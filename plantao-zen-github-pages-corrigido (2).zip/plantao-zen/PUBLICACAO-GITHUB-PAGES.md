# Plantão Zen Health — GitHub Pages

O GitHub Pages **não executa** o backend Node/Express/tRPC nem autenticação real. Por segurança, este deploy publica apenas a **prévia navegável com dados fictícios**, começando pelo login, com aviso visível. Não utilize dados ou senhas reais nela.

## Publicar

1. Envie este projeto para `lucasrosa2026dev-max/plantao-zen2026`, mantendo os arquivos da pasta `.github/workflows/`.
2. No GitHub, abra **Settings → Pages → Build and deployment → Source** e selecione **GitHub Actions**.
3. Abra **Actions** e acompanhe a execução **Publicar prévia Plantão Zen no GitHub Pages**. Se necessário, use **Run workflow**.
4. Acesse `https://lucasrosa2026dev-max.github.io/plantao-zen2026/` após a execução bem-sucedida.

Há também um `index.html` autônomo na raiz para o caso de a configuração anterior ainda publicar a partir da raiz da branch. O workflow gera uma versão nova usando `pnpm run build:preview:full`.

## Para tornar o login real

Publicar o backend em ambiente com Node, banco MySQL/TiDB, HTTPS, cookies seguros e configuração de domínios/CORS, e publicar frontend no **mesmo domínio** ou em infraestrutura com autenticação entre origens cuidadosamente configurada. GitHub Pages sozinho não fornece essa infraestrutura. Não salve segredos no frontend nem em `VITE_*`.

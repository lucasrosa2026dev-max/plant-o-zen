plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}
android {
  namespace = "care.plantaozen.watch"
  compileSdk = 35
  defaultConfig {
    applicationId = "care.plantaozen.watch"
    minSdk = 30
    targetSdk = 35
    versionCode = 1
    versionName = "0.1.0"
  }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}

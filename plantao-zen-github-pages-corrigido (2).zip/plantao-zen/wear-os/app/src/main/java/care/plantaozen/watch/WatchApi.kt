package care.plantaozen.watch

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class WatchHttpException(val statusCode: Int, message: String): Exception(message)

class WatchApi(private val store: SecureStore) {
  fun request(method: String, path: String, data: JSONObject? = null, auth: Boolean = true): JSONObject {
    val base = store.server().trimEnd('/')
    require(base.startsWith("https://") && !base.contains("@")) { "Informe a URL pública HTTPS do Plantão Zen." }
    val connection = URL(base + path).openConnection() as HttpURLConnection
    try {
      connection.connectTimeout = 10000
      connection.readTimeout = 12000
      connection.requestMethod = method
      connection.instanceFollowRedirects = false
      connection.setRequestProperty("Accept", "application/json")
      if (auth) connection.setRequestProperty("Authorization", "Bearer ${store.read() ?: error("Relógio não conectado")}")
      if (data != null) {
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.outputStream.use { it.write(data.toString().toByteArray(Charsets.UTF_8)) }
      }
      val status = connection.responseCode
      val body = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
      val response = JSONObject(body)
      if (status !in 200..299) throw WatchHttpException(status, response.optString("error", "Erro HTTP $status"))
      return response
    } finally { connection.disconnect() }
  }
}

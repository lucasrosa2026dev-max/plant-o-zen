package care.plantaozen.watch

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.io.IOException
import java.util.concurrent.Executors

/** Protótipo funcional Wear OS. Alertas são consultados SOMENTE enquanto a tela está aberta. */
class WatchActivity : Activity() {
  private val io = Executors.newSingleThreadExecutor()
  private val main = Handler(Looper.getMainLooper())
  private lateinit var store: SecureStore
  private lateinit var api: WatchApi
  private lateinit var root: LinearLayout
  private var polling = false
  private var lastAlert = -1
  private val refresh = object : Runnable {
    override fun run() {
      if (!polling) return
      runTask(silent = true) {
        val result = api.request("GET", "/api/watch/v1/alerts").optJSONArray("alerts")
        if (result != null && result.length() > 0) {
          val obj = result.getJSONObject(0)
          val id = obj.optInt("id", -1)
          if (lastAlert >= 0 && id > lastAlert && obj.optInt("isRead", 1) == 0) main.post { notifyAlert(obj.optString("title", "Novo alerta")) }
          lastAlert = maxOf(lastAlert, id)
        }
      }
      main.postDelayed(this, 60000)
    }
  }
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    store = SecureStore(this)
    api = WatchApi(store)
    root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(20, 18, 20, 18)
    }
    val scroll = ScrollView(this)
    scroll.addView(root)
    setContentView(scroll)
    val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(NotificationChannel("plantao_watch", "Alertas de plantão", NotificationManager.IMPORTANCE_DEFAULT))
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
      requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
    home()
  }
  override fun onResume() { super.onResume(); polling = true; main.postDelayed(refresh, 2000) }
  override fun onPause() { polling = false; main.removeCallbacks(refresh); super.onPause() }
  private fun clear(title: String) {
    root.removeAllViews()
    label(title, 18)
  }
  private fun label(value: String, size: Int = 14) {
    root.addView(TextView(this).apply { text = value; textSize = size; setPadding(4, 8, 4, 8) })
  }
  private fun field(hint: String, numeric: Boolean = false): EditText {
    val edit = EditText(this).apply {
      this.hint = hint
      isSingleLine = true
      if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
      textSize = 14f
    }
    root.addView(edit)
    return edit
  }
  private fun button(title: String, onClick: () -> Unit) {
    root.addView(Button(this).apply {
      text = title
      isAllCaps = false
      layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
      setOnClickListener { onClick() }
    })
  }
  private fun runTask(silent: Boolean = false, action: () -> Unit) {
    io.execute {
      try { action() }
      catch (e: Exception) { if (!silent) main.post { Toast.makeText(this, e.message ?: "Falha de conexão", Toast.LENGTH_LONG).show() } }
    }
  }
  private fun home() {
    clear("Plantão Zen ⌚")
    if (store.read() == null) {
      label("Conecte sua conta pelo portal do Plantão Zen.")
      val base = field("https://seu-dominio.com")
      base.setText(store.server())
      val code = field("Código de 8 dígitos", true)
      button("Conectar") {
        val server = base.text.toString().trim().trimEnd('/')
        val number = code.text.toString().trim()
        if (!server.startsWith("https://") || !Regex("^\\d{8}$").matches(number)) {
          Toast.makeText(this, "Use HTTPS e código de 8 dígitos", Toast.LENGTH_SHORT).show(); return@button
        }
        store.setServer(server)
        runTask { val data = api.request("POST", "/api/watch/pair", JSONObject().put("code", number).put("label", "Wear OS"), auth = false)
          store.save(data.getString("token")); main.post { home() } }
      }
      return
    }
    button("Minhas escalas") { schedules() }
    button("Alertas") { alerts() }
    button("Mensagens") { conversations() }
    button("Desconectar") { runTask { api.request("POST", "/api/watch/v1/unpair", JSONObject()); store.clear(); main.post { home() } } }
  }
  private fun schedules() {
    clear("Minhas escalas")
    button("Voltar") { home() }
    label("Sincronizando...")
    runTask {
      try {
        val arr = api.request("GET", "/api/watch/v1/shifts").optJSONArray("shifts") ?: org.json.JSONArray()
        store.saveScheduleCache(arr.toString())
        main.post { showSchedules(arr, offline = false) }
      } catch (e: IOException) {
        // Somente falha de rede autoriza usar cache. Erros 401/403 NÃO entram no modo offline.
        val cached = store.readScheduleCache()
        main.post {
          if (cached == null) {
            clear("Minhas escalas")
            button("Voltar") { home() }
            label("Sem conexão e sem escala recente salva.")
          } else showSchedules(cached, offline = true)
        }
      } catch (e: WatchHttpException) {
        if (e.statusCode == 401 || e.statusCode == 403) store.clearScheduleCache()
        main.post { clear("Minhas escalas"); button("Voltar") { home() }; label("Acesso não autorizado. Conecte novamente se necessário.") }
      }
    }
  }
  private fun showSchedules(arr: org.json.JSONArray, offline: Boolean) {
    clear("Minhas escalas")
    button("Voltar") { home() }
    if (offline) label("SEM CONEXÃO · Escala salva (até 24h). Confira alterações ao reconectar. Presença indisponível.")
    if (arr.length() == 0) { label("Nenhum plantão cadastrado."); return }
    for (i in 0 until arr.length()) {
      val s = arr.getJSONObject(i)
      label("${s.optString("title")} · ${s.optString("status")}\n${s.optString("startsAt")}")
      if (offline) continue
      if (s.optString("status") != "cancelled" && s.isNull("checkInAt")) button("Entrada · #${s.getInt("id")}") { attendance(s.getInt("id"), "in") }
      else if (!s.isNull("checkInAt") && s.isNull("checkOutAt")) button("Saída · #${s.getInt("id")}") { attendance(s.getInt("id"), "out") }
    }
  }
  private fun attendance(id: Int, action: String) {
    // Confirmação explícita para evitar toque acidental.
    android.app.AlertDialog.Builder(this).setTitle("Registrar ${if (action == "in") "entrada" else "saída"}?")
      .setMessage("Plantão #$id. O horário oficial será o do servidor.")
      .setNegativeButton("Cancelar", null)
      .setPositiveButton("Confirmar") { _, _ -> runTask { api.request("POST", "/api/watch/v1/attendance", JSONObject().put("id", id).put("action", action)); main.post { schedules() } } }.show()
  }
  private fun alerts() {
    clear("Alertas")
    button("Voltar") { home() }
    runTask { val arr = api.request("GET", "/api/watch/v1/alerts").optJSONArray("alerts")
      main.post { if (arr == null || arr.length() == 0) label("Sem alertas.") else for (i in 0 until arr.length()) label(arr.getJSONObject(i).optString("title")) } }
  }
  private fun conversations() {
    clear("Conversas")
    button("Voltar") { home() }
    runTask { val result = api.request("GET", "/api/watch/v1/conversations").optJSONArray("conversations")
      main.post {
        if (result == null || result.length() == 0) label("Sem conversas disponíveis.")
        else for (i in 0 until result.length()) {
          val c = result.getJSONObject(i)
          val id = c.optInt("id")
          button("Conversa #$id") { thread(id) }
        }
      }
    }
  }
  private fun thread(id: Int) {
    clear("Conversa #$id")
    button("Voltar") { conversations() }
    runTask { val result = api.request("GET", "/api/watch/v1/messages/$id")
      // A resposta do chat existente pode incluir metadados variados; ler apenas mensagens textuais.
      val arr = result.optJSONArray("messages")
      main.post { if (arr != null) for (i in maxOf(0, arr.length() - 15) until arr.length()) label(arr.getJSONObject(i).optString("body")) }
    }
    val message = field("Mensagem")
    button("Enviar") {
      val value = message.text.toString().trim()
      if (value.isEmpty()) return@button
      runTask { api.request("POST", "/api/watch/v1/messages", JSONObject().put("conversationId", id).put("message", value)); main.post { thread(id) } }
    }
  }
  private fun notifyAlert(title: String) {
    val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    val notification = android.app.Notification.Builder(this, "plantao_watch")
      .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Plantão Zen")
      .setContentText(title.take(80)).setAutoCancel(true).build()
    try { manager.notify(2001, notification) } catch (_: SecurityException) { /* sem permissão */ }
  }
}

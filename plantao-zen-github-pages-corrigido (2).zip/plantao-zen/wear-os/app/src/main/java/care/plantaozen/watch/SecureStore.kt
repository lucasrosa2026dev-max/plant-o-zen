package care.plantaozen.watch

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// Nunca armazena o bearer em SharedPreferences sem criptografia.
class SecureStore(private val context: Context) {
  private val preferences = context.getSharedPreferences("watch_secure", Context.MODE_PRIVATE)
  private val alias = "plantaozen.watch.token"
  private fun key(): SecretKey {
    val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (ks.getKey(alias, null) as? SecretKey)?.let { return it }
    return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
      init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).build())
    }.generateKey()
  }
  private fun seal(plain: String): String {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key())
    return Base64.encodeToString(cipher.iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
  }
  private fun unseal(encoded: String): String {
    val bytes = Base64.decode(encoded, Base64.NO_WRAP)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
    return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
  }
  fun save(token: String) { preferences.edit().remove("shifts_cache").putString("token", seal(token)).apply() }
  fun read(): String? = try {
    preferences.getString("token", null)?.let { unseal(it) }
  } catch (_: Exception) { null }

  // Cache mínimo, cifrado, vinculado à conta pareada e válido por até 24 horas.
  // Nunca guardar mensagens, dados médicos ou credenciais em texto aberto.
  fun saveScheduleCache(shiftsJson: String) {
    val payload = org.json.JSONObject()
      .put("savedAt", System.currentTimeMillis())
      .put("shifts", org.json.JSONArray(shiftsJson))
    preferences.edit().putString("shifts_cache", seal(payload.toString())).apply()
  }
  fun readScheduleCache(): org.json.JSONArray? {
    return try {
    if (read() == null) return null
    val encoded = preferences.getString("shifts_cache", null) ?: return null
    val data = org.json.JSONObject(unseal(encoded))
    val age = System.currentTimeMillis() - data.getLong("savedAt")
    if (age < 0 || age > 24 * 60 * 60 * 1000L) null else data.getJSONArray("shifts")
    } catch (_: Exception) { null }
  }
  fun clearScheduleCache() { preferences.edit().remove("shifts_cache").apply() }
  fun clear() { preferences.edit().remove("token").remove("shifts_cache").apply() }
  fun setServer(value: String) { preferences.edit().putString("server", value).apply() }
  fun server(): String = preferences.getString("server", "") ?: ""
}

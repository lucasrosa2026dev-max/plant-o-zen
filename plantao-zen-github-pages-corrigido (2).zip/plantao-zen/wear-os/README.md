# Plantão Zen Watch (Wear OS) — protótipo Android

Abra **esta pasta `wear-os/` como projeto separado no Android Studio**. Requer JDK 17, Android SDK 35 e Gradle/Android Gradle Plugin disponíveis pela internet. O módulo é independente do aplicativo Capacitor existente e **não deve ser incluído em `android/`**.

O aplicativo permite parear com código de 8 dígitos, consultar escalas, confirmar entrada/saída, listar alertas e ler/enviar mensagens. Exige HTTPS público; token fica criptografado no Android Keystore e pode ser revogado no portal. O token expira após 30 dias: é necessário novo pareamento.

Limitações nesta versão: notificações são atualizadas apenas enquanto o aplicativo está **em primeiro plano**, aproximadamente a cada 60 segundos; sem FCM push, sem ação offline confiável, sem validação de localização da presença; interface nativa simplificada, sem Compose. Nem todo relógio Android é Wear OS. **Apple Watch/watchOS não incluído**. Confira o guia `INTEGRACAO-SMARTWATCH.md` antes de homologar.

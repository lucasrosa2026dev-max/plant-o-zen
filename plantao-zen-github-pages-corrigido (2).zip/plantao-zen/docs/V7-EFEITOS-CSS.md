# V7 — efeitos visuais

Atualização de 12/10/2026 sobre a entrega V7 etapa 1.

- Brilho discreto em verde-água nas bordas e sombras dos cards.
- Degradê suave nos painéis, adaptado aos temas claro e escuro.
- Entrada breve dos painéis de plantões e da tela de acesso, sem repetição contínua.
- Realce dos campos ao navegar com teclado e dos painéis que contêm o foco.
- Resposta dos botões e itens do calendário ao mouse, com deslocamento máximo de 1px; CTA de login com 2px.
- Indicador lateral do item selecionado no menu, usando `aria-current`.
- SOS sem deslocamento. Botões desabilitados sem efeitos de hover.
- Novas animações e deslocamentos desativados com `prefers-reduced-motion`.

Arquivos de código alterados: `client/src/index.css`, `client/src/pages/medical-login.css` e `client/src/pages/Portal.tsx` (atributo de acessibilidade do menu). Sem novas dependências, alterações de dados, autenticação ou banco.

## Verificação

- TypeScript e compilação aprovados. Permanecem os avisos anteriores de tamanho do pacote e script de configuração em tempo de execução.
- Prévia local: navegação entre seções, temas claro/escuro, estilo calculado de animação/degradê e foco em campo conferidos no navegador.
- Largura de celular de 390px conferida: conteúdo de 375px, sem transbordamento horizontal da página.
- Tela de login: animações carregadas e botão desabilitado com transformação `none`.
- Regras de redução de movimento e exclusão do SOS revisadas no código; não foi feita alteração da preferência do sistema operacional.
- Imagem `v7-efeitos-previa.png`: tela de prévia isolada, sem dados de usuários e com gravações bloqueadas.

Não foram repetidos testes de banco ou integrações nesta alteração visual. As pendências da etapa 1 continuam descritas em `V7-ENTREGA-ETAPA1.md`.

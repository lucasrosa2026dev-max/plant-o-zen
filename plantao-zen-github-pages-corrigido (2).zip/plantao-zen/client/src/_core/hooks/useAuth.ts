import { useQueryClient } from "@tanstack/react-query";
import { clearSessionCache } from "@/lib/sessionCache";
import { readPushRegistration, clearNativePush } from "@/lib/nativePush";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useMemo } from "react";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath } = options ?? {};
  const utils = trpc.useUtils();
  const queryClient = useQueryClient();

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.setData(undefined, null);
    },
  });

  const logout = useCallback(async () => {
    let ended = false;
    try {
      await logoutMutation.mutateAsync({
        pushToken: readPushRegistration()?.token,
      });
      ended = true;
      await clearNativePush();
    } catch (error: unknown) {
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        ended = true;
        await clearNativePush();
        return;
      }
      throw error;
    } finally {
      if (ended) {
        await clearSessionCache(queryClient);
        utils.auth.me.setData(undefined, null);
      }
    }
  }, [logoutMutation, utils, queryClient]);

  const state = useMemo(() => {
    return {
      // Never keep rendering protected pages with stale user data after the
      // session check fails. Protected queries would otherwise return 401 and
      // the dashboard would show a misleading generic data error.
      user: meQuery.error ? null : (meQuery.data ?? null),
      loading: meQuery.isLoading || logoutMutation.isPending,
      error: meQuery.error ?? logoutMutation.error ?? null,
      isAuthenticated: Boolean(meQuery.data) && !meQuery.error,
    };
  }, [
    meQuery.data,
    meQuery.error,
    meQuery.isLoading,
    logoutMutation.error,
    logoutMutation.isPending,
  ]);

  useEffect(() => {
    if (!redirectOnUnauthenticated) return;
    if (meQuery.isLoading || logoutMutation.isPending) return;
    if (state.user) return;
    if (typeof window === "undefined") return;
    if (redirectPath && window.location.pathname === redirectPath) return;

    if (redirectPath) {
      window.location.href = redirectPath;
    } else {
      startLogin();
    }
  }, [
    redirectOnUnauthenticated,
    redirectPath,
    logoutMutation.isPending,
    meQuery.isLoading,
    state.user,
  ]);

  return {
    ...state,
    refresh: () => meQuery.refetch(),
    logout,
  };
}

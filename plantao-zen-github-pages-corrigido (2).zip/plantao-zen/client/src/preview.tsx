import { createRoot } from "react-dom/client";
import { Toaster, toast } from "sonner";
import { ThemeProvider } from "./contexts/ThemeContext";
import Demo from "./pages/Demo";
// Local preview: navigation stays inside this file and never contacts the server.
document.addEventListener(
  "click",
  event => {
    const target =
      event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (target && !target.getAttribute("href")?.startsWith("#")) {
      event.preventDefault();
      event.stopPropagation();
      toast(
        "Prévia local. Para acessar as outras telas, execute o projeto e entre na sua conta."
      );
    }
  },
  true
);
createRoot(document.getElementById("root")!).render(
  <ThemeProvider defaultTheme="light" switchable>
    <Toaster />
    <Demo />
  </ThemeProvider>
);

export type DeviceCapabilities = {
  notifications: boolean;
  notificationPermission: NotificationPermission | "unsupported";
  notificationActions: boolean;
  serviceWorker: boolean;
  pwaInstalled: boolean;
  likelySmartwatchMirroring: boolean;
};

export function getDeviceCapabilities(): DeviceCapabilities {
  const notifications = typeof window !== "undefined" && "Notification" in window;
  const standalone = typeof window !== "undefined" && (window.matchMedia?.("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);
  return {
    notifications,
    notificationPermission: notifications ? Notification.permission : "unsupported",
    notificationActions: notifications && "actions" in Notification.prototype,
    serviceWorker: typeof navigator !== "undefined" && "serviceWorker" in navigator,
    pwaInstalled: Boolean(standalone),
    likelySmartwatchMirroring: notifications && /Android/i.test(navigator.userAgent),
  };
}

export async function requestNotificationPermission() {
  if (!("Notification" in window)) return "unsupported" as const;
  return Notification.requestPermission();
}

export async function showEmergencyNotification(message: string) {
  if (!("Notification" in window) || Notification.permission !== "granted") return false;
  const options: NotificationOptions = {
    body: message,
    tag: "plantao-zen-emergency",
    requireInteraction: true,
  };
  try {
    if ("serviceWorker" in navigator) {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration?.showNotification) {
        await registration.showNotification("EMERGÊNCIA — Plantão Zen", options);
        return true;
      }
    }
    new Notification("EMERGÊNCIA — Plantão Zen", options);
    return true;
  } catch {
    return false;
  }
}

import { Capacitor } from "@capacitor/core";
import { PushNotifications } from "@capacitor/push-notifications";
const KEY = "plantao-native-push";
export const isAndroidApp = () =>
  Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
export function readPushRegistration(): {
  token: string;
  userId: number;
} | null {
  try {
    const value = JSON.parse(localStorage.getItem(KEY) || "null");
    return value &&
      typeof value.token === "string" &&
      typeof value.userId === "number"
      ? value
      : null;
  } catch {
    return null;
  }
}
export function savePushRegistration(token: string, userId: number) {
  localStorage.setItem(KEY, JSON.stringify({ token, userId }));
}
export async function clearNativePush() {
  localStorage.removeItem(KEY);
  if (isAndroidApp())
    await PushNotifications.unregister().catch(() => undefined);
}

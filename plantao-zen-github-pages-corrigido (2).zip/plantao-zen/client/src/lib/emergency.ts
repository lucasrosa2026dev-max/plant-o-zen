let audioContext: AudioContext | null = null;
let intervalId: number | null = null;

export function startEmergencyAlert() {
  if (typeof window === "undefined") return;
  stopEmergencyAlert();
  try {
    audioContext = new AudioContext();
    const playBeep = () => {
      if (!audioContext) return;
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = 880;
      gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.16, audioContext.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.34);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.36);
    };
    void audioContext.resume();
    playBeep();
    intervalId = window.setInterval(playBeep, 900);
  } catch {
    // The UI still shows the emergency state when audio is blocked by the browser.
  }
}

export function stopEmergencyAlert() {
  if (intervalId !== null) window.clearInterval(intervalId);
  intervalId = null;
  if (audioContext) void audioContext.close().catch(() => undefined);
  audioContext = null;
}

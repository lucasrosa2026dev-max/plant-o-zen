export type AuthAction =
  | "login"
  | "register"
  | "forgot-password"
  | "reset-password";
export type AuthResult = { success: true } | { requires2fa: true };

/** Consume the body before clearing the timeout; a stalled response must not lock the form. */
export async function postAuth(
  action: AuthAction,
  payload: Record<string, unknown>
): Promise<AuthResult> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);
  try {
    const response = await fetch(`/api/auth/${action}`, {
      method: "POST",
      credentials: "same-origin",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const messages: Record<number, string> = {
        400:
          action === "reset-password"
            ? "Link inválido ou expirado. Solicite um novo link e use uma senha de 12 a 128 caracteres."
            : "Confira os campos informados. A senha deve ter de 12 a 128 caracteres.",
        401: payload.totpCode
          ? "Não foi possível validar o acesso. Confira a senha e o código atual do autenticador."
          : "E-mail ou senha incorretos. Confira seus dados e tente novamente.",
        403: "Não foi possível validar este acesso. Reabra o site pelo endereço oficial.",
        409: "Não foi possível cadastrar este e-mail. Tente entrar ou solicite ajuda ao administrador.",
        429: "Muitas tentativas. Aguarde 15 minutos antes de tentar novamente.",
      };
      throw new Error(
        messages[response.status] ??
          "O serviço está temporariamente indisponível. Tente novamente em alguns instantes."
      );
    }
    const result: unknown = await response.json();
    if (result && typeof result === "object") {
      if (
        response.status === 202 &&
        action === "login" &&
        "requires2fa" in result &&
        result.requires2fa === true
      )
        return { requires2fa: true };
      if (
        response.status !== 202 &&
        "success" in result &&
        result.success === true
      )
        return { success: true };
    }
    throw new Error(
      "Não foi possível confirmar a resposta do servidor. Tente novamente."
    );
  } catch (error) {
    if (controller.signal.aborted)
      throw new Error(
        "O servidor demorou para responder. Tente novamente. Se acabou de cadastrar, tente entrar com seus dados."
      );
    if (error instanceof TypeError || error instanceof SyntaxError)
      throw new Error(
        "Não foi possível confirmar o acesso. Confira sua conexão e tente novamente."
      );
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

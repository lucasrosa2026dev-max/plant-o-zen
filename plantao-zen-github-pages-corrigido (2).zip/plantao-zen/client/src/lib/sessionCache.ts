import type { QueryClient } from "@tanstack/react-query";

export async function clearSessionCache(client: QueryClient) {
  // Cancel pending reads before removing data, so late responses cannot restore it.
  await client.cancelQueries();
  client.clear();
}

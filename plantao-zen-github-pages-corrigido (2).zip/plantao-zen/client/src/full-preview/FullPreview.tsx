import { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { observable } from "@trpc/server/observable";
import { TRPCClientError } from "@trpc/client";
import { Router, useLocation } from "wouter";
import { memoryLocation } from "wouter/memory-location";
import { Toaster, toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "@/components/ErrorBoundary";
import Portal from "@/pages/Portal";
import LoginScreen from "@/pages/LoginScreen";
import About from "@/pages/About";
import Privacy from "@/pages/Privacy";
import NotFound from "@/pages/NotFound";
import { previewData, previewQuery } from "./data";
import "@/pages/login.css";
export const pages = [
  ["/", "Visão geral"],
  ["/login", "Login"],
  ["/register", "Criar conta"],
  ["/workforce", "Plantões"],
  ["/messages", "Mensagens"],
  ["/messages/moderation", "Moderação"],
  ["/checkin", "Como estou"],
  ["/analyses", "Minhas análises"],
  ["/analyses/1", "Detalhe de análise"],
  ["/contacts", "Rede de apoio"],
  ["/safety", "Plano de segurança"],
  ["/emergency", "Emergência"],
  ["/profile", "Meu perfil"],
  ["/smartwatch", "Relógio"],
  ["/settings", "Configurações"],
  ["/about", "Sobre"],
  ["/privacidade", "Privacidade"],
  ["/404", "Página não encontrada"],
] as const;
const notice =
  "Prévia de navegação: alterações, envios e integrações estão desativados.";
export function createPreviewCache() {
  const cache = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
        refetchOnWindowFocus: false,
      },
    },
  });
  for (const [path, data] of Object.entries(previewData))
    cache.setQueryData([path.split("."), { type: "query" }], data);
  cache.setQueryData(
    [["analyses", "list"], { type: "query", input: { limit: 100 } }],
    previewQuery("analyses.list", {})
  );
  return cache;
}
export function createPreviewClient(onLogout: () => void) {
  return trpc.createClient({
    links: [
      () =>
        ({ op }) =>
          observable(observer => {
            try {
              if (op.type === "mutation") {
                if (
                  op.path === "chat.markRead" ||
                  op.path === "smartwatch.save"
                ) {
                  observer.next({ result: { data: { success: true } } });
                  observer.complete();
                  return;
                }
                if (op.path === "auth.logout") {
                  onLogout();
                  observer.error(
                    TRPCClientError.from(
                      new Error("Prévia: nenhuma sessão real foi encerrada.")
                    )
                  );
                  return;
                }
                toast.info(notice);
                observer.error(TRPCClientError.from(new Error(notice)));
                return;
              }
              observer.next({
                result: { data: previewQuery(op.path, op.input) },
              });
              observer.complete();
            } catch (error) {
              observer.error(
                TRPCClientError.from(
                  error instanceof Error
                    ? error
                    : new Error("Prévia indisponível")
                )
              );
            }
          }),
    ],
  });
}
export function PreviewScreen({ path }: { path: string }) {
  if (path === "/login" || path === "/register")
    return <LoginScreen key={path} register={path === "/register"} />;
  if (path === "/about") return <About />;
  if (path === "/privacidade") return <Privacy />;
  if (path === "/404") return <NotFound />;
  return <Portal />;
}
function Navigator() {
  const [path, navigate] = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
    const click = (event: MouseEvent) => {
      const target = event.target instanceof Element ? event.target : null;
      const link = target?.closest("a[href]");
      if (link) {
        const href = link.getAttribute("href")!;
        if (href.startsWith("#")) return;
        event.preventDefault();
        event.stopPropagation();
        if (href.startsWith("/")) navigate(href === "/demo" ? "/" : href);
        else toast.info(notice);
        return;
      }
      const button = target?.closest("button");
      if (
        button &&
        (button.title === "Ligar" ||
          (button.closest("#main-content") &&
            ["/emergency", "/smartwatch"].includes(path)))
      ) {
        event.preventDefault();
        event.stopPropagation();
        toast.info(notice);
      }
    };
    const submit = (event: SubmitEvent) => {
      event.preventDefault();
      event.stopPropagation();
      if (
        path === "/login" &&
        event.target instanceof HTMLFormElement &&
        !event.target.querySelector("input[name=password]")
      ) {
        toast.info("Recuperação demonstrativa. Nenhum e-mail foi enviado.");
        return;
      }
      if (path === "/login" || path === "/register") {
        toast.info(
          "Acesso demonstrativo: nenhuma conta foi criada ou autenticada. Use ‘Explorar o painel’ para navegar pela prévia."
        );
      } else toast.info(notice);
    };
    const rejection = (event: PromiseRejectionEvent) => {
      event.preventDefault();
      toast.info(notice);
    };
    document.addEventListener("click", click, true);
    document.addEventListener("submit", submit, true);
    window.addEventListener("unhandledrejection", rejection);
    return () => {
      document.removeEventListener("click", click, true);
      document.removeEventListener("submit", submit, true);
      window.removeEventListener("unhandledrejection", rejection);
    };
  }, [path, navigate]);
  return (
    <>
      <div className="pz-preview-toolbar">
        <div>
          <strong>PRÉVIA COMPLETA</strong>
          <span>
            Dados fictícios · sem gravação ou envio. Não use senhas reais.
          </span>
        </div>
        <label>
          <span className="sr-only">Escolher tela</span>
          <select value={path} onChange={e => navigate(e.target.value)}>
            {pages.map(([value, label]) => (
              <option value={value} key={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <button onClick={() => navigate(path === "/login" ? "/" : "/login")}>
          {path === "/login" ? "Explorar o painel" : "Ver login"}
        </button>
      </div>
      <PreviewScreen path={path} />
    </>
  );
}
export default function FullPreview() {
  const [location] = useState(() => memoryLocation({ path: "/login" }));
  const [cache] = useState(createPreviewCache);
  const [client] = useState(() =>
    createPreviewClient(() => location.navigate("/login"))
  );
  return (
    <Router hook={location.hook} searchHook={location.searchHook}>
      <ErrorBoundary>
        <trpc.Provider client={client} queryClient={cache}>
          <QueryClientProvider client={cache}>
            <ThemeProvider defaultTheme="light" switchable>
              <TooltipProvider>
                <Toaster />
                <Navigator />
              </TooltipProvider>
            </ThemeProvider>
          </QueryClientProvider>
        </trpc.Provider>
      </ErrorBoundary>
    </Router>
  );
}

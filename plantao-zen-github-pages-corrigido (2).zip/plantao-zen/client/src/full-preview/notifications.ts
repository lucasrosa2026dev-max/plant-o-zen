export function getDeviceCapabilities() {
  return {
    notifications: false,
    notificationPermission: "unsupported" as const,
    notificationActions: false,
    serviceWorker: false,
    pwaInstalled: false,
    likelySmartwatchMirroring: false,
  };
}
export async function requestNotificationPermission() {
  return "unsupported" as const;
}
export async function showEmergencyNotification(_message: string) {
  return false;
}
export function startEmergencyAlert() {}
export function stopEmergencyAlert() {}

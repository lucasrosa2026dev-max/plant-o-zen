import { createRoot } from "react-dom/client";
import FullPreview from "./FullPreview";
createRoot(document.getElementById("root")!).render(<FullPreview />);

import { localDateKey } from "@shared/workforce";
const now = new Date();
const at = (offset: number, hour: number) => {
  const d = new Date(now);
  d.setDate(d.getDate() + offset);
  d.setHours(hour, 0, 0, 0);
  return d;
};
const stamp = { createdAt: now, updatedAt: now };
export const previewUser = {
  id: 1,
  openId: "preview-only",
  name: "Marina Oliveira",
  email: "marina@example.com",
  loginMethod: "password",
  role: "admin",
  lastSignedIn: now,
  ...stamp,
};
const contacts = ["Ana Souza", "Rafael Mendes", "Luciana Costa"].map(
  (name, i) => ({
    id: i + 1,
    userId: 1,
    name,
    phone: "(00) 00000-0000",
    email: `contato${i + 1}@example.com`,
    relationship: i === 0 ? "Família" : "Colega de equipe",
    isEmergency: i < 2 ? 1 : 0,
    emergencyPriority: i,
    linkedOpenId: null,
    ...stamp,
  })
);
const shifts = [
  {
    id: 1,
    title: "UTI adulto · Plantão diurno",
    professionalName: "Marina Oliveira",
    startsAt: at(0, 7),
    endsAt: at(0, 19),
    status: "planned",
    checkInAt: null,
    checkOutAt: null,
  },
  {
    id: 2,
    title: "Pronto atendimento",
    professionalName: "Rafael Mendes",
    startsAt: at(1, 7),
    endsAt: at(1, 19),
    status: "planned",
    checkInAt: null,
    checkOutAt: null,
  },
  {
    id: 3,
    title: "Enfermaria · Plantão noturno",
    professionalName: "Marina Oliveira",
    startsAt: at(-2, 19),
    endsAt: at(-1, 7),
    status: "completed",
    checkInAt: at(-2, 19),
    checkOutAt: at(-1, 7),
  },
].map(s => ({ ...s, ownerId: 1, hourlyCents: 0, createdAt: now }));
const analyses = [
  {
    id: 1,
    userId: 1,
    title: "Depois do plantão",
    result: "Tranquilo",
    details:
      "Registro fictício: organizei os horários da semana e reservei um período de descanso.",
    createdAt: at(-1, 19),
  },
  {
    id: 2,
    userId: 1,
    title: "Organização da rotina",
    result: "Atenção",
    details: "Registro fictício: lembrar de fazer pausas entre as atividades.",
    createdAt: at(-3, 9),
  },
];
const conversations = [
  {
    id: 1,
    status: "accepted",
    direction: "outgoing",
    otherName: "Rafael Mendes",
    lastMessage: "Combinado! Já conferi os horários.",
    lastMessageAt: at(0, 9),
    lastMessageIsMine: false,
    lastMessageReadAt: at(0, 9),
  },
  {
    id: 2,
    status: "accepted",
    direction: "incoming",
    otherName: "Ana Souza",
    lastMessage: "Como foi seu dia?",
    lastMessageAt: at(-1, 20),
    lastMessageIsMine: false,
    lastMessageReadAt: null,
  },
];
export const previewData: Record<string, unknown> = {
  "auth.me": previewUser,
  "workforce.list": shifts,
  "workforce.audit": [
    {
      id: 1,
      ownerId: 1,
      shiftId: 1,
      action: "shift.created",
      details: JSON.stringify({
        professionalName: "Marina Oliveira",
        title: "UTI adulto",
      }),
      createdAt: at(-1, 10),
    },
    {
      id: 2,
      ownerId: 1,
      shiftId: 3,
      action: "attendance.out",
      details: null,
      createdAt: at(-1, 7),
    },
  ],
  "contacts.list": contacts,
  "profile.get": {
    id: 1,
    userId: 1,
    fullName: "Marina Oliveira",
    phone: "(00) 00000-0000",
    birthDate: "1995-05-15",
    city: "Rio de Janeiro",
    careNotes: "Perfil fictício para conhecer as telas.",
    ...stamp,
  },
  "analyses.list": analyses,
  "checkins.list": [
    {
      id: 1,
      userId: 1,
      mood: "Estou bem",
      notes: "Dado fictício: consegui descansar antes do plantão.",
      createdAt: at(0, 6),
    },
    {
      id: 2,
      userId: 1,
      mood: "Preciso de atenção",
      notes: "Dado fictício: dia cheio, reservei tempo para uma pausa.",
      createdAt: at(-1, 18),
    },
  ],
  "safetyPlan.get": {
    id: 1,
    userId: 1,
    safeLocation: "Exemplo: um lugar tranquilo com alguém de confiança",
    medications: "Exemplo: informações que você considera importantes",
    allergies: "Exemplo: registrar informações conhecidas",
    priorityContacts: "Ana Souza · rede de apoio fictícia",
    instructions: "Exemplo: conversar com uma pessoa de confiança",
    localServices: "Exemplo: anotar serviços da sua região",
    updatedAt: now,
  },
  "preferences.get": {
    id: 1,
    userId: 1,
    notificationsEnabled: 0,
    soundEnabled: 0,
    smartwatchEnabled: 0,
    backgroundEnabled: 0,
    callConfirmationRequired: 1,
    theme: "light",
    updatedAt: now,
  },
  "smartwatch.get": {
    id: 1,
    userId: 1,
    platform: "Prévia local",
    pwaInstalled: 0,
    supportsNotifications: 0,
    supportsActions: 0,
    notificationPermission: "unsupported",
    smartwatchMirroring: 0,
    updatedAt: now,
  },
  "emergency.active": null,
  "inbox.list": [
    {
      id: 1,
      userId: 1,
      eventType: "preview",
      relatedEmergencyId: null,
      title: "Bem-vinda à prévia completa",
      body: "Todos os nomes e registros são fictícios. Explore as telas pelo menu.",
      isRead: 0,
      createdAt: now,
    },
  ],
  "chat.settings.get": { discoverable: true, publicChatId: "PZ-DEMONSTRACAO" },
  "chat.conversations": conversations,
  "chat.directorySearch": [
    { publicChatId: "PZ-EXEMPLO-001", name: "Rafael Mendes" },
  ],
  "chat.blocked.list": [],
  "chat.adminReports": [],
  "security.twoFactorStatus": { enabled: false },
  "security.sessionCount": { count: 1 },
  "watch.devices": [],
};
export function previewQuery(path: string, input: unknown) {
  const params =
    input && typeof input === "object"
      ? (input as Record<string, unknown>)
      : {};
  if (path === "chat.thread") {
    const id = Number(params.conversationId);
    const c = conversations.find(c => c.id === id) ?? conversations[0];
    return {
      conversation: c,
      messages: [
        {
          id: 1,
          body:
            id === 2
              ? "Oi, Marina! Como foi seu dia?"
              : "Oi, Rafael! Já organizei minha agenda da semana.",
          isMine: id !== 2,
          createdAt: at(0, 8),
          readAt: at(0, 9),
        },
        {
          id: 2,
          body:
            id === 2
              ? "Tudo bem por aqui. Obrigada por perguntar!"
              : "Combinado! Já conferi os horários.",
          isMine: id === 2,
          createdAt: at(0, 9),
          readAt: at(0, 9),
        },
      ],
    };
  }
  if (path === "analyses.get")
    return analyses.find(a => a.id === params.id) ?? null;
  if (path === "analyses.list" && params.result)
    return analyses.filter(a => a.result === params.result);
  if (path in previewData) return previewData[path];
  throw new Error(`Consulta não disponível nesta prévia: ${path}`);
}
export const previewDate = localDateKey(now);

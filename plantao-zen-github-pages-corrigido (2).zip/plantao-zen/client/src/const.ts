export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
export function startLogin(): void {
  if (window.location.pathname !== "/login") window.location.assign("/login");
}

import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock3,
  HeartPulse,
  Plus,
  ShieldCheck,
  Users,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { intersectsLocalDay, localDateKey } from "@shared/workforce";
import { weekSummary } from "@shared/overview";
const time = (date: Date | string) =>
  new Intl.DateTimeFormat("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(date));
function QueryError({ retry }: { retry: () => void }) {
  return (
    <div className="pz-query-error" role="status">
      Não foi possível carregar estes dados.
      <button onClick={retry}>Tentar novamente</button>
    </div>
  );
}
export default function Overview({
  user,
  preview = false,
}: {
  user: { name?: string | null };
  preview?: boolean;
}) {
  const [now, setNow] = useState(() => new Date());
  const [selected, setSelected] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(id);
  }, []);
  const shifts = trpc.workforce.list.useQuery(undefined, {
    enabled: !preview,
    retry: 1,
    refetchInterval: 30000,
  });
  const contacts = trpc.contacts.list.useQuery(undefined, {
    enabled: !preview,
    retry: 1,
  });
  const checkins = trpc.checkins.list.useQuery(undefined, {
    enabled: !preview,
    retry: 1,
  });
  const inbox = trpc.inbox.list.useQuery(undefined, {
    enabled: !preview,
    retry: 1,
  });
  const emergency = trpc.emergency.active.useQuery(undefined, {
    enabled: !preview,
    retry: 1,
    refetchInterval: 30000,
  });
  const summary = weekSummary(shifts.data ?? [], selected);
  const dayKey = localDateKey(selected);
  const agenda = summary.shifts
    .filter(s => intersectsLocalDay(s.startsAt, s.endsAt, dayKey))
    .sort((a, b) => +new Date(a.startsAt) - +new Date(b.startsAt));
  const next = (shifts.data ?? [])
    .filter(
      s => s.status !== "cancelled" && !s.checkOutAt && new Date(s.endsAt) > now
    )
    .sort((a, b) => +new Date(a.startsAt) - +new Date(b.startsAt))[0];
  const lastCheckin = [...(checkins.data ?? [])].sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  )[0];
  const metrics = [
    {
      label: "Plantões na semana",
      value: summary.shifts.length,
      detail: "Cadastrados na sua agenda",
      icon: CalendarDays,
      query: shifts,
    },
    {
      label: "Horas previstas",
      value: `${summary.hours.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}h`,
      detail: "Dentro da semana selecionada",
      icon: Clock3,
      query: shifts,
    },
    {
      label: "Plantões concluídos",
      value: summary.completed,
      detail: "Com saída registrada",
      icon: ShieldCheck,
      query: shifts,
    },
    {
      label: "Rede de apoio",
      value: contacts.data?.length ?? 0,
      detail: "Contatos cadastrados",
      icon: Users,
      query: contacts,
    },
  ];
  return (
    <div className="pz-overview">
      <header className="pz-page-heading">
        <div>
          <p className="pz-eyebrow">SUA ROTINA, COM CLAREZA</p>
          <h1>
            Olá, {user.name?.trim().split(" ")[0] || "que bom ter você aqui"}.
          </h1>
          <p>Acompanhe seus plantões e reserve espaço para cuidar de você.</p>
        </div>
        <Link href="/workforce" className="pz-health-primary">
          <Plus size={17} /> Organizar plantões
        </Link>
      </header>
      <div className="pz-metrics">
        {metrics.map(({ label, value, detail, icon: Icon, query }) => (
          <section key={label} className="pz-metric">
            <div>
              <span>{label}</span>
              <Icon size={18} />
            </div>
            <strong>
              {query.isError ? "—" : query.isPending ? "…" : value}
            </strong>
            <small>{query.isError ? "Dados indisponíveis" : detail}</small>
          </section>
        ))}
      </div>
      <div className="pz-overview-grid">
        <div className="space-y-5">
          <section className="pz-agenda pz-health-panel">
            <header className="pz-section-heading">
              <div>
                <p className="pz-eyebrow">PLANEJAMENTO</p>
                <h2>Sua semana</h2>
              </div>
              <div className="flex gap-2 items-center">
                <button
                  className="pz-icon-button"
                  aria-label="Semana anterior"
                  onClick={() =>
                    setSelected(d => {
                      const n = new Date(d);
                      n.setDate(n.getDate() - 7);
                      return n;
                    })
                  }
                >
                  <ChevronLeft size={18} />
                </button>
                <button
                  className="pz-text-button"
                  onClick={() => setSelected(new Date())}
                >
                  Hoje
                </button>
                <button
                  className="pz-icon-button"
                  aria-label="Próxima semana"
                  onClick={() =>
                    setSelected(d => {
                      const n = new Date(d);
                      n.setDate(n.getDate() + 7);
                      return n;
                    })
                  }
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </header>
            <p className="pz-month-label">
              {new Intl.DateTimeFormat("pt-BR", {
                month: "long",
                year: "numeric",
              }).format(selected)}
            </p>
            <div className="pz-week">
              {summary.days.map(d => {
                const key = localDateKey(d);
                const hasShift = summary.shifts.some(s =>
                  intersectsLocalDay(s.startsAt, s.endsAt, key)
                );
                return (
                  <button
                    key={key}
                    aria-pressed={key === dayKey}
                    aria-label={new Intl.DateTimeFormat("pt-BR", {
                      dateStyle: "full",
                    }).format(d)}
                    onClick={() => setSelected(d)}
                    className={key === localDateKey(now) ? "is-today" : ""}
                  >
                    <span>
                      {new Intl.DateTimeFormat("pt-BR", { weekday: "short" })
                        .format(d)
                        .replace(".", "")}
                    </span>
                    <strong>{d.getDate()}</strong>
                    <i className={hasShift ? "has-shift" : ""} />
                  </button>
                );
              })}
            </div>
            <div className="pz-agenda-list">
              {shifts.isError ? (
                <QueryError retry={() => void shifts.refetch()} />
              ) : shifts.isPending ? (
                <p className="pz-empty" role="status">
                  Carregando agenda…
                </p>
              ) : agenda.length ? (
                agenda.map(s => (
                  <Link
                    href={`/workforce?date=${dayKey}`}
                    key={s.id}
                    className="pz-agenda-row"
                  >
                    <span className="pz-agenda-time">
                      {time(s.startsAt)}
                      <small>
                        {time(s.endsAt)}
                        {localDateKey(new Date(s.endsAt)) !==
                        localDateKey(new Date(s.startsAt))
                          ? " (+1 dia)"
                          : ""}
                      </small>
                    </span>
                    <span className="pz-agenda-detail">
                      <strong>{s.title}</strong>
                      <small>{s.professionalName}</small>
                    </span>
                    <span className="pz-status">
                      {s.checkOutAt
                        ? "Concluído"
                        : s.checkInAt
                          ? "Presença registrada"
                          : "Agendado"}
                    </span>
                    <ChevronRight size={16} />
                  </Link>
                ))
              ) : (
                <div className="pz-empty">
                  <CalendarDays size={27} />
                  <strong>Espaço livre na agenda</strong>
                  <p>Nenhum plantão cadastrado para este dia.</p>
                  <Link href={`/workforce?date=${dayKey}`}>
                    Organizar esta data <ArrowRight size={14} />
                  </Link>
                </div>
              )}
            </div>
            <Link
              href={`/workforce?date=${dayKey}`}
              className="pz-panel-footer"
            >
              Ver escala completa <ArrowRight size={16} />
            </Link>
          </section>
          <section className="pz-health-panel">
            <header className="pz-section-heading">
              <div>
                <p className="pz-eyebrow">ACOMPANHAMENTO</p>
                <h2>Notificações recentes</h2>
              </div>
            </header>
            {inbox.isError ? (
              <QueryError retry={() => void inbox.refetch()} />
            ) : inbox.isPending ? (
              <p className="pz-empty">Carregando notificações…</p>
            ) : inbox.data?.length ? (
              <div className="pz-notices">
                {[...inbox.data]
                  .sort(
                    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
                  )
                  .slice(0, 3)
                  .map(item => (
                    <article key={item.id}>
                      <span className="pz-notice-dot" />
                      <div>
                        <strong>{item.title}</strong>
                        <p>{item.body}</p>
                        <small>
                          {new Intl.DateTimeFormat("pt-BR", {
                            dateStyle: "short",
                            timeStyle: "short",
                          }).format(new Date(item.createdAt))}
                        </small>
                      </div>
                    </article>
                  ))}
              </div>
            ) : (
              <p className="pz-empty">Nenhuma notificação por aqui.</p>
            )}
          </section>
        </div>
        <aside className="space-y-5">
          <section className="pz-next-shift">
            <p className="pz-eyebrow">NA SUA AGENDA</p>
            <CalendarDays size={27} />
            <h2>
              {shifts.isError
                ? "Agenda indisponível"
                : shifts.isPending
                  ? "Consultando agenda…"
                  : next
                    ? new Date(next.startsAt) <= now
                      ? "Plantão em andamento"
                      : "Próximo plantão"
                    : "Seu próximo passo"}
            </h2>
            {next && !shifts.isError ? (
              <>
                <h3>{next.title}</h3>
                <p>{next.professionalName}</p>
                <div className="pz-next-date">
                  {new Intl.DateTimeFormat("pt-BR", {
                    day: "numeric",
                    month: "long",
                  }).format(new Date(next.startsAt))}
                  <strong>
                    {time(next.startsAt)} — {time(next.endsAt)}
                  </strong>
                </div>
              </>
            ) : (
              <p>
                {shifts.isError
                  ? "Tente recarregar a agenda para consultar os horários."
                  : "Cadastre um plantão e tenha seus próximos horários sempre à mão."}
              </p>
            )}
            <Link href="/workforce">
              {next ? "Abrir agenda" : "Organizar plantões"}
              <ArrowRight size={17} />
            </Link>
          </section>
          <section className="pz-health-panel p-5">
            <span className="pz-care-icon">
              <HeartPulse size={22} />
            </span>
            <h2 className="mt-4 text-lg font-semibold">E você, como está?</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-6">
              Uma pausa para perceber como você se sente também faz parte da
              rotina.
            </p>
            {checkins.isError ? (
              <QueryError retry={() => void checkins.refetch()} />
            ) : lastCheckin ? (
              <div className="pz-last-checkin">
                <small>ÚLTIMO REGISTRO</small>
                <strong>{lastCheckin.mood}</strong>
                <span>
                  {new Intl.DateTimeFormat("pt-BR", {
                    dateStyle: "short",
                  }).format(new Date(lastCheckin.createdAt))}
                </span>
              </div>
            ) : null}
            <Link href="/checkin" className="pz-health-outline mt-4 w-full">
              Registrar como estou <ArrowRight size={15} />
            </Link>
          </section>
          <Link
            href="/emergency"
            className={`pz-support ${emergency.data ? "is-alert" : ""}`}
          >
            <ShieldCheck size={21} />
            <span>
              <strong>
                {emergency.data
                  ? "Emergência em andamento"
                  : "Sua rede, por perto"}
              </strong>
              <small>
                {emergency.isError
                  ? "Status indisponível. Abrir segurança."
                  : emergency.isPending
                    ? "Consultando status…"
                    : "Acessar recursos de segurança"}
              </small>
            </span>
            <ChevronRight size={16} />
          </Link>
        </aside>
      </div>
    </div>
  );
}

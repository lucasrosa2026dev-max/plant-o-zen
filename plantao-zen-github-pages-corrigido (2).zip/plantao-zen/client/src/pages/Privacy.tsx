import PublicLayout from "@/components/PublicLayout";
export default function Privacy() {
  return (
    <PublicLayout>
      <main className="pz-public-copy">
        <a href="/" className="text-primary underline">
          ← Voltar ao Plantão Zen
        </a>
        <h1 className="mt-8 text-3xl font-bold">
          Aviso de Privacidade — Plantão Zen Health
        </h1>
        <p className="mt-3 text-sm">
          Versão de referência: novembro de 2026. Antes da publicação, o
          responsável pelo aplicativo deve informar sua identidade e contato
          oficial.
        </p>
        <h2 className="mt-8 text-xl font-bold">Quais dados são tratados?</h2>
        <p className="mt-2">
          Dados de cadastro, contato, perfil, escalas, check-ins, mensagens,
          notificações, eventos de emergência e anotações opcionais de cuidado.
          Alguns registros podem conter dados pessoais sensíveis relacionados à
          saúde.
        </p>
        <h2 className="mt-6 text-xl font-bold">Para quê?</h2>
        <p className="mt-2">
          Para autenticar a conta, disponibilizar recursos escolhidos pelo
          usuário, organizar plantões, possibilitar conversas e contatos de
          emergência e manter segurança e integridade do serviço. Cada
          finalidade requer uma hipótese legal aplicável documentada pelo
          controlador; este texto não presume consentimento como única base
          legal.
        </p>
        <h2 className="mt-6 text-xl font-bold">Compartilhamento e retenção</h2>
        <p className="mt-2">
          Mensagens e dados enviados a outros participantes ou contatos poderão
          ser visualizados por esses destinatários. Serviços de hospedagem,
          banco de dados e notificações podem atuar como operadores de dados. O
          responsável deverá publicar a lista de fornecedores, eventual
          transferência internacional e prazos reais de retenção e backup antes
          do lançamento.
        </p>
        <h2 className="mt-6 text-xl font-bold">Seus direitos</h2>
        <p className="mt-2">
          Na seção Meu perfil é possível exportar os registros associados à sua
          conta e solicitar exclusão autenticada. Para correção, informação,
          oposição e demais direitos previstos na LGPD, contate o controlador do
          aplicativo. O canal oficial deverá ser informado antes da publicação.
        </p>
        <h2 className="mt-6 text-xl font-bold">Segurança e incidentes</h2>
        <p className="mt-2">
          O serviço aplica controles de acesso, verificação de senha e proteções
          de sessão. Nenhuma plataforma é imune a riscos. Incidentes relevantes
          devem seguir o procedimento de resposta e as obrigações legais
          aplicáveis.
        </p>
        <p className="mt-8 rounded-lg border p-4 text-sm">
          <strong>Pendente antes da operação pública:</strong> preencher
          nome/razão social e contato do controlador/encarregado, bases legais
          por finalidade, inventário de fornecedores, transferências, retenção e
          canal de atendimento LGPD.
        </p>
      </main>
    </PublicLayout>
  );
}

import { Link } from "wouter";
import { ArrowLeft, Compass } from "lucide-react";
import PublicLayout from "@/components/PublicLayout";
export default function NotFound() {
  return (
    <PublicLayout>
      <main className="mx-auto max-w-lg py-20 text-center">
        <Compass size={45} className="mx-auto text-primary" strokeWidth={1.2} />
        <p className="pz-eyebrow mt-7">PÁGINA NÃO ENCONTRADA · 404</p>
        <h1 className="text-3xl font-semibold tracking-tight">
          Vamos voltar ao seu caminho.
        </h1>
        <p className="mt-5 text-muted-foreground leading-7">
          Este endereço não está disponível. Volte ao início para continuar no
          Plantão Zen.
        </p>
        <Link href="/" className="pz-health-primary mt-8">
          <ArrowLeft size={17} /> Voltar ao início
        </Link>
      </main>
    </PublicLayout>
  );
}

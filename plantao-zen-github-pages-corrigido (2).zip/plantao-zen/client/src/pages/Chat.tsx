import PageHeading from "@/components/PageHeading";
import { useEffect, useState } from "react";
import {
  AlertTriangle,
  Ban,
  Check,
  CheckCheck,
  ChevronRight,
  CircleHelp,
  MessageCircle,
  Search,
  Send,
  ShieldCheck,
  UserRound,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { MessagesPage as QuickMessagesPage } from "@/pages/Wellbeing";
import { useLocation } from "wouter";

type SearchResult = { publicChatId: string; name: string };
type Conversation = {
  id: number;
  status: "pending" | "accepted" | "declined";
  direction: "incoming" | "outgoing";
  otherName: string;
  lastMessage: string;
  lastMessageAt: Date | string;
  lastMessageIsMine: boolean;
  lastMessageReadAt: Date | string | null;
};
type ReportReason = "harassment" | "spam" | "safety" | "other";

function Panel({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`pz-card rounded-2xl border border-border bg-card shadow-sm ${className}`}
    >
      {children}
    </section>
  );
}

function PrimaryButton({
  children,
  onClick,
  type = "button",
  disabled = false,
  variant = "primary",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
  variant?: "primary" | "soft" | "danger" | "ghost";
}) {
  const styles = {
    primary: "bg-primary text-white hover:bg-primary",
    soft: "bg-muted text-primary hover:bg-muted",
    danger: "bg-[#b84d4d] text-white hover:bg-[#a94343]",
    ghost: "bg-transparent text-muted-foreground hover:bg-muted",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`pz-button inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${styles[variant]}`}
    >
      {children}
    </button>
  );
}

function when(value: Date | string) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}

export function MessagesPage({ isAdmin = false }: { isAdmin?: boolean }) {
  const [location, setLocation] = useLocation();
  const inModeration = location === "/messages/moderation";
  const [showQuickMessages, setShowQuickMessages] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [target, setTarget] = useState<SearchResult | null>(null);
  const [firstMessage, setFirstMessage] = useState("");
  const [draft, setDraft] = useState("");
  const [reportMessageId, setReportMessageId] = useState<number | undefined>();
  const [reportReason, setReportReason] = useState<ReportReason>("safety");
  const [reportDetails, setReportDetails] = useState("");

  const utils = trpc.useUtils();
  const settings = trpc.chat.settings.get.useQuery();
  const conversations = trpc.chat.conversations.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const directory = trpc.chat.directorySearch.useQuery(
    { query: search.trim() },
    {
      enabled:
        Boolean(settings.data?.discoverable) && search.trim().length >= 2,
    }
  );
  const activeConversation = (conversations.data ?? []).find(
    item => item.id === selectedId
  ) as Conversation | undefined;
  const thread = trpc.chat.thread.useQuery(
    { conversationId: selectedId ?? 0 },
    {
      enabled: selectedId !== null,
      refetchInterval: selectedId === null ? false : 10_000,
    }
  );
  const blocks = trpc.chat.blocked.list.useQuery();
  const adminReports = trpc.chat.adminReports.useQuery(undefined, {
    enabled: isAdmin && inModeration,
  });
  const markRead = trpc.chat.markRead.useMutation();
  const saveSettings = trpc.chat.settings.save.useMutation({
    onSuccess: () => utils.chat.settings.get.invalidate(),
  });
  const start = trpc.chat.start.useMutation();
  const send = trpc.chat.send.useMutation();
  const respond = trpc.chat.respond.useMutation();
  const block = trpc.chat.block.useMutation();
  const unblock = trpc.chat.blocked.remove.useMutation({
    onSuccess: () => utils.chat.blocked.list.invalidate(),
  });
  const report = trpc.chat.report.useMutation();
  const review = trpc.chat.reviewReport.useMutation({
    onSuccess: () => utils.chat.adminReports.invalidate(),
  });

  useEffect(() => {
    if (selectedId === null && conversations.data?.length) {
      const preferred =
        conversations.data.find(
          item => item.status === "pending" && item.direction === "incoming"
        ) ??
        conversations.data.find(item => item.status === "accepted") ??
        conversations.data[0];
      if (preferred) setSelectedId(preferred.id);
    }
  }, [selectedId, conversations.data]);

  useEffect(() => {
    if (selectedId !== null && thread.data) {
      void markRead
        .mutateAsync({ conversationId: selectedId })
        .then(() => utils.chat.conversations.invalidate())
        .catch(() => undefined);
    }
    // Mark incoming messages read when a new thread/message is opened; invalidating the list does not change this key.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId, thread.data?.messages.at(-1)?.id]);

  const discoverable = Boolean(settings.data?.discoverable);
  const accepted = activeConversation?.status === "accepted";
  const threadMessages = thread.data?.messages ?? [];

  const toggleDiscoverability = async () => {
    try {
      await saveSettings.mutateAsync({ discoverable: !discoverable });
      toast(
        !discoverable
          ? "Sua participação no diretório foi ativada."
          : "Você deixou de aparecer para novas buscas."
      );
      await utils.chat.directorySearch.invalidate();
    } catch {
      toast.error("Não foi possível atualizar sua preferência de chat.");
    }
  };

  const submitStart = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!target) return;
    try {
      const result = await start.mutateAsync({
        targetPublicChatId: target.publicChatId,
        message: firstMessage,
      });
      setTarget(null);
      setFirstMessage("");
      setSearch("");
      setSelectedId(result.conversationId);
      setShowQuickMessages(false);
      setLocation("/messages");
      await Promise.all([
        utils.chat.conversations.invalidate(),
        utils.chat.thread.invalidate({ conversationId: result.conversationId }),
      ]);
      if (result.status === "accepted") toast.success("Mensagem enviada.");
      else if (result.created)
        toast.success(
          "Pedido de conversa enviado. A outra pessoa precisa aceitar para continuar."
        );
      else toast("Já existe um pedido pendente com esta pessoa.");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível iniciar a conversa."
      );
    }
  };

  const submitMessage = async (event: React.FormEvent) => {
    event.preventDefault();
    if (selectedId === null || !draft.trim()) return;
    try {
      await send.mutateAsync({ conversationId: selectedId, message: draft });
      setDraft("");
      await Promise.all([
        utils.chat.thread.invalidate({ conversationId: selectedId }),
        utils.chat.conversations.invalidate(),
      ]);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "A mensagem não foi enviada. Verifique a conexão e tente novamente."
      );
    }
  };

  const respondToRequest = async (action: "accept" | "decline") => {
    if (selectedId === null) return;
    try {
      await respond.mutateAsync({ conversationId: selectedId, action });
      await Promise.all([
        utils.chat.thread.invalidate({ conversationId: selectedId }),
        utils.chat.conversations.invalidate(),
      ]);
      toast.success(
        action === "accept"
          ? "Pedido aceito. A conversa está aberta."
          : "Pedido recusado."
      );
      if (action === "decline") setSelectedId(null);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível responder ao pedido."
      );
    }
  };

  const blockParticipant = async () => {
    if (
      selectedId === null ||
      !window.confirm(
        "Bloquear esta pessoa? Ela não poderá enviar novas mensagens e a conversa será ocultada."
      )
    )
      return;
    try {
      await block.mutateAsync({ conversationId: selectedId });
      setSelectedId(null);
      await Promise.all([
        utils.chat.conversations.invalidate(),
        utils.chat.blocked.list.invalidate(),
      ]);
      toast.success(
        "Pessoa bloqueada. Você pode desbloqueá-la nas opções abaixo."
      );
    } catch {
      toast.error("Não foi possível bloquear esta pessoa.");
    }
  };

  const submitReport = async (event: React.FormEvent) => {
    event.preventDefault();
    if (selectedId === null) return;
    try {
      await report.mutateAsync({
        conversationId: selectedId,
        messageId:
          reportMessageId && reportMessageId > 0 ? reportMessageId : undefined,
        reason: reportReason,
        details: reportDetails || undefined,
      });
      setReportMessageId(undefined);
      setReportDetails("");
      toast.success("Denúncia enviada para análise administrativa.");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível enviar a denúncia."
      );
    }
  };

  const chooseTab = (tab: "chat" | "quick" | "moderation") => {
    setShowQuickMessages(tab === "quick");
    setLocation(tab === "moderation" ? "/messages/moderation" : "/messages");
  };

  if (inModeration && !isAdmin)
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
        Esta área está disponível apenas para a equipe administradora.
      </div>
    );
  if (showQuickMessages && !inModeration)
    return (
      <div>
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-sm font-bold text-primary">Mensagens rápidas</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Envio para contatos vinculados à sua conta.
            </p>
          </div>
          <PrimaryButton variant="soft" onClick={() => chooseTab("chat")}>
            <MessageCircle className="h-4 w-4" /> Abrir conversas
          </PrimaryButton>
        </div>
        <QuickMessagesPage />
      </div>
    );

  return (
    <div className="max-w-6xl">
      <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <PageHeading
          eyebrow="Conversa com consentimento"
          title="Mensagens"
          description="Encontre pessoas que também ativaram o chat. Toda conversa nova começa com um pedido que a outra pessoa pode aceitar ou recusar."
        />
        <div className="flex flex-wrap gap-2">
          <PrimaryButton
            variant={!inModeration ? "primary" : "soft"}
            onClick={() => chooseTab("chat")}
          >
            <MessageCircle className="h-4 w-4" /> Conversas
          </PrimaryButton>
          <PrimaryButton variant="soft" onClick={() => chooseTab("quick")}>
            <Send className="h-4 w-4" /> Mensagens rápidas
          </PrimaryButton>
          {isAdmin && (
            <PrimaryButton
              variant={inModeration ? "primary" : "soft"}
              onClick={() => chooseTab("moderation")}
            >
              <ShieldCheck className="h-4 w-4" /> Denúncias
            </PrimaryButton>
          )}
        </div>
      </div>

      {inModeration ? (
        <Panel className="p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-warning-soft text-[#b84d4d]">
              <AlertTriangle className="h-5 w-5" />
            </span>
            <div>
              <h3 className="text-xl font-bold text-foreground">
                Denúncias para revisão
              </h3>
              <p className="text-sm text-muted-foreground">
                Somente administradores podem ver este conteúdo.
              </p>
            </div>
          </div>
          {adminReports.isLoading ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Carregando denúncias...
            </p>
          ) : (adminReports.data ?? []).length === 0 ? (
            <p className="rounded-xl bg-muted p-5 text-sm text-muted-foreground">
              Não há denúncias para exibir.
            </p>
          ) : (
            <div className="grid gap-4">
              {adminReports.data?.map(item => (
                <article
                  key={item.id}
                  className="rounded-xl border border-border p-5"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-bold text-foreground">
                        {item.reporterName} denunciou {item.reportedName}
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {item.reason} · {when(item.createdAt)} · estado:{" "}
                        {item.status}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {item.status === "open" && (
                        <>
                          <PrimaryButton
                            variant="soft"
                            onClick={() =>
                              void review.mutateAsync({
                                reportId: item.id,
                                status: "reviewed",
                              })
                            }
                          >
                            <Check className="h-4 w-4" /> Revisada
                          </PrimaryButton>
                          <PrimaryButton
                            variant="danger"
                            onClick={() =>
                              void review.mutateAsync({
                                reportId: item.id,
                                status: "actioned",
                              })
                            }
                          >
                            Ação tomada
                          </PrimaryButton>
                        </>
                      )}
                    </div>
                  </div>
                  {item.message && (
                    <blockquote className="mt-4 rounded-xl bg-muted p-4 text-sm leading-6 text-muted-foreground">
                      “{item.message}”
                    </blockquote>
                  )}
                  {item.details && (
                    <p className="mt-3 text-sm leading-6 text-muted-foreground">
                      Observação: {item.details}
                    </p>
                  )}
                </article>
              ))}
            </div>
          )}
        </Panel>
      ) : (
        <>
          <Panel className="mb-5 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-muted text-primary">
                <Users className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-foreground">
                  Participar do diretório de chat
                </p>
                <p className="mt-1 max-w-2xl text-sm leading-5 text-muted-foreground">
                  Quando ativo, outras pessoas podem encontrar seu nome. Seu
                  e-mail, telefone e informações de cuidado não aparecem na
                  busca. Desativar impede novas buscas, mas não apaga conversas
                  já existentes.
                </p>
              </div>
            </div>
            <button
              role="switch"
              aria-checked={discoverable}
              aria-label="Permitir que outras pessoas me encontrem no chat"
              onClick={() => void toggleDiscoverability()}
              disabled={saveSettings.isPending}
              className={`relative h-8 w-14 shrink-0 rounded-full transition ${discoverable ? "bg-primary" : "bg-muted"}`}
            >
              <span
                className={`absolute top-1 h-6 w-6 rounded-full bg-card shadow transition ${discoverable ? "left-7" : "left-1"}`}
              />
            </button>
          </Panel>

          {discoverable && settings.data?.publicChatId && (
            <Panel className="mb-5 flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.15em] text-primary">
                  Seu código de chat
                </p>
                <p className="mt-2 font-mono text-lg font-bold tracking-[0.08em] text-primary">
                  {settings.data.publicChatId}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  É diferente do ID usado para vincular contatos.
                </p>
              </div>
              <PrimaryButton
                variant="soft"
                onClick={() => {
                  const code = settings.data?.publicChatId;
                  if (!code) return;
                  void navigator.clipboard
                    ?.writeText(code)
                    .then(() => toast("Código de chat copiado."));
                }}
              >
                Copiar código
              </PrimaryButton>
            </Panel>
          )}

          {discoverable && (
            <Panel className="mb-5 p-5">
              <div className="flex items-start gap-3">
                <Search className="mt-1 h-5 w-5 text-primary" />
                <div className="w-full">
                  <h3 className="font-bold text-foreground">
                    Encontrar alguém
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Pesquise pelo nome (2 caracteres ou mais). Você pode iniciar
                    até 5 novos pedidos por hora.
                  </p>
                  <div className="mt-4">
                    <input
                      value={search}
                      onChange={event => setSearch(event.target.value)}
                      maxLength={80}
                      placeholder="Digite o nome..."
                      aria-label="Buscar pessoas no diretório"
                      className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
                    />
                  </div>
                  {search.trim().length >= 2 && (
                    <div className="mt-3 grid gap-2">
                      {directory.isLoading ? (
                        <p className="py-2 text-sm text-muted-foreground">
                          Buscando...
                        </p>
                      ) : (directory.data ?? []).length === 0 ? (
                        <p className="rounded-xl bg-muted p-4 text-sm text-muted-foreground">
                          Nenhuma pessoa encontrada com chat ativado.
                        </p>
                      ) : (
                        directory.data?.map(person => (
                          <div
                            key={person.publicChatId}
                            className="flex items-center gap-3 rounded-xl border border-border p-3"
                          >
                            <span className="grid h-10 w-10 place-items-center rounded-full bg-muted text-primary">
                              <UserRound className="h-5 w-5" />
                            </span>
                            <span className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
                              <span className="block truncate">
                                {person.name}
                              </span>
                              <span className="mt-0.5 block truncate font-mono text-[11px] font-medium text-muted-foreground">
                                ID de chat: {person.publicChatId}
                              </span>
                            </span>
                            <PrimaryButton
                              variant="soft"
                              onClick={() => {
                                setTarget(person);
                                setFirstMessage("");
                              }}
                            >
                              Conversar <ChevronRight className="h-4 w-4" />
                            </PrimaryButton>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                  {target && (
                    <form
                      onSubmit={submitStart}
                      className="mt-4 grid gap-3 rounded-xl border border-border bg-muted p-4"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-bold text-foreground">
                          Pedido para {target.name}
                        </p>
                        <button
                          type="button"
                          aria-label="Fechar pedido"
                          onClick={() => setTarget(null)}
                          className="rounded-lg p-2 text-muted-foreground hover:bg-card"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <label className="grid gap-2 text-sm font-semibold text-foreground">
                        Sua primeira mensagem
                        <textarea
                          value={firstMessage}
                          onChange={event =>
                            setFirstMessage(event.target.value)
                          }
                          required
                          maxLength={2000}
                          rows={3}
                          placeholder="Escreva uma mensagem breve para acompanhar o pedido..."
                          className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary"
                        />
                        <span className="text-xs font-normal text-muted-foreground">
                          Até 2.000 caracteres. A conversa contínua só abre se a
                          pessoa aceitar.
                        </span>
                      </label>
                      <PrimaryButton
                        type="submit"
                        disabled={start.isPending || !firstMessage.trim()}
                      >
                        <Send className="h-4 w-4" />{" "}
                        {start.isPending
                          ? "Enviando pedido..."
                          : "Enviar pedido"}
                      </PrimaryButton>
                    </form>
                  )}
                </div>
              </div>
            </Panel>
          )}

          <div className="grid gap-5 lg:grid-cols-[minmax(260px,0.75fr)_minmax(0,1.55fr)]">
            <Panel className="overflow-hidden">
              <div className="flex items-center justify-between border-b border-border p-5">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[.15em] text-muted-foreground">
                    Sua caixa
                  </p>
                  <h3 className="mt-1 text-lg font-bold text-foreground">
                    Conversas e pedidos
                  </h3>
                </div>
                <button
                  aria-label="Atualizar conversas"
                  onClick={() => void conversations.refetch()}
                  className="rounded-lg p-2 text-primary hover:bg-muted"
                >
                  <MessageCircle className="h-4 w-4" />
                </button>
              </div>
              <div className="max-h-[620px] overflow-y-auto p-3">
                {conversations.isError ? (
                  <div className="pz-query-error" role="status">
                    Não foi possível carregar as conversas.
                    <button onClick={() => void conversations.refetch()}>
                      Tentar novamente
                    </button>
                  </div>
                ) : conversations.isLoading ? (
                  <p className="p-5 text-center text-sm text-muted-foreground">
                    Carregando conversas...
                  </p>
                ) : (conversations.data ?? []).length === 0 ? (
                  <div className="grid justify-items-center gap-3 px-4 py-10 text-center">
                    <MessageCircle className="h-8 w-8 text-muted-foreground" />
                    <p className="font-bold text-muted-foreground">
                      Ainda não há conversas
                    </p>
                    <p className="text-sm leading-5 text-muted-foreground">
                      Ative o diretório para encontrar alguém ou aguarde um
                      pedido.
                    </p>
                  </div>
                ) : (
                  <div className="grid gap-2">
                    {(conversations.data as Conversation[]).map(item => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setSelectedId(item.id);
                          setShowQuickMessages(false);
                          setLocation("/messages");
                        }}
                        className={`w-full rounded-xl border p-3 text-left transition ${selectedId === item.id ? "border-border bg-muted" : "border-transparent hover:border-border hover:bg-muted"}`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-bold text-foreground">
                              {item.otherName}
                            </p>
                            <p className="mt-1 truncate text-xs text-muted-foreground">
                              {item.lastMessage || "Pedido de conversa"}
                            </p>
                          </div>
                          <span className="shrink-0 text-[10px] text-muted-foreground">
                            {when(item.lastMessageAt)}
                          </span>
                        </div>
                        <div className="mt-2 flex items-center gap-2">
                          {item.status === "pending" ? (
                            <span
                              className={`rounded-full px-2 py-1 text-[10px] font-bold ${item.direction === "incoming" ? "bg-warning-soft text-warning-ink" : "bg-muted text-primary"}`}
                            >
                              {item.direction === "incoming"
                                ? "Pedido recebido"
                                : "Aguardando aceite"}
                            </span>
                          ) : (
                            <span className="rounded-full bg-success-soft px-2 py-1 text-[10px] font-bold text-success-ink">
                              Conversa ativa
                            </span>
                          )}
                          {item.status === "accepted" &&
                            item.lastMessageIsMine &&
                            item.lastMessageReadAt && (
                              <CheckCheck
                                aria-label="Mensagem lida"
                                className="h-3.5 w-3.5 text-primary"
                              />
                            )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </Panel>

            <Panel className="flex min-h-[460px] flex-col overflow-hidden">
              {activeConversation ? (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-4 sm:p-5">
                    <div className="flex min-w-0 items-center gap-3">
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-muted text-primary">
                        <UserRound className="h-5 w-5" />
                      </span>
                      <div className="min-w-0">
                        <h3 className="truncate font-bold text-foreground">
                          {activeConversation.otherName}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          {activeConversation.status === "pending"
                            ? activeConversation.direction === "incoming"
                              ? "Pedido aguardando sua resposta"
                              : "Pedido aguardando aceite"
                            : "Conversa privada entre vocês"}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      <button
                        onClick={() => setReportMessageId(0)}
                        className="min-h-10 rounded-lg px-3 text-xs font-semibold text-danger-ink hover:bg-danger-soft"
                      >
                        Denunciar
                      </button>
                      <button
                        onClick={() => void blockParticipant()}
                        className="min-h-10 rounded-lg px-3 text-xs font-semibold text-danger-ink hover:bg-danger-soft"
                      >
                        <Ban className="mr-1 inline h-4 w-4" /> Bloquear
                      </button>
                    </div>
                  </div>
                  {activeConversation.status === "pending" &&
                    activeConversation.direction === "incoming" && (
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-warning-soft px-5 py-4">
                        <div>
                          <p className="text-sm font-bold text-warning-ink">
                            Pedido de conversa
                          </p>
                          <p className="mt-1 text-xs leading-5 text-warning-ink">
                            Leia a primeira mensagem e escolha se deseja abrir a
                            conversa.
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <PrimaryButton
                            variant="soft"
                            onClick={() => void respondToRequest("decline")}
                            disabled={respond.isPending}
                          >
                            <X className="h-4 w-4" /> Recusar
                          </PrimaryButton>
                          <PrimaryButton
                            onClick={() => void respondToRequest("accept")}
                            disabled={respond.isPending}
                          >
                            <Check className="h-4 w-4" /> Aceitar
                          </PrimaryButton>
                        </div>
                      </div>
                    )}
                  {activeConversation.status === "pending" &&
                    activeConversation.direction === "outgoing" && (
                      <div className="border-b border-border bg-muted px-5 py-3 text-sm text-muted-foreground">
                        Seu pedido foi enviado. Você receberá uma resposta
                        quando a outra pessoa abrir o Plantão Zen.
                      </div>
                    )}
                  <div className="flex-1 space-y-3 overflow-y-auto bg-muted p-4 sm:p-5">
                    {thread.isError ? (
                      <div className="pz-query-error" role="status">
                        Não foi possível carregar as mensagens.
                        <button onClick={() => void thread.refetch()}>
                          Tentar novamente
                        </button>
                      </div>
                    ) : thread.isLoading ? (
                      <p className="py-8 text-center text-sm text-muted-foreground">
                        Carregando mensagens...
                      </p>
                    ) : threadMessages.length === 0 ? (
                      <p className="py-8 text-center text-sm text-muted-foreground">
                        Não há mensagens nesta conversa.
                      </p>
                    ) : (
                      threadMessages.map(message => {
                        const mine = message.isMine;
                        return (
                          <div
                            key={message.id}
                            className={`flex ${mine ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-[88%] rounded-2xl px-4 py-3 sm:max-w-[75%] ${mine ? "rounded-br-md bg-primary text-white" : "rounded-bl-md border border-border bg-card text-foreground"}`}
                            >
                              <p className="whitespace-pre-wrap break-words text-sm leading-6">
                                {message.body}
                              </p>
                              <div
                                className={`mt-2 flex items-center justify-end gap-2 text-[10px] ${mine ? "text-white/70" : "text-muted-foreground"}`}
                              >
                                <time>{when(message.createdAt)}</time>
                                {mine && message.readAt && (
                                  <CheckCheck
                                    aria-label="Lida"
                                    className="h-3.5 w-3.5"
                                  />
                                )}
                                {!mine &&
                                  activeConversation.status === "accepted" && (
                                    <button
                                      onClick={() =>
                                        setReportMessageId(message.id)
                                      }
                                      className="rounded px-1 underline underline-offset-2"
                                    >
                                      Denunciar
                                    </button>
                                  )}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                  {reportMessageId !== undefined && (
                    <form
                      onSubmit={submitReport}
                      className="grid gap-3 border-t border-border bg-danger-soft p-4"
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-bold text-danger-ink">
                          Denunciar {reportMessageId ? "mensagem" : "conversa"}
                        </p>
                        <button
                          type="button"
                          onClick={() => setReportMessageId(undefined)}
                          aria-label="Cancelar denúncia"
                          className="rounded p-2"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <select
                        value={reportReason}
                        onChange={event =>
                          setReportReason(event.target.value as ReportReason)
                        }
                        className="h-10 rounded-lg border border-border bg-card px-3 text-sm"
                      >
                        <option value="safety">Preocupação de segurança</option>
                        <option value="harassment">Assédio</option>
                        <option value="spam">Spam</option>
                        <option value="other">Outro motivo</option>
                      </select>
                      <textarea
                        value={reportDetails}
                        onChange={event => setReportDetails(event.target.value)}
                        maxLength={500}
                        rows={2}
                        placeholder="Detalhe opcional (até 500 caracteres)"
                        className="rounded-lg border border-border bg-card p-3 text-sm"
                      />
                      <PrimaryButton
                        type="submit"
                        variant="danger"
                        disabled={report.isPending}
                      >
                        <AlertTriangle className="h-4 w-4" /> Enviar denúncia
                      </PrimaryButton>
                    </form>
                  )}
                  {accepted && (
                    <form
                      onSubmit={submitMessage}
                      className="flex items-end gap-2 border-t border-border bg-card p-3 sm:p-4"
                    >
                      <label className="sr-only" htmlFor="chat-message">
                        Sua mensagem
                      </label>
                      <textarea
                        id="chat-message"
                        value={draft}
                        onChange={event => setDraft(event.target.value)}
                        maxLength={2000}
                        rows={2}
                        placeholder="Escreva uma mensagem..."
                        className="min-h-11 max-h-32 flex-1 resize-y rounded-xl border border-border bg-card px-3 py-2.5 text-sm outline-none focus:border-primary"
                      />
                      <PrimaryButton
                        type="submit"
                        disabled={send.isPending || !draft.trim()}
                      >
                        <Send className="h-4 w-4" />
                        <span className="hidden sm:inline">Enviar</span>
                      </PrimaryButton>
                    </form>
                  )}
                </>
              ) : (
                <div className="grid flex-1 place-items-center p-8 text-center">
                  <div>
                    <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-muted text-primary">
                      <MessageCircle className="h-6 w-6" />
                    </span>
                    <h3 className="mt-4 font-bold text-foreground">
                      Escolha uma conversa
                    </h3>
                    <p className="mt-1 max-w-sm text-sm leading-5 text-muted-foreground">
                      Selecione um pedido ou uma conversa na lista. As mensagens
                      só ficam disponíveis às duas pessoas participantes.
                    </p>
                  </div>
                </div>
              )}
            </Panel>
          </div>

          {(blocks.data ?? []).length > 0 && (
            <Panel className="mt-5 p-5">
              <h3 className="font-bold text-foreground">Pessoas bloqueadas</h3>
              <div className="mt-3 grid gap-2">
                {blocks.data?.map(item => (
                  <div
                    key={item.publicChatId}
                    className="flex items-center gap-3 rounded-xl bg-muted p-3"
                  >
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold text-muted-foreground">
                      {item.name}
                    </span>
                    <button
                      onClick={() =>
                        void unblock.mutateAsync({
                          publicChatId: item.publicChatId,
                        })
                      }
                      className="min-h-10 rounded-lg px-3 text-sm font-semibold text-primary hover:bg-card"
                    >
                      Desbloquear
                    </button>
                  </div>
                ))}
              </div>
            </Panel>
          )}
          <div className="mt-5 flex items-start gap-3 rounded-xl border border-border bg-muted p-4">
            <CircleHelp className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-xs leading-5 text-muted-foreground">
              Este chat é uma ferramenta de comunicação entre usuários. Não é
              atendimento profissional nem serviço de emergência. Em risco
              imediato, use o modo Emergência ou os serviços locais. Não envie
              dados clínicos, senhas ou informações financeiras.
            </p>
          </div>
        </>
      )}
    </div>
  );
}

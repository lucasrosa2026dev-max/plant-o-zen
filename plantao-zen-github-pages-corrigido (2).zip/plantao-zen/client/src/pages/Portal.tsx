import PageHeading from "@/components/PageHeading";
import Shell from "@/components/AppShell";
import Overview from "./Overview";
import NativePush from "@/components/NativePush";
import LoginScreen from "./LoginScreen";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import type { Contact } from "@shared/types";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { startEmergencyAlert, stopEmergencyAlert } from "@/lib/emergency";
import {
  getDeviceCapabilities,
  requestNotificationPermission,
  showEmergencyNotification,
} from "@/lib/notifications";
import {
  Activity,
  BarChart3,
  AlertCircle,
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  Copy,
  Clock3,
  Link2,
  MessageCircle,
  Moon,
  Phone,
  Plus,
  Radio,
  RefreshCw,
  Settings,
  ShieldCheck,
  Sun,
  Smartphone,
  Trash2,
  Users,
  Watch,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { toast } from "sonner";
import NotFound from "@/pages/NotFound";
import { CheckinPage, SafetyPlanPage } from "@/pages/Wellbeing";
import { MessagesPage } from "@/pages/Chat";
import Workforce from "./Workforce";
import SecurityControls from "./SecurityControls";
import WatchPairing from "@/components/WatchPairing";
import About from "./About";
import { useTheme } from "@/contexts/ThemeContext";

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "Sem registro";
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function initials(name: string) {
  return (
    name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map(part => part[0])
      .join("")
      .toUpperCase() || "PZ"
  );
}

function Card({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`pz-card rounded-2xl border border-border bg-card shadow-sm ${className}`}
    >
      {children}
    </section>
  );
}

function Button({
  children,
  onClick,
  variant = "primary",
  type = "button",
  disabled = false,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "soft";
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
}) {
  const styles = {
    primary: "bg-primary text-white hover:bg-primary shadow-sm",
    secondary: "bg-[#2f4d5b] text-white hover:bg-[#263f4b]",
    ghost: "bg-transparent text-muted-foreground hover:bg-muted",
    danger: "bg-[#bf4c4c] text-white hover:bg-[#aa3e3e]",
    soft: "bg-muted text-primary hover:bg-muted",
  } as const;
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`pz-button inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-semibold text-foreground">
      <span>{label}</span>
      {children}
      {hint && (
        <span className="text-xs font-normal text-muted-foreground">
          {hint}
        </span>
      )}
    </label>
  );
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`pz-input h-11 w-full rounded-xl border border-border bg-card px-3 text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/15 ${props.className ?? ""}`}
    />
  );
}

function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`pz-input min-h-28 w-full resize-y rounded-xl border border-border bg-card px-3 py-3 text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/15 ${props.className ?? ""}`}
    />
  );
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "neutral" | "success" | "warning" | "danger" | "info";
}) {
  const tones = {
    neutral: "bg-muted text-muted-foreground",
    success: "bg-success-soft text-success-ink",
    warning: "bg-warning-soft text-warning-ink",
    danger: "bg-danger-soft text-danger-ink",
    info: "bg-muted text-primary",
  } as const;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

function SectionHeading({
  title,
  eyebrow,
  action,
  onClick,
}: {
  title: string;
  eyebrow: string;
  action?: string;
  onClick?: () => void;
}) {
  return (
    <div className="flex items-end justify-between gap-3">
      <div>
        <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">
          {eyebrow}
        </p>
        <h3 className="mt-1 text-lg font-bold text-foreground">{title}</h3>
      </div>
      {action && (
        <button onClick={onClick} className="text-xs font-bold text-primary">
          {action}
        </button>
      )}
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  text,
  action,
  onClick,
}: {
  icon: LucideIcon;
  title: string;
  text: string;
  action?: string;
  onClick?: () => void;
}) {
  return (
    <div className="grid justify-items-center gap-3 py-9 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-warning-ink">
        <Icon className="h-5 w-5" />
      </span>
      <div>
        <p className="font-bold text-muted-foreground">{title}</p>
        <p className="mt-1 max-w-sm text-sm leading-5 text-muted-foreground">
          {text}
        </p>
      </div>
      {action && (
        <Button variant="soft" onClick={onClick}>
          {action}
        </Button>
      )}
    </div>
  );
}

function EmergencyPage() {
  const contactsQuery = trpc.contacts.list.useQuery();
  const activeQuery = trpc.emergency.active.useQuery();
  const preferencesQuery = trpc.preferences.get.useQuery();
  const utils = trpc.useUtils();
  const trigger = trpc.emergency.trigger.useMutation({
    onSuccess: async () => {
      await utils.emergency.active.invalidate();
      await utils.emergency.history.invalidate();
    },
  });
  const updateNotification = trpc.emergency.updateNotification.useMutation({
    onSuccess: () => utils.emergency.active.invalidate(),
  });
  const cancel = trpc.emergency.cancel.useMutation({
    onSuccess: async () => {
      stopEmergencyAlert();
      await utils.emergency.active.invalidate();
      await utils.emergency.history.invalidate();
      toast("Emergência cancelada.");
    },
  });
  const callStarted = trpc.emergency.callStarted.useMutation();
  const callNotCompleted = trpc.emergency.callNotCompleted.useMutation();
  const [notes, setNotes] = useState("");
  const active = activeQuery.data;
  const emergencyContacts = (contactsQuery.data ?? []).filter(
    contact => contact.isEmergency === 1
  );
  const soundEnabled = preferencesQuery.data?.soundEnabled !== 0;
  const notificationsEnabled =
    preferencesQuery.data?.notificationsEnabled !== 0;
  const confirmCall = preferencesQuery.data?.callConfirmationRequired !== 0;
  useEffect(() => {
    if (active && soundEnabled) startEmergencyAlert();
    else stopEmergencyAlert();
    return () => stopEmergencyAlert();
  }, [active?.id, soundEnabled]);
  const triggerEmergency = async () => {
    if (active || trigger.isPending) return;
    const linkedRecipientCount = emergencyContacts.filter(contact =>
      Boolean(contact.linkedOpenId)
    ).length;
    const detail = notes.trim() || "Preciso de ajuda agora.";
    const confirmed = window.confirm(`Acionar o Plantão Zen agora?

O evento será registrado na sua conta. ${soundEnabled ? "O som funciona somente enquanto este app estiver aberto." : "O som está desativado."} ${linkedRecipientCount > 0 ? `${linkedRecipientCount} contato(s) vinculado(s) poderão receber uma mensagem dentro do app.` : "Nenhum contato de emergência vinculado poderá receber mensagem pelo app."}

SMS e ligações não são enviados automaticamente.

Mensagem: “${detail}”`);
    if (!confirmed) return;
    try {
      const result = await trigger.mutateAsync({ message: detail });
      if (!result.event)
        throw new Error("A emergência não pôde ser registrada.");
      if (soundEnabled) startEmergencyAlert();
      setNotes("");
      if (result.duplicate) {
        toast(
          "Já existe um alerta ativo. Confira os contatos e o status abaixo."
        );
        await utils.emergency.active.invalidate();
        return;
      }
      if (result.notificationsSent > 0)
        toast(
          `${result.notificationsSent} contato(s) vinculado(s) recebeu(ram) uma mensagem no app.`
        );
      try {
        const permission = notificationsEnabled
          ? getDeviceCapabilities().notificationPermission === "default"
            ? await requestNotificationPermission()
            : getDeviceCapabilities().notificationPermission
          : "unsupported";
        const webSent =
          permission === "granted"
            ? await showEmergencyNotification(
                "Uma emergência foi acionada. Abra o Plantão Zen para ver os contatos de confiança."
              )
            : false;
        await updateNotification.mutateAsync({
          id: result.event.id,
          status: webSent
            ? "sent"
            : permission === "unsupported"
              ? "unsupported"
              : "failed",
        });
      } catch {
        toast(
          "O alerta foi registrado, mas não foi possível confirmar a notificação deste aparelho."
        );
      }
      await utils.emergency.active.invalidate();
      await utils.emergency.history.invalidate();
    } catch {
      toast(
        "Não foi possível confirmar o status do alerta. Atualize a tela e confira antes de tentar novamente."
      );
      await utils.emergency.active.invalidate();
    }
  };
  const cancelEmergency = async () => {
    if (!active) return;
    if (!window.confirm("Cancelar o alerta de emergência?")) return;
    await cancel.mutateAsync({ id: active.id });
  };
  const call = async (contact: Contact) => {
    if (
      confirmCall &&
      !window.confirm(`Abrir o telefone para ligar para ${contact.name}?`)
    ) {
      if (active) await callNotCompleted.mutateAsync({ id: active.id });
      return;
    }
    if (active) await callStarted.mutateAsync({ id: active.id });
    window.location.href = `tel:${contact.phone}`;
  };
  return (
    <div className="max-w-5xl">
      <PageHeading
        eyebrow="Acesso rápido e sem ruído"
        title="Modo emergência"
        description="Use quando precisar de ajuda imediata. O alerta fica registrado e você pode cancelá-lo se tiver sido acionado por engano."
      />
      {active ? (
        <Card className="overflow-hidden border-border bg-danger-soft">
          <div className="border-b border-border bg-[#b84d4d] px-6 py-5 text-white sm:px-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <StatusPill tone="danger">Alerta em andamento</StatusPill>
                <h3 className="mt-4 text-2xl font-bold">Emergência acionada</h3>
                <p className="mt-1 text-sm text-white/80">
                  {formatDate(active.createdAt)} ·{" "}
                  {active.message || "Preciso de ajuda agora."}
                </p>
              </div>
              <AlertCircle className="h-9 w-9 text-white/80" />
            </div>
          </div>
          <div className="grid gap-6 p-6 sm:p-8 lg:grid-cols-[1fr_0.8fr]">
            <div>
              <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-danger-soft text-danger-ink">
                  <Bell className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-bold text-muted-foreground">
                    {soundEnabled
                      ? "Alerta sonoro ativo"
                      : "Alerta sonoro desativado"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {soundEnabled
                      ? "O navegador pode controlar volume e reprodução."
                      : "Você desativou o som nas configurações."}
                  </p>
                </div>
              </div>
              <div className="mt-4 grid gap-3">
                <EventStatus done label="Emergência acionada" />
                <EventStatus
                  done={
                    active.contactsNotificationStatus === "sent" ||
                    active.contactsNotificationStatus === "partial"
                  }
                  label={
                    active.contactsNotificationStatus === "sent"
                      ? `${active.notificationsSent} contato(s) receberam mensagem no app`
                      : active.contactsNotificationStatus === "partial"
                        ? `${active.notificationsSent} contato(s) receberam mensagem; houve falha com outro(s)`
                        : active.contactsNotificationStatus === "failed"
                          ? "Não foi possível entregar mensagem aos contatos vinculados"
                          : active.contactsNotificationStatus === "no_contacts"
                            ? "Sem contatos vinculados para receber mensagem no app"
                            : "Enviando mensagem aos contatos vinculados"
                  }
                />
                <EventStatus
                  done={active.webNotificationStatus === "sent"}
                  label={
                    active.webNotificationStatus === "sent"
                      ? "Notificação deste aparelho enviada"
                      : active.webNotificationStatus === "failed"
                        ? "Notificação deste aparelho não enviada"
                        : active.webNotificationStatus === "unsupported"
                          ? "Notificação indisponível neste aparelho"
                          : "Notificação deste aparelho pendente"
                  }
                />
                <EventStatus
                  done={active.callStatus === "initiated"}
                  label={
                    active.callStatus === "initiated"
                      ? "Ligação solicitada"
                      : "Ligação opcional"
                  }
                />
              </div>
              <Button
                variant="danger"
                onClick={cancelEmergency}
                disabled={cancel.isPending}
                className="mt-6 w-full sm:w-auto"
              >
                <X className="h-4 w-4" /> Cancelar emergência
              </Button>
            </div>
            <div className="rounded-2xl bg-card p-5">
              <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">
                Contatos de confiança
              </p>
              {emergencyContacts.length ? (
                <div className="mt-4 grid gap-3">
                  {emergencyContacts.map((contact, index) => (
                    <div
                      key={contact.id}
                      className="flex items-center gap-3 rounded-xl border border-border p-3"
                    >
                      <span className="grid h-9 w-9 place-items-center rounded-xl bg-warning-soft text-xs font-bold text-warning-ink">
                        {initials(contact.name)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-foreground">
                          {contact.name}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {contact.phone}
                        </p>
                        {contact.linkedOpenId && (
                          <span className="mt-1 inline-block text-[11px] font-semibold text-success-ink">
                            Vinculado ao app
                          </span>
                        )}
                      </div>
                      <Button
                        variant="soft"
                        onClick={() => void call(contact)}
                        className="min-h-9 px-3 py-1.5 text-xs"
                      >
                        <Phone className="h-3.5 w-3.5" /> Ligar
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-4 text-sm leading-6 text-muted-foreground">
                  Você ainda não configurou contatos de emergência. O alerta
                  local continua ativo.
                </p>
              )}
            </div>
          </div>
        </Card>
      ) : (
        <div className="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
          <Card className="relative overflow-hidden border-[#efc0a7] bg-warning-soft p-6 sm:p-9">
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full border-[32px] border-primary/10" />
            <div className="relative">
              <span className="mx-auto grid h-24 w-24 place-items-center rounded-full border-[10px] border-border bg-primary text-white shadow-sm sm:h-28 sm:w-28">
                <AlertCircle className="h-11 w-11" />
              </span>
              <h3 className="mt-7 text-center text-2xl font-bold text-warning-ink">
                Precisa de ajuda agora?
              </h3>
              <p className="mx-auto mt-2 max-w-sm text-center text-sm leading-6 text-warning-ink">
                Você poderá revisar o envio antes de confirmar. O app registra o
                evento e só envia mensagem interna aos contatos vinculados; não
                faz chamadas ou SMS automáticos.
              </p>
              <Button
                onClick={() => void triggerEmergency()}
                disabled={trigger.isPending}
                className="mx-auto mt-7 w-full max-w-sm sm:min-h-14 sm:text-base"
              >
                <Radio className="h-5 w-5" />{" "}
                {trigger.isPending
                  ? "Acionando..."
                  : "Acionar emergência agora"}
              </Button>
              <div className="mx-auto mt-5 max-w-sm">
                <Field label="Mensagem opcional">
                  <TextArea
                    value={notes}
                    onChange={event => setNotes(event.target.value)}
                    placeholder="Ex.: estou em casa e preciso de ajuda..."
                    maxLength={240}
                    className="min-h-20 border-border bg-white/80"
                  />
                </Field>
              </div>
            </div>
          </Card>
          <Card className="p-6 sm:p-8">
            <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">
              Como funciona
            </p>
            <h3 className="mt-2 text-2xl font-bold text-foreground">
              Clareza em cada etapa.
            </h3>
            <div className="mt-7 grid gap-5">
              <EventStatus
                done={soundEnabled}
                label={
                  soundEnabled
                    ? "O alerta sonoro começa imediatamente no aparelho."
                    : "O alerta sonoro está desativado nas configurações."
                }
              />
              <EventStatus label="O evento fica salvo para você acompanhar." />
              <EventStatus label="Contatos vinculados recebem uma notificação dentro do app." />
              <EventStatus label="Você decide se quer abrir uma ligação pelo telefone." />
            </div>
            <div className="mt-7 rounded-xl bg-muted p-4 text-sm leading-6 text-muted-foreground">
              <CircleHelp className="mr-2 inline h-4 w-4 text-primary" />{" "}
              Notificações para contatos fora do app, SMS e ligações automáticas
              dependem de serviços externos e permissões do dispositivo.
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

function EventStatus({
  label,
  done = false,
}: {
  label: string;
  done?: boolean;
}) {
  return (
    <div className="flex items-center gap-3 text-sm">
      <span
        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full ${done ? "bg-success-soft text-success-ink" : "bg-muted text-muted-foreground"}`}
      >
        {done ? (
          <Check className="h-4 w-4" />
        ) : (
          <Clock3 className="h-3.5 w-3.5" />
        )}
      </span>
      <span
        className={
          done ? "font-semibold text-success-ink" : "text-muted-foreground"
        }
      >
        {label}
      </span>
    </div>
  );
}

function ContactsPage() {
  const query = trpc.contacts.list.useQuery();
  const preferencesQuery = trpc.preferences.get.useQuery();
  const utils = trpc.useUtils();
  const create = trpc.contacts.create.useMutation({
    onSuccess: () => utils.contacts.list.invalidate(),
  });
  const update = trpc.contacts.update.useMutation({
    onSuccess: () => utils.contacts.list.invalidate(),
  });
  const remove = trpc.contacts.remove.useMutation({
    onSuccess: () => utils.contacts.list.invalidate(),
  });
  const reorderEmergency = trpc.contacts.reorderEmergency.useMutation({
    onSuccess: () => utils.contacts.list.invalidate(),
  });
  const empty = {
    name: "",
    phone: "",
    email: "",
    relationship: "",
    linkedOpenId: "",
    isEmergency: true,
  };
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState<number | null>(null);
  const contacts = query.data ?? [];
  const emergencyContacts = contacts.filter(
    contact => contact.isEmergency === 1
  );
  const moveEmergencyContact = async (contactId: number, direction: -1 | 1) => {
    const ids = emergencyContacts.map(contact => contact.id);
    const index = ids.indexOf(contactId);
    const target = index + direction;
    if (
      index < 0 ||
      target < 0 ||
      target >= ids.length ||
      reorderEmergency.isPending
    )
      return;
    [ids[index], ids[target]] = [ids[target], ids[index]];
    try {
      await reorderEmergency.mutateAsync({ ids });
      toast("Ordem dos contatos de emergência atualizada.");
    } catch {
      toast(
        "Não foi possível atualizar a ordem. Atualize a lista e tente novamente."
      );
    }
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (editingId)
      await update.mutateAsync({
        id: editingId,
        ...form,
        email: form.email || null,
        linkedOpenId: form.linkedOpenId || null,
      });
    else
      await create.mutateAsync({
        ...form,
        email: form.email || undefined,
        linkedOpenId: form.linkedOpenId || undefined,
      });
    setForm(empty);
    setEditingId(null);
    toast(editingId ? "Contato atualizado." : "Contato adicionado.");
  };
  const edit = (contact: Contact) =>
    setForm({
      name: contact.name,
      phone: contact.phone,
      email: contact.email || "",
      relationship: contact.relationship || "",
      linkedOpenId: contact.linkedOpenId || "",
      isEmergency: contact.isEmergency === 1,
    });
  const deleteOne = async (id: number) => {
    if (!window.confirm("Remover este contato?")) return;
    await remove.mutateAsync({ id });
    toast("Contato removido.");
  };
  const confirmCall = preferencesQuery.data?.callConfirmationRequired !== 0;
  const callContact = (contact: Contact) => {
    if (
      confirmCall &&
      !window.confirm(`Abrir o telefone para ligar para ${contact.name}?`)
    )
      return;
    window.location.href = `tel:${contact.phone}`;
  };
  return (
    <div>
      <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <PageHeading
          eyebrow="Sua rede de confiança"
          title="Sua rede de apoio"
          description="Tenha as pessoas certas por perto. Use as setas para definir a ordem de prioridade na tela de emergência."
        />
        <StatusPill tone="success">
          <ShieldCheck className="h-3 w-3" />{" "}
          {contacts.filter(c => c.isEmergency === 1).length} de emergência
        </StatusPill>
      </div>
      <div className="grid gap-5 xl:grid-cols-[0.8fr_1.2fr]">
        <Card className="p-6">
          <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">
            {editingId ? "Editar contato" : "Novo contato"}
          </p>
          <h3 className="mt-2 text-xl font-bold text-foreground">
            {editingId ? "Atualize os dados" : "Adicione alguém de confiança"}
          </h3>
          <form onSubmit={submit} className="mt-6 grid gap-4">
            <Field label="Nome">
              <TextInput
                required
                value={form.name}
                onChange={event =>
                  setForm({ ...form, name: event.target.value })
                }
                placeholder="Ex.: Ana Souza"
              />
            </Field>
            <Field label="Telefone">
              <TextInput
                required
                value={form.phone}
                onChange={event =>
                  setForm({ ...form, phone: event.target.value })
                }
                placeholder="(11) 99999-9999"
              />
            </Field>
            <Field label="E-mail (opcional)">
              <TextInput
                type="email"
                value={form.email}
                onChange={event =>
                  setForm({ ...form, email: event.target.value })
                }
                placeholder="ana@email.com"
              />
            </Field>
            <Field label="Relação">
              <TextInput
                value={form.relationship}
                onChange={event =>
                  setForm({ ...form, relationship: event.target.value })
                }
                placeholder="Ex.: irmã, amigo, cuidador"
              />
            </Field>
            <Field
              label="ID Plantão Zen vinculado (opcional)"
              hint="Digite o ID PZ-000001 da pessoa para enviar alertas dentro do app; esse código é diferente do ID de chat."
            >
              <TextInput
                value={form.linkedOpenId}
                onChange={event =>
                  setForm({ ...form, linkedOpenId: event.target.value })
                }
                placeholder="Ex.: PZ-000001"
              />
            </Field>
            <label className="flex items-start gap-3 rounded-xl bg-warning-soft p-3 text-sm text-warning-ink">
              <input
                type="checkbox"
                checked={form.isEmergency}
                onChange={event =>
                  setForm({ ...form, isEmergency: event.target.checked })
                }
                className="mt-0.5 h-4 w-4 accent-[#1769aa]"
              />
              <span>
                <strong className="block text-warning-ink">
                  Contato de emergência
                </strong>
                <span className="text-xs leading-5">
                  Inclua esta pessoa na rede que aparece durante um alerta.
                </span>
              </span>
            </label>
            <div className="flex gap-2">
              <Button
                type="submit"
                disabled={create.isPending || update.isPending}
              >
                {editingId ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}
                {editingId ? "Salvar alterações" : "Adicionar contato"}
              </Button>
              {editingId && (
                <Button
                  variant="ghost"
                  onClick={() => {
                    setEditingId(null);
                    setForm(empty);
                  }}
                >
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </Card>
        <Card className="p-6">
          <SectionHeading title="Pessoas adicionadas" eyebrow="Sua lista" />
          {contacts.length === 0 ? (
            <EmptyState
              icon={Users}
              title="Sua lista está vazia"
              text="Adicione alguém que possa estar por perto quando você precisar."
            />
          ) : (
            <div className="mt-5 grid gap-3">
              {contacts.map(contact => {
                const emergencyIndex = emergencyContacts.findIndex(
                  item => item.id === contact.id
                );
                return (
                  <div
                    key={contact.id}
                    className="flex flex-col gap-3 rounded-xl border border-border p-4 sm:flex-row sm:items-center"
                  >
                    {contact.isEmergency === 1 && (
                      <span
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-muted text-xs font-bold text-primary"
                        aria-label={`Prioridade ${emergencyIndex + 1}`}
                      >
                        {emergencyIndex + 1}
                      </span>
                    )}
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-warning-soft text-sm font-bold text-warning-ink">
                      {initials(contact.name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-bold text-foreground">
                          {contact.name}
                        </p>
                        {contact.isEmergency === 1 && (
                          <StatusPill tone="warning">
                            <AlertCircle className="h-3 w-3" /> Emergência
                          </StatusPill>
                        )}
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {contact.relationship || "Contato de confiança"} ·{" "}
                        {contact.phone}
                      </p>
                      {contact.email && (
                        <p className="mt-1 text-xs text-muted-foreground">
                          {contact.email}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {contact.isEmergency === 1 && (
                        <>
                          <button
                            type="button"
                            onClick={() =>
                              void moveEmergencyContact(contact.id, -1)
                            }
                            disabled={
                              emergencyIndex === 0 || reorderEmergency.isPending
                            }
                            aria-label={`Mover ${contact.name} para cima`}
                            title="Priorizar contato"
                            className="rounded-lg p-2 text-muted-foreground hover:bg-muted disabled:opacity-40"
                          >
                            <ArrowUp className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void moveEmergencyContact(contact.id, 1)
                            }
                            disabled={
                              emergencyIndex === emergencyContacts.length - 1 ||
                              reorderEmergency.isPending
                            }
                            aria-label={`Mover ${contact.name} para baixo`}
                            title="Baixar prioridade"
                            className="rounded-lg p-2 text-muted-foreground hover:bg-muted disabled:opacity-40"
                          >
                            <ArrowDown className="h-4 w-4" />
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => callContact(contact)}
                        title="Ligar"
                        className="rounded-lg p-2 text-success-ink hover:bg-success-soft"
                      >
                        <Phone className="h-4 w-4" />
                      </button>
                      <a
                        href={`sms:${contact.phone}`}
                        title="Mensagem"
                        className="rounded-lg p-2 text-[#397fae] hover:bg-muted"
                      >
                        <MessageCircle className="h-4 w-4" />
                      </a>
                      <button
                        onClick={() => {
                          setEditingId(contact.id);
                          edit(contact);
                        }}
                        title="Editar"
                        className="rounded-lg p-2 text-muted-foreground hover:bg-muted"
                      >
                        <Settings className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => void deleteOne(contact.id)}
                        title="Remover"
                        className="rounded-lg p-2 text-danger-ink hover:bg-danger-soft"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function AnalysesPage({
  selectedId,
  setLocation,
}: {
  selectedId?: number;
  setLocation: (path: string) => void;
}) {
  const [filter, setFilter] = useState("Todos");
  const [period, setPeriod] = useState("all");
  const query = trpc.analyses.list.useQuery(
    filter === "Todos" ? undefined : { result: filter }
  );
  const allAnalysesQuery = trpc.analyses.list.useQuery({ limit: 100 });
  const checkinsQuery = trpc.checkins.list.useQuery();
  const detailQuery = trpc.analyses.get.useQuery(
    { id: selectedId ?? 0 },
    { enabled: Boolean(selectedId) }
  );
  const utils = trpc.useUtils();
  const create = trpc.analyses.create.useMutation({
    onSuccess: () => utils.analyses.list.invalidate(),
  });
  const remove = trpc.analyses.remove.useMutation({
    onSuccess: () => {
      utils.analyses.list.invalidate();
      if (selectedId) setLocation("/analyses");
    },
  });
  const clear = trpc.analyses.clear.useMutation({
    onSuccess: () => utils.analyses.list.invalidate(),
  });
  const [form, setForm] = useState({
    title: "Check-in de bem-estar",
    result: "Tranquilo",
    details: "",
  });
  const analyses = query.data ?? [];
  const checkins = checkinsQuery.data ?? [];
  const resultCounts = analyses.reduce<Record<string, number>>(
    (counts, item) => ({
      ...counts,
      [item.result]: (counts[item.result] || 0) + 1,
    }),
    {}
  );
  const reportAnalyses = allAnalysesQuery.data ?? [];
  const reportSince =
    period === "all" ? 0 : Date.now() - Number(period) * 86400000;
  const reportCheckins = checkins.filter(
    item => new Date(item.createdAt).getTime() >= reportSince
  );
  const reportRows = reportAnalyses.filter(
    item => new Date(item.createdAt).getTime() >= reportSince
  );
  const printReport = () => {
    window.print();
  };
  const reportSection = (
    <div className="print-only mt-6">
      <h2 className="text-xl font-bold">Registros do período</h2>
      {reportRows.length === 0 ? (
        <p className="mt-2 text-sm">Nenhuma análise no período selecionado.</p>
      ) : (
        <div className="mt-3 grid gap-3">
          {reportRows.map(item => (
            <div key={item.id} className="border-b border-border pb-3">
              <p className="font-bold">
                {item.title} — {item.result}
              </p>
              <p className="text-sm">{formatDate(item.createdAt)}</p>
              <p className="mt-1 whitespace-pre-wrap text-sm">{item.details}</p>
            </div>
          ))}
        </div>
      )}
      <h2 className="mt-6 text-xl font-bold">Check-ins do período</h2>
      {reportCheckins.length === 0 ? (
        <p className="mt-2 text-sm">Nenhum check-in no período selecionado.</p>
      ) : (
        <div className="mt-3 grid gap-3">
          {reportCheckins.map(item => (
            <div key={item.id} className="border-b border-border pb-3">
              <p className="font-bold">{item.mood}</p>
              <p className="text-sm">{formatDate(item.createdAt)}</p>
              {item.notes && (
                <p className="mt-1 whitespace-pre-wrap text-sm">{item.notes}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    await create.mutateAsync(form);
    setForm({ ...form, details: "" });
    toast("Análise salva em Minhas análises.");
  };
  const selected =
    detailQuery.data || analyses.find(item => item.id === selectedId);
  const trendSummary = (
    <Card className="mb-5 p-6">
      <div className="flex items-center gap-3">
        <BarChart3 className="h-5 w-5 text-primary" />
        <div>
          <p className="text-xs font-bold uppercase tracking-[.15em] text-muted-foreground">
            Visão geral
          </p>
          <h3 className="mt-1 text-lg font-bold text-foreground">
            Acompanhamento sem diagnóstico
          </h3>
        </div>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {Object.entries(resultCounts).map(([label, count]) => (
          <div key={label}>
            <div className="mb-1 flex justify-between text-xs font-semibold text-muted-foreground">
              <span>{label}</span>
              <span>{count}</span>
            </div>
            <div className="h-2 rounded-full bg-muted">
              <div
                className="h-2 rounded-full bg-primary"
                style={{
                  width: `${analyses.length ? (count / analyses.length) * 100 : 0}%`,
                }}
              />
            </div>
          </div>
        ))}
        <div className="rounded-xl bg-muted p-3 text-sm text-muted-foreground">
          {checkins.length} check-in(s) recente(s) disponível(is) para consulta.
        </div>
      </div>
    </Card>
  );
  return (
    <div className="pz-analysis-page">
      <div className="print-report-title mb-6">
        <h1 className="text-2xl font-bold">
          Relatório de cuidado — Plantão Zen
        </h1>
        <p className="mt-1 text-sm">Gerado em {formatDate(new Date())}</p>
      </div>
      {reportSection}
      <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <PageHeading
          eyebrow="Seu histórico de cuidado"
          title="Minhas análises"
          description="Registre percepções importantes e reveja seus resultados quando quiser. Tudo fica vinculado à sua conta."
        />
        <div className="flex flex-wrap items-center gap-2" data-no-print>
          <select
            aria-label="Período do relatório"
            value={period}
            onChange={event => setPeriod(event.target.value)}
            className="h-10 rounded-xl border border-border bg-card px-3 text-xs font-semibold text-muted-foreground"
          >
            <option value="7">Últimos 7 dias</option>
            <option value="30">Últimos 30 dias</option>
            <option value="90">Últimos 90 dias</option>
            <option value="all">Todo o histórico</option>
          </select>
          <Button variant="soft" onClick={printReport}>
            <BarChart3 className="h-4 w-4" /> Gerar PDF
          </Button>
          {analyses.length > 0 && (
            <Button
              variant="ghost"
              onClick={() => {
                if (window.confirm("Excluir todo o histórico de análises?"))
                  void clear.mutateAsync();
              }}
            >
              <Trash2 className="h-4 w-4" /> Limpar histórico
            </Button>
          )}
        </div>
      </div>
      {trendSummary}
      {selected ? (
        <Card className="mb-5 p-6 sm:p-8">
          <button
            onClick={() => setLocation("/analyses")}
            className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-primary"
          >
            <ArrowLeft className="h-4 w-4" /> Voltar para o histórico
          </button>
          <div className="flex flex-wrap items-center gap-2">
            <StatusPill tone="info">{selected.result}</StatusPill>
            <span className="text-xs text-muted-foreground">
              {formatDate(selected.createdAt)}
            </span>
          </div>
          <h3 className="mt-4 text-3xl font-bold text-foreground">
            {selected.title}
          </h3>
          <p className="mt-5 whitespace-pre-wrap text-base leading-8 text-muted-foreground">
            {selected.details}
          </p>
          <Button
            variant="danger"
            onClick={() => {
              if (window.confirm("Excluir esta análise?"))
                void remove.mutateAsync({ id: selected.id });
            }}
            className="mt-8"
          >
            <Trash2 className="h-4 w-4" /> Excluir análise
          </Button>
        </Card>
      ) : (
        <div className="grid gap-5 xl:grid-cols-[0.75fr_1.25fr]">
          <Card className="p-6">
            <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">
              Nova análise
            </p>
            <h3 className="mt-2 text-xl font-bold text-foreground">
              Como foi seu momento?
            </h3>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Escreva o que é relevante para você. Esta análise ficará salva
              automaticamente quando você enviar.
            </p>
            <form onSubmit={submit} className="mt-6 grid gap-4">
              <Field label="Título">
                <TextInput
                  required
                  value={form.title}
                  onChange={event =>
                    setForm({ ...form, title: event.target.value })
                  }
                />
              </Field>
              <Field label="Resultado">
                <select
                  value={form.result}
                  onChange={event =>
                    setForm({ ...form, result: event.target.value })
                  }
                  className="h-11 rounded-xl border border-border bg-muted px-3 text-sm outline-none focus:border-primary"
                >
                  <option>Tranquilo</option>
                  <option>Preciso de atenção</option>
                  <option>Preciso de apoio</option>
                  <option>Em acompanhamento</option>
                </select>
              </Field>
              <Field label="Informações relevantes">
                <TextArea
                  required
                  value={form.details}
                  onChange={event =>
                    setForm({ ...form, details: event.target.value })
                  }
                  placeholder="O que você gostaria de lembrar desta análise?"
                />
              </Field>
              <Button type="submit" disabled={create.isPending}>
                <Check className="h-4 w-4" />{" "}
                {create.isPending ? "Salvando..." : "Salvar análise"}
              </Button>
            </form>
          </Card>
          <Card className="p-6">
            <div className="flex items-end justify-between gap-3">
              <SectionHeading
                title="Registros salvos"
                eyebrow={`${analyses.length} ${analyses.length === 1 ? "registro" : "registros"}`}
              />
              <select
                aria-label="Filtrar análises"
                value={filter}
                onChange={event => setFilter(event.target.value)}
                className="h-9 rounded-lg border border-border bg-card px-2 text-xs font-semibold text-muted-foreground"
              >
                <option>Todos</option>
                <option>Tranquilo</option>
                <option>Preciso de atenção</option>
                <option>Preciso de apoio</option>
                <option>Em acompanhamento</option>
              </select>
            </div>
            {analyses.length === 0 ? (
              <EmptyState
                icon={Activity}
                title="Ainda não há registros"
                text="Sua primeira análise aparecerá aqui depois que você salvar."
              />
            ) : (
              <div className="mt-5 grid gap-3">
                {analyses.map(item => (
                  <button
                    key={item.id}
                    onClick={() => setLocation(`/analyses/${item.id}`)}
                    className="group flex items-center gap-4 rounded-xl border border-border p-4 text-left transition hover:border-[#efc0a7] hover:bg-muted"
                  >
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-muted text-primary">
                      <Activity className="h-4 w-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate font-bold text-foreground">
                          {item.title}
                        </p>
                        <StatusPill tone="info">{item.result}</StatusPill>
                      </div>
                      <p className="mt-1 truncate text-sm text-muted-foreground">
                        {item.details}
                      </p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        {formatDate(item.createdAt)}
                      </p>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" />
                  </button>
                ))}
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}

function ProfilePage() {
  const query = trpc.profile.get.useQuery();
  const utils = trpc.useUtils();
  const save = trpc.profile.save.useMutation({
    onSuccess: () => utils.profile.get.invalidate(),
  });
  const privacyTwoFactor = trpc.security.twoFactorStatus.useQuery();
  const exportPrivacy = trpc.privacy.exportData.useMutation();
  const deletePrivacy = trpc.privacy.deleteAccount.useMutation();
  const [privacyPassword, setPrivacyPassword] = useState("");
  const [privacyTotp, setPrivacyTotp] = useState("");
  const [deleteConfirmation, setDeleteConfirmation] = useState("");
  const { user, logout } = useAuth();
  const [copiedId, setCopiedId] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    birthDate: "",
    city: "",
    careNotes: "",
  });
  useEffect(() => {
    if (query.data)
      setForm({
        fullName: query.data.fullName || "",
        phone: query.data.phone || "",
        birthDate: query.data.birthDate || "",
        city: query.data.city || "",
        careNotes: query.data.careNotes || "",
      });
  }, [query.data]);
  const accountId = user ? `PZ-${String(user.id).padStart(6, "0")}` : "";
  const copyAccountId = async () => {
    if (!accountId) return;
    await navigator.clipboard?.writeText(accountId);
    setCopiedId(true);
    toast("ID de contatos copiado.");
    window.setTimeout(() => setCopiedId(false), 1800);
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    await save.mutateAsync(form);
    toast("Perfil salvo com segurança.");
  };
  const downloadMyData = async () => {
    try {
      const data = await exportPrivacy.mutateAsync({
        password: privacyPassword,
        totpCode: privacyTwoFactor.data?.enabled ? privacyTotp : undefined,
      });
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json;charset=utf-8",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "plantao-zen-meus-dados.json";
      link.click();
      URL.revokeObjectURL(url);
      setPrivacyPassword("");
      setPrivacyTotp("");
      toast.success(
        "Seus dados foram exportados. Guarde o arquivo em local seguro."
      );
    } catch {
      toast.error(
        "Não foi possível exportar. Confira a senha e tente novamente."
      );
    }
  };
  const deleteProfile = async () => {
    if (deleteConfirmation !== "EXCLUIR MINHA CONTA") {
      toast.error("Digite a confirmação exatamente como indicado.");
      return;
    }
    if (
      !window.confirm(
        "Excluir permanentemente a conta e os dados associados? Esta ação não pode ser desfeita."
      )
    )
      return;
    try {
      await deletePrivacy.mutateAsync({
        password: privacyPassword,
        totpCode: privacyTwoFactor.data?.enabled ? privacyTotp : undefined,
        confirmation: "EXCLUIR MINHA CONTA",
      });
      setPrivacyPassword("");
      toast.success("Conta excluída.");
      window.location.assign("/login");
    } catch {
      toast.error(
        "Não foi possível excluir. Confira a senha e tente novamente."
      );
    }
  };
  return (
    <div className="max-w-4xl">
      <PageHeading
        eyebrow="Quem está usando o cuidado"
        title="Meu perfil"
        description="Mantenha seus dados atualizados para que os contatos e preferências funcionem do jeito que você espera."
      />
      <Card className="mb-5 border-border bg-muted p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.15em] text-primary">
              ID para vincular contatos
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              Use este ID ao vincular contatos; seu código de chat é diferente.
            </p>
            <p className="mt-3 font-mono text-2xl font-bold tracking-[0.12em] text-primary">
              {accountId || "Gerando..."}
            </p>
          </div>
          <Button
            variant="soft"
            onClick={() => void copyAccountId()}
            disabled={!accountId}
          >
            {copiedId ? (
              <Check className="h-4 w-4" />
            ) : (
              <Copy className="h-4 w-4" />
            )}{" "}
            {copiedId ? "Copiado" : "Copiar ID"}
          </Button>
        </div>
      </Card>
      <Card className="p-6 sm:p-8">
        <form onSubmit={submit} className="grid gap-5 sm:grid-cols-2">
          <Field label="Nome completo">
            <TextInput
              value={form.fullName}
              onChange={event =>
                setForm({ ...form, fullName: event.target.value })
              }
              placeholder="Como você prefere ser chamado"
            />
          </Field>
          <Field label="Telefone">
            <TextInput
              value={form.phone}
              onChange={event =>
                setForm({ ...form, phone: event.target.value })
              }
              placeholder="Seu telefone"
            />
          </Field>
          <Field label="Data de nascimento">
            <TextInput
              type="date"
              value={form.birthDate}
              onChange={event =>
                setForm({ ...form, birthDate: event.target.value })
              }
            />
          </Field>
          <Field label="Cidade">
            <TextInput
              value={form.city}
              onChange={event => setForm({ ...form, city: event.target.value })}
              placeholder="Onde você está"
            />
          </Field>
          <div className="sm:col-span-2">
            <Field
              label="Observações importantes"
              hint="Use somente informações que você deseja manter salvas na sua conta."
            >
              <TextArea
                value={form.careNotes}
                onChange={event =>
                  setForm({ ...form, careNotes: event.target.value })
                }
                placeholder="Alergias, preferências ou observações para o seu cuidado..."
              />
            </Field>
          </div>
          <div className="flex flex-col justify-between gap-4 border-t border-border pt-5 sm:col-span-2 sm:flex-row sm:items-center">
            <p className="text-xs text-muted-foreground">
              {query.data
                ? `Última atualização: ${formatDate(query.data.updatedAt)}`
                : "Ainda não há um perfil salvo."}
            </p>
            <Button type="submit" disabled={save.isPending}>
              <Check className="h-4 w-4" />{" "}
              {save.isPending ? "Salvando..." : "Salvar meu perfil"}
            </Button>
          </div>
        </form>
      </Card>
      <Card className="mt-5 p-6">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-1 h-5 w-5 text-primary" />
          <div className="flex-1">
            <h3 className="font-bold text-foreground">
              Privacidade e direitos LGPD
            </h3>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              Você pode obter uma cópia dos seus dados ou solicitar a exclusão
              da conta. Por segurança, as duas ações exigem sua senha e, se o
              2FA estiver ativo, o código do autenticador. O arquivo exportado
              contém informações pessoais: armazene-o com cuidado.
            </p>
            <a
              className="mt-2 inline-block text-sm font-semibold text-primary underline"
              href="/privacidade"
              target="_blank"
              rel="noopener noreferrer"
            >
              Ler Aviso de Privacidade
            </a>
            <div className="mt-4">
              <Field label="Confirme a senha da conta">
                <TextInput
                  type="password"
                  autoComplete="current-password"
                  value={privacyPassword}
                  onChange={event => setPrivacyPassword(event.target.value)}
                  placeholder="Sua senha"
                />
              </Field>
            </div>
            {privacyTwoFactor.data?.enabled && (
              <div className="mt-3">
                <Field label="Código atual do autenticador (2FA)">
                  <TextInput
                    type="text"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    value={privacyTotp}
                    onChange={event =>
                      setPrivacyTotp(
                        event.target.value.replace(/\D/g, "").slice(0, 6)
                      )
                    }
                    placeholder="000000"
                  />
                </Field>
              </div>
            )}
            <Button
              className="mt-3"
              variant="soft"
              onClick={() => void downloadMyData()}
              disabled={
                !privacyPassword ||
                privacyTwoFactor.isLoading ||
                (privacyTwoFactor.data?.enabled && privacyTotp.length !== 6) ||
                exportPrivacy.isPending
              }
            >
              {exportPrivacy.isPending
                ? "Preparando…"
                : "Exportar meus dados (JSON)"}
            </Button>
            <div className="mt-6 border-t border-border pt-5">
              <h4 className="font-bold text-danger-ink">
                Excluir definitivamente minha conta
              </h4>
              <p className="mt-1 text-sm text-danger-ink">
                Remove seus dados, plantões e mensagens enviadas. Preserva as
                mensagens enviadas pelos outros participantes em conversas
                somente leitura, sem manter seu perfil ou acesso. Backups e
                obrigações legais podem exigir tratamento separado.
              </p>
              <div className="mt-3">
                <Field label="Digite EXCLUIR MINHA CONTA">
                  <TextInput
                    value={deleteConfirmation}
                    onChange={event =>
                      setDeleteConfirmation(event.target.value)
                    }
                    placeholder="EXCLUIR MINHA CONTA"
                  />
                </Field>
              </div>
              <Button
                className="mt-3"
                variant="danger"
                onClick={() => void deleteProfile()}
                disabled={
                  !privacyPassword ||
                  privacyTwoFactor.isLoading ||
                  (privacyTwoFactor.data?.enabled &&
                    privacyTotp.length !== 6) ||
                  deleteConfirmation !== "EXCLUIR MINHA CONTA" ||
                  deletePrivacy.isPending
                }
              >
                {deletePrivacy.isPending ? "Excluindo…" : "Excluir minha conta"}
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function SmartwatchPage() {
  const utils = trpc.useUtils();
  const query = trpc.smartwatch.get.useQuery();
  const save = trpc.smartwatch.save.useMutation({
    onSuccess: () => utils.smartwatch.get.invalidate(),
  });
  const [capabilities, setCapabilities] = useState(getDeviceCapabilities());
  const refresh = () => setCapabilities(getDeviceCapabilities());
  const enable = async () => {
    const permission = await requestNotificationPermission();
    const next = getDeviceCapabilities();
    setCapabilities(next);
    await save.mutateAsync({
      notificationPermission: permission,
      supportsNotifications: permission === "granted",
      pwaInstalled: next.pwaInstalled,
      supportsActions: next.notificationActions,
      smartwatchMirroring: false,
    });
    toast(
      permission === "granted"
        ? "Notificações ativas. O espelhamento depende do sistema do seu relógio."
        : "Permissão não concedida."
    );
  };
  useEffect(() => {
    void save.mutateAsync({
      platform: navigator.userAgent.includes("Android")
        ? "Android / navegador"
        : "Navegador",
      pwaInstalled: capabilities.pwaInstalled,
      supportsNotifications:
        capabilities.notifications &&
        capabilities.notificationPermission === "granted",
      supportsActions: capabilities.notificationActions,
      notificationPermission: capabilities.notificationPermission,
      smartwatchMirroring: false,
    });
  }, []);
  return (
    <div className="max-w-5xl">
      <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <PageHeading
          eyebrow="Seu dispositivo de apoio"
          title="Relógio e dispositivos"
          description="Prepare as notificações para que um alerta importante possa ser espelhado no relógio, quando o Android e o modelo conectado permitirem."
        />
        <Button variant="ghost" onClick={refresh}>
          <RefreshCw className="h-4 w-4" /> Atualizar status
        </Button>
      </div>
      <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Card className="overflow-hidden">
          <div className="bg-[#2f4d5b] p-7 text-white sm:p-8">
            <div className="flex items-start justify-between">
              <div>
                <StatusPill
                  tone={
                    capabilities.notifications &&
                    capabilities.notificationPermission === "granted"
                      ? "success"
                      : "warning"
                  }
                >
                  {capabilities.notifications &&
                  capabilities.notificationPermission === "granted"
                    ? "Pronto para notificar"
                    : "Ação necessária"}
                </StatusPill>
                <h3 className="mt-4 text-2xl font-bold">
                  Notificações no relógio
                </h3>
                <p className="mt-2 max-w-md text-sm leading-6 text-white/70">
                  O Plantão Zen envia a notificação para o navegador. O sistema
                  do telefone decide se ela será espelhada no smartwatch.
                </p>
              </div>
              <Watch className="h-10 w-10 text-[#9cc7e6]" />
            </div>
          </div>
          <div className="grid gap-4 p-6 sm:grid-cols-2">
            <Capability
              label="Notificações do navegador"
              value={
                capabilities.notifications
                  ? capabilities.notificationPermission === "granted"
                    ? "Permitidas"
                    : "Pendentes"
                  : "Indisponíveis"
              }
              good={
                capabilities.notifications &&
                capabilities.notificationPermission === "granted"
              }
            />
            <Capability
              label="Ações rápidas"
              value={
                capabilities.notificationActions
                  ? "Suportadas"
                  : "Dependem do navegador"
              }
              good={capabilities.notificationActions}
            />
            <Capability
              label="PWA instalada"
              value={capabilities.pwaInstalled ? "Sim" : "Ainda não"}
              good={capabilities.pwaInstalled}
            />
            <Capability
              label="Espelhamento no relógio"
              value={"Não confirmado"}
              good={false}
            />
          </div>
          <div className="border-t border-border p-6">
            <Button onClick={() => void enable()} disabled={save.isPending}>
              <Bell className="h-4 w-4" />{" "}
              {capabilities.notificationPermission === "granted"
                ? "Salvar preferência"
                : "Ativar notificações"}
            </Button>
          </div>
        </Card>
        <Card className="p-6 sm:p-8">
          <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">
            Compatibilidade transparente
          </p>
          <h3 className="mt-2 text-2xl font-bold text-foreground">
            O que funciona hoje
          </h3>
          <div className="mt-6 grid gap-5">
            <InfoRow
              icon={Smartphone}
              title="Celular"
              text="Alertas e som local funcionam conforme as permissões do navegador."
            />
            <InfoRow
              icon={Watch}
              title="Wear OS"
              text="Pode espelhar notificações do Android se você ativar esse recurso no telefone."
            />
            <InfoRow
              icon={Link2}
              title="Ações no relógio"
              text="Ações nativas para acionar, cancelar ou ver contatos exigem um app companheiro Wear OS futuro."
            />
          </div>
          <div className="mt-7 rounded-xl bg-muted p-4 text-sm leading-6 text-muted-foreground">
            <ShieldCheck className="mr-2 inline h-4 w-4 text-primary" /> Nenhuma
            permissão de contatos ou chamadas é solicitada nesta tela. Elas só
            são usadas quando você escolher a ação correspondente.
          </div>
        </Card>
      </div>
    </div>
  );
}

function Capability({
  label,
  value,
  good,
}: {
  label: string;
  value: string;
  good: boolean;
}) {
  return (
    <div className="rounded-xl bg-muted p-4">
      <div className="flex items-center gap-2">
        <span
          className={`h-2 w-2 rounded-full ${good ? "bg-[#5bb889]" : "bg-[#e4aa4c]"}`}
        />
        <span className="text-xs font-bold uppercase tracking-[0.08em] text-muted-foreground">
          {label}
        </span>
      </div>
      <p className="mt-2 text-sm font-bold text-foreground">{value}</p>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  title,
  text,
}: {
  icon: LucideIcon;
  title: string;
  text: string;
}) {
  return (
    <div className="flex gap-3">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-muted text-primary">
        <Icon className="h-5 w-5" />
      </span>
      <div>
        <p className="font-bold text-foreground">{title}</p>
        <p className="mt-1 text-sm leading-6 text-muted-foreground">{text}</p>
      </div>
    </div>
  );
}

function SettingsPage() {
  const query = trpc.preferences.get.useQuery();
  const utils = trpc.useUtils();
  const { theme, toggleTheme } = useTheme();
  const save = trpc.preferences.save.useMutation({
    onSuccess: () => utils.preferences.get.invalidate(),
  });
  const [values, setValues] = useState({
    notificationsEnabled: true,
    soundEnabled: true,
    smartwatchEnabled: true,
    backgroundEnabled: true,
    callConfirmationRequired: true,
  });
  const [permission, setPermission] = useState<
    NotificationPermission | "unsupported"
  >(getDeviceCapabilities().notificationPermission);
  useEffect(() => {
    if (query.data)
      setValues({
        notificationsEnabled: query.data.notificationsEnabled === 1,
        soundEnabled: query.data.soundEnabled === 1,
        smartwatchEnabled: query.data.smartwatchEnabled === 1,
        backgroundEnabled: query.data.backgroundEnabled === 1,
        callConfirmationRequired: query.data.callConfirmationRequired === 1,
      });
  }, [query.data]);
  const toggle = async (key: keyof typeof values) => {
    const next = { ...values, [key]: !values[key] };
    setValues(next);
    await save.mutateAsync({ [key]: next[key] });
    toast("Preferência atualizada.");
  };
  const changeTheme = async () => {
    toggleTheme?.();
    await save.mutateAsync({ theme: theme === "dark" ? "light" : "dark" });
    toast(`Tema ${theme === "dark" ? "claro" : "escuro"} ativado.`);
  };
  const enableNotifications = async () => {
    const next = await requestNotificationPermission();
    setPermission(next);
    toast(
      next === "granted"
        ? "Notificações permitidas neste navegador."
        : next === "denied"
          ? "A permissão está bloqueada no navegador."
          : "Notificações indisponíveis."
    );
  };
  return (
    <div className="max-w-4xl">
      <PageHeading
        eyebrow="Seu jeito de usar o app"
        title="Configurações"
        description="Escolha o que faz sentido para você. As permissões do navegador são solicitadas somente no momento de uso."
      />
      <Card className="mb-5 flex items-center gap-4 p-5">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-muted text-primary">
          {theme === "dark" ? (
            <Moon className="h-5 w-5" />
          ) : (
            <Sun className="h-5 w-5" />
          )}
        </span>
        <div className="flex-1">
          <p className="font-bold text-foreground">Tema da interface</p>
          <p className="mt-1 text-sm text-muted-foreground">
            A preferência visual fica salva neste dispositivo.
          </p>
        </div>
        <Button variant="soft" onClick={() => void changeTheme()}>
          {theme === "dark" ? "Usar tema claro" : "Usar tema escuro"}
        </Button>
      </Card>
      <Card className="divide-y divide-[#eee8e1] p-2 sm:p-3">
        {[
          [
            "notificationsEnabled",
            "Notificações importantes",
            "Receba alertas de emergência e eventos importantes no celular.",
          ],
          [
            "soundEnabled",
            "Som de emergência",
            "Emita o alerta sonoro local quando uma emergência for acionada.",
          ],
          [
            "smartwatchEnabled",
            "Espelhamento no smartwatch",
            "Permita que alertas do celular sejam elegíveis para espelhamento.",
          ],
          [
            "backgroundEnabled",
            "Atividade em segundo plano",
            "Mantenha a preferência para notificações quando o app não estiver aberto.",
          ],
          [
            "callConfirmationRequired",
            "Confirmar antes de ligar",
            "Sempre peça uma confirmação antes de abrir o discador do aparelho.",
          ],
        ].map(([key, title, description]) => (
          <div key={key} className="flex items-center gap-4 p-4">
            <div className="flex-1">
              <p className="font-bold text-foreground">{title}</p>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">
                {description}
              </p>
            </div>
            <button
              aria-label={`Alternar ${title}`}
              onClick={() => void toggle(key as keyof typeof values)}
              className={`relative h-7 w-12 rounded-full transition ${values[key as keyof typeof values] ? "bg-primary" : "bg-muted"}`}
            >
              <span
                className={`absolute top-1 h-5 w-5 rounded-full bg-card shadow transition ${values[key as keyof typeof values] ? "left-6" : "left-1"}`}
              />
            </button>
          </div>
        ))}
      </Card>
      <Card className="mt-5 p-6">
        <div className="flex items-start gap-3">
          <Bell className="mt-0.5 h-5 w-5 text-primary" />
          <div className="flex-1">
            <h3 className="font-bold text-foreground">
              Permissão do navegador
            </h3>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              Estado atual:{" "}
              <strong>
                {permission === "granted"
                  ? "permitida"
                  : permission === "denied"
                    ? "bloqueada"
                    : permission === "unsupported"
                      ? "indisponível"
                      : "ainda não solicitada"}
              </strong>
              .
            </p>
            {permission === "denied" ? (
              <p className="mt-2 text-sm leading-6 text-warning-ink">
                Para reativar, abra as configurações do site no cadeado ao lado
                do endereço e permita Notificações. Depois, recarregue esta
                página.
              </p>
            ) : (
              permission !== "granted" && (
                <Button
                  variant="soft"
                  onClick={() => void enableNotifications()}
                  className="mt-4"
                >
                  Solicitar permissão
                </Button>
              )
            )}
          </div>
        </div>
      </Card>
      <Card className="mt-5 p-6">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-0.5 h-5 w-5 text-primary" />
          <div>
            <h3 className="font-bold text-foreground">
              Privacidade por escolha
            </h3>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              Seus dados são vinculados à conta autenticada e não são
              compartilhados com terceiros pelo aplicativo. Você pode excluir
              tudo na seção Meu perfil.
            </p>
          </div>
        </div>
      </Card>
      <WatchPairing />
      <SecurityControls />
    </div>
  );
}

export default function Portal() {
  const { user, loading, logout } = useAuth();
  const [location, setLocation] = useLocation();
  if (loading)
    return (
      <div className="grid min-h-screen place-items-center bg-muted">
        <div className="flex items-center gap-3 text-sm font-semibold text-muted-foreground">
          <span className="h-3 w-3 animate-pulse rounded-full bg-primary" />{" "}
          Carregando seu espaço...
        </div>
      </div>
    );
  if (!user)
    return (
      <LoginScreen
        key={location === "/register" ? "register" : "login"}
        register={location === "/register"}
      />
    );
  const selectedId = location.match(/^\/analyses\/(\d+)/)?.[1];
  if (location.startsWith("/analyses/") && !selectedId) return <NotFound />;
  const content =
    location === "/emergency" ? (
      <EmergencyPage />
    ) : location === "/contacts" ? (
      <ContactsPage />
    ) : location === "/analyses" || Boolean(selectedId) ? (
      <AnalysesPage
        selectedId={selectedId ? Number(selectedId) : undefined}
        setLocation={setLocation}
      />
    ) : location === "/checkin" ? (
      <CheckinPage />
    ) : location === "/safety" ? (
      <SafetyPlanPage />
    ) : location === "/messages" || location === "/messages/moderation" ? (
      <MessagesPage isAdmin={user.role === "admin"} />
    ) : location === "/profile" ? (
      <ProfilePage />
    ) : location === "/smartwatch" ? (
      <SmartwatchPage />
    ) : location === "/settings" ? (
      <SettingsPage />
    ) : location === "/workforce" ? (
      <Workforce />
    ) : location === "/about" ? (
      <About />
    ) : (
      <Overview user={user} />
    );
  return (
    <Shell
      user={user}
      location={location}
      setLocation={setLocation}
      logout={logout}
    >
      <NativePush />
      {content}
    </Shell>
  );
}

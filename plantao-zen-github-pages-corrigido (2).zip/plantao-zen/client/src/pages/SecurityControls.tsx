import { useId, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ShieldCheck } from "lucide-react";

export default function SecurityControls() {
  const fieldId = useId();
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [secret, setSecret] = useState("");
  const [uri, setUri] = useState("");
  const status = trpc.security.twoFactorStatus.useQuery();
  const sessions = trpc.security.sessionCount.useQuery();
  const begin = trpc.security.beginTwoFactor.useMutation();
  const enable = trpc.security.enableTwoFactor.useMutation();
  const disable = trpc.security.disableTwoFactor.useMutation();
  const revoke = trpc.security.revokeOtherSessions.useMutation();
  const message = (error: unknown) =>
    toast.error(
      error instanceof Error
        ? error.message
        : "Não foi possível concluir. Tente novamente."
    );
  const inputStyle =
    "w-full rounded-xl border border-border bg-card p-3 text-foreground";
  const buttonStyle =
    "rounded-xl bg-primary px-4 py-2 font-semibold text-primary-foreground disabled:opacity-50";
  return (
    <section
      className="mt-5 rounded-2xl border border-border bg-card p-6"
      aria-labelledby="security-heading"
    >
      <div className="flex items-center gap-2">
        <ShieldCheck className="text-primary" />
        <h3 id="security-heading" className="text-xl font-bold">
          Segurança da conta
        </h3>
      </div>
      <p className="mt-2 text-sm text-foreground">
        Ative códigos de autenticação de um aplicativo autenticador. Guarde o
        acesso ao aplicativo: a recuperação de senha não remove o segundo fator.
      </p>
      <label
        htmlFor={`${fieldId}-password`}
        className="mt-5 block text-sm font-semibold"
      >
        Senha atual
      </label>
      <input
        id={`${fieldId}-password`}
        className={inputStyle}
        type="password"
        autoComplete="current-password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <p className="mt-4 text-sm">
        2FA:{" "}
        <strong>
          {status.isError
            ? "Não foi possível consultar"
            : status.isPending
              ? "Consultando…"
              : status.data?.enabled
                ? "Ativado"
                : "Desativado"}
        </strong>
      </p>
      {!status.data?.enabled && (
        <button
          className={`${buttonStyle} mt-2`}
          disabled={
            !password || begin.isPending || status.isPending || status.isError
          }
          onClick={async () => {
            try {
              const result = await begin.mutateAsync({ password });
              setSecret(result.secret);
              setUri(result.uri);
              toast.success(
                "Configure o aplicativo autenticador com a chave exibida."
              );
            } catch (err) {
              message(err);
            }
          }}
        >
          Iniciar ativação 2FA
        </button>
      )}
      {secret && !status.data?.enabled && (
        <div className="mt-4 rounded-xl bg-muted p-4">
          <p className="font-semibold">
            Adicione esta chave no Google Authenticator, Microsoft Authenticator
            ou equivalente:
          </p>
          <p className="mt-2 break-all font-mono text-sm">{secret}</p>
          <p className="mt-2 text-xs">
            A chave só é exibida nesta etapa. Não compartilhe nem envie por
            mensagem.
          </p>
          <a
            className="mt-2 block break-words text-sm text-primary underline"
            href={uri}
          >
            Abrir no aplicativo autenticador
          </a>
        </div>
      )}
      {(!!secret || !!status.data?.enabled) && (
        <>
          <label
            htmlFor={`${fieldId}-code`}
            className="mt-4 block text-sm font-semibold"
          >
            Código de 6 dígitos
          </label>
          <input
            id={`${fieldId}-code`}
            className={inputStyle}
            value={code}
            maxLength={6}
            inputMode="numeric"
            autoComplete="one-time-code"
            onChange={e => setCode(e.target.value.replace(/\D/g, ""))}
            placeholder="000000"
          />
        </>
      )}
      {!!secret && !status.data?.enabled && (
        <button
          className={`${buttonStyle} mt-3`}
          disabled={code.length !== 6 || enable.isPending}
          onClick={async () => {
            try {
              await enable.mutateAsync({ code });
              setSecret("");
              setUri("");
              setCode("");
              await status.refetch();
              toast.success("2FA ativado.");
            } catch (err) {
              message(err);
            }
          }}
        >
          Confirmar e ativar
        </button>
      )}
      {!!status.data?.enabled && (
        <button
          className="mt-3 rounded-xl border border-red-400 px-4 py-2 font-semibold text-red-700"
          disabled={!password || code.length !== 6 || disable.isPending}
          onClick={async () => {
            if (
              !window.confirm(
                "Desativar autenticação em duas etapas e encerrar todas as sessões?"
              )
            )
              return;
            try {
              await disable.mutateAsync({ password, code });
              window.location.assign("/login");
            } catch (err) {
              message(err);
            }
          }}
        >
          Desativar 2FA e sair
        </button>
      )}
      <div className="mt-6 border-t pt-5">
        <h4 className="font-semibold">Sessões de acesso</h4>
        <p className="mt-1 text-sm text-foreground">
          Sessões registradas: {sessions.data?.count ?? "…"}. Você pode encerrar
          todas as outras sessões e manter esta.
        </p>
        <button
          className={`${buttonStyle} mt-3`}
          disabled={!password || revoke.isPending}
          onClick={async () => {
            try {
              await revoke.mutateAsync({ password });
              await sessions.refetch();
              toast.success("Outras sessões encerradas.");
            } catch (err) {
              message(err);
            }
          }}
        >
          Encerrar outras sessões
        </button>
      </div>
    </section>
  );
}

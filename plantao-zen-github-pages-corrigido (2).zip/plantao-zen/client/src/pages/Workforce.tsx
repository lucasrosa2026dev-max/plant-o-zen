import { csvCell } from "@shared/csv";
import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  intersectsLocalDay,
  localDateKey,
  dayTimelinePosition,
} from "@shared/workforce";
import { toast } from "sonner";
import {
  Activity,
  AlertTriangle,
  Bell,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Download,
  HeartPulse,
  Plus,
  Search,
  ShieldCheck,
  X,
} from "lucide-react";

const exportDate = (d: Date | string) =>
  new Date(d).toLocaleString("pt-BR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
const fmt = (d: Date | string) =>
  new Date(d).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
const time = (d: Date | string) =>
  new Date(d).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });
const DAY_HOURS = Array.from({ length: 13 }, (_, i) => i * 2);
const COLORS = ["#246f69", "#456c83", "#75678b", "#8b713c"];
function Ring({
  value,
  label,
  number,
}: {
  value: number;
  label: string;
  number: string;
}) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <section className="pz-health-panel p-5">
      <p className="text-sm text-muted-foreground">{label}</p>
      <div className="mt-5 flex items-baseline gap-3">
        <strong className="text-4xl font-semibold tracking-tight">
          {number}
        </strong>
        <span className="text-xs text-muted-foreground">
          {pct.toFixed(0)}% dos plantões do dia
        </span>
      </div>
      <div
        role="progressbar"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        className="mt-5 h-1.5 overflow-hidden rounded-full bg-muted"
      >
        <div
          className="h-full rounded-full bg-primary"
          style={{ width: `${pct}%` }}
        />
      </div>
    </section>
  );
}
export default function Workforce() {
  const utils = trpc.useUtils();
  const shiftsQuery = trpc.workforce.list.useQuery(undefined, {
    refetchInterval: 30000,
  });
  const { data: shifts = [], isLoading } = shiftsQuery;
  const auditQuery = trpc.workforce.audit.useQuery();
  const { data: audit = [] } = auditQuery;
  const create = trpc.workforce.create.useMutation({
    onSuccess: () => {
      toast.success("Plantão cadastrado");
      void utils.workforce.invalidate();
      setOpen(false);
    },
    onError: e => toast.error(e.message),
  });
  const update = trpc.workforce.update.useMutation({
    onSuccess: () => {
      toast.success("Plantão atualizado");
      void utils.workforce.invalidate();
      setOpen(false);
      setEditingId(null);
    },
    onError: e => toast.error(e.message),
  });
  const cancel = trpc.workforce.cancel.useMutation({
    onSuccess: () => {
      toast.success("Plantão cancelado");
      void utils.workforce.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const attendance = trpc.workforce.attendance.useMutation({
    onSuccess: () => {
      toast.success("Presença registrada");
      void utils.workforce.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedDate, setSelectedDate] = useState(() => {
    const requested = new URLSearchParams(window.location.search).get("date");
    return requested &&
      /^\d{4}-\d{2}-\d{2}$/.test(requested) &&
      Number.isFinite(+new Date(requested + "T00:00:00"))
      ? requested
      : localDateKey();
  });
  const [form, setForm] = useState({
    professionalName: "",
    title: "",
    startsAt: "",
    endsAt: "",
  });
  const toLocalInput = (value: Date | string) => {
    const d = new Date(value);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  };
  const beginEdit = (s: (typeof shifts)[number]) => {
    setEditingId(s.id);
    setForm({
      professionalName: s.professionalName,
      title: s.title,
      startsAt: toLocalInput(s.startsAt),
      endsAt: toLocalInput(s.endsAt),
    });
    setOpen(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const beginCreate = () => {
    setEditingId(null);
    setForm({ professionalName: "", title: "", startsAt: "", endsAt: "" });
    setOpen(true);
  };
  const active = useMemo(
    () => shifts.filter(s => s.status !== "cancelled"),
    [shifts]
  );
  const day = useMemo(
    () =>
      active.filter(s =>
        intersectsLocalDay(s.startsAt, s.endsAt, selectedDate)
      ),
    [active, selectedDate]
  );
  const visible = day.filter(s =>
    (s.professionalName + " " + s.title)
      .toLowerCase()
      .includes(search.toLowerCase())
  );
  const professionals = Array.from(
    new Set(visible.map(s => s.professionalName))
  );
  const checked = day.filter(s => Boolean(s.checkInAt)).length;
  const coverage = day.length ? (checked / day.length) * 100 : 0;
  const overlaps = active.flatMap((s, i) =>
    active
      .slice(i + 1)
      .filter(
        t =>
          t.professionalName.toLowerCase() ===
            s.professionalName.toLowerCase() &&
          new Date(s.startsAt) < new Date(t.endsAt) &&
          new Date(t.startsAt) < new Date(s.endsAt)
      )
      .map(t => `${s.professionalName}: ${s.title} / ${t.title}`)
  );
  const exportCsv = () => {
    const rows = [
      [
        "Profissional",
        "Unidade / plantão",
        "Início",
        "Fim",
        "Status",
        "Check-in",
        "Check-out",
      ],
      ...active.map(s => [
        s.professionalName,
        s.title,
        exportDate(s.startsAt),
        exportDate(s.endsAt),
        s.status,
        s.checkInAt ? exportDate(s.checkInAt) : "",
        s.checkOutAt ? exportDate(s.checkOutAt) : "",
      ]),
    ];
    const blob = new Blob(
      ["\ufeff" + rows.map(r => r.map(csvCell).join(";")).join("\r\n")],
      { type: "text/csv;charset=utf-8" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "plantao-zen-health-escalas.csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  if (shiftsQuery.isError)
    return (
      <section role="alert" className="pz-health-panel space-y-4 p-6">
        <h1 className="text-xl font-semibold">Escalas indisponíveis</h1>
        <p>
          Não foi possível consultar os plantões. Os indicadores serão exibidos
          após uma consulta bem-sucedida.
        </p>
        <button
          className="pz-health-primary"
          disabled={shiftsQuery.isFetching}
          onClick={() => void shiftsQuery.refetch()}
        >
          Tentar novamente
        </button>
      </section>
    );
  if (isLoading)
    return (
      <section
        role="status"
        aria-label="Carregando escalas"
        className="pz-health-panel space-y-4 p-6"
      >
        <p>Carregando escalas e indicadores...</p>
        <div className="h-36 rounded-xl bg-muted motion-safe:animate-pulse" />
      </section>
    );
  return (
    <div className="pz-health-dashboard space-y-5 pb-8">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[.2em] text-primary">
            <HeartPulse size={16} /> ROTINA / AGENDA
          </div>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-foreground">
            Organize seus plantões
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Horários, presença e disponibilidade em um só lugar.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={exportCsv} className="pz-health-outline">
            <Download size={17} /> Exportar CSV
          </button>
          <button onClick={beginCreate} className="pz-health-primary">
            <Plus size={17} /> Novo plantão
          </button>
        </div>
      </header>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-card p-3 shadow-sm">
        <div className="flex items-center gap-2 text-sm font-medium text-foreground">
          <ShieldCheck size={18} className="text-teal-600" /> Central de
          operações{" "}
          <span className="rounded-full bg-teal-50 px-2 py-1 text-xs text-teal-700">
            Acompanhamento
          </span>
        </div>
        <div className="flex items-center gap-2">
          <CalendarDays size={17} className="text-muted-foreground" />
          <input
            aria-label="Data da escala"
            type="date"
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="rounded-lg border border-border p-2 text-sm"
          />
        </div>
      </div>
      {open && (
        <form
          className="pz-health-panel grid gap-3 p-5 sm:grid-cols-2"
          onSubmit={e => {
            e.preventDefault();
            if (new Date(form.endsAt) <= new Date(form.startsAt)) {
              toast.error("O término deve ser posterior ao início");
              return;
            }
            const payload = {
              professionalName: form.professionalName,
              title: form.title,
              startsAt: new Date(form.startsAt),
              endsAt: new Date(form.endsAt),
            };
            if (editingId !== null)
              update.mutate({ ...payload, id: editingId });
            else create.mutate(payload);
          }}
        >
          <div className="flex items-center justify-between sm:col-span-2">
            <h2 className="font-semibold">
              {editingId !== null ? "Editar plantão" : "Cadastrar plantão"}
            </h2>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Fechar"
            >
              <X size={18} />
            </button>
          </div>
          {(
            [
              { key: "professionalName", label: "Profissional", type: "text" },
              { key: "title", label: "Unidade / atividade", type: "text" },
              { key: "startsAt", label: "Início", type: "datetime-local" },
              { key: "endsAt", label: "Término", type: "datetime-local" },
            ] as const
          ).map(f => (
            <label key={f.key} className="grid gap-1 text-sm text-foreground">
              {f.label}
              <input
                required
                type={f.type}
                value={form[f.key]}
                onChange={e =>
                  setForm(p => ({ ...p, [f.key]: e.target.value }))
                }
                className="rounded-xl border border-border bg-card p-3 text-foreground"
              />
            </label>
          ))}
          <button
            disabled={create.isPending || update.isPending}
            className="pz-health-primary sm:col-span-2"
          >
            {create.isPending || update.isPending
              ? "Salvando..."
              : editingId !== null
                ? "Salvar alterações"
                : "Salvar plantão"}
          </button>
        </form>
      )}
      <div className="grid gap-4 lg:grid-cols-3">
        <Ring
          value={coverage}
          label="Presenças registradas"
          number={String(checked)}
        />
        <Ring
          value={
            day.length
              ? (day.filter(s => s.checkOutAt).length / day.length) * 100
              : 0
          }
          label="Plantões concluídos"
          number={String(day.filter(s => s.checkOutAt).length)}
        />
        <section className="pz-health-panel p-5">
          <div className="flex items-center gap-2 font-semibold text-foreground">
            <Bell size={17} /> Alertas importantes
          </div>
          <div className="mt-4 space-y-3">
            {overlaps.length > 0 ? (
              overlaps.slice(0, 3).map((s, i) => (
                <div
                  key={i}
                  className="flex gap-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-900"
                >
                  <AlertTriangle size={18} className="shrink-0" />
                  {s}
                </div>
              ))
            ) : (
              <div className="flex gap-3 rounded-xl bg-teal-50 p-3 text-sm text-teal-800">
                <CheckCircle2 size={18} className="shrink-0" /> Nenhum conflito
                de horário identificado.
              </div>
            )}
            <div className="flex gap-3 rounded-xl bg-accent p-3 text-sm text-primary">
              <Activity size={18} className="shrink-0" />
              {day.length} plantão(ões) previsto(s) para a data selecionada.
            </div>
          </div>
        </section>
      </div>
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.9fr)_minmax(290px,1fr)]">
        <section className="pz-health-panel min-w-0 overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-5">
            <div>
              <h2 className="font-semibold text-foreground">
                Linha do tempo da equipe
              </h2>
              <p className="mt-1 text-xs text-muted-foreground">
                Plantões por profissional · 24 horas
              </p>
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-border px-3">
              <Search size={16} className="text-muted-foreground" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                aria-label="Buscar profissional"
                placeholder="Buscar profissional"
                className="w-40 bg-transparent py-2 text-sm outline-none"
              />
            </div>
          </div>
          <div className="overflow-x-auto p-4">
            <div className="min-w-[720px]">
              <div className="grid grid-cols-[170px_repeat(12,minmax(0,1fr))] border-b border-border pb-3 text-xs text-muted-foreground">
                <span>Profissional</span>
                {DAY_HOURS.slice(0, 12).map(h => (
                  <span key={h} className="text-center">
                    {String(h).padStart(2, "0")}:00
                  </span>
                ))}
              </div>
              {isLoading ? (
                <p className="p-6 text-sm text-muted-foreground">
                  Carregando escalas...
                </p>
              ) : professionals.length === 0 ? (
                <p className="p-8 text-center text-sm text-muted-foreground">
                  Nenhuma escala nesta data. Cadastre um plantão para visualizar
                  a linha do tempo.
                </p>
              ) : (
                professionals.map((name, i) => (
                  <div
                    key={name}
                    className="grid grid-cols-[170px_minmax(0,1fr)] items-center border-b border-border py-3"
                  >
                    <div className="flex items-center gap-2 pr-2">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-bold text-primary">
                        {name
                          .split(" ")
                          .slice(0, 2)
                          .map(x => x[0])
                          .join("")
                          .toUpperCase()}
                      </div>
                      <span
                        className="truncate text-xs font-medium text-foreground"
                        title={name}
                      >
                        {name}
                      </span>
                    </div>
                    <div className="relative h-11 rounded-lg bg-[repeating-linear-gradient(to_right,#f1f4f9_0px,#f1f4f9_1px,transparent_1px,transparent_calc(100%/12))]">
                      {visible
                        .filter(s => s.professionalName === name)
                        .map(s => {
                          const position = dayTimelinePosition(
                            s.startsAt,
                            s.endsAt,
                            selectedDate
                          );
                          if (!position) return null;
                          return (
                            <div
                              key={s.id}
                              title={`${s.title}: ${time(s.startsAt)}–${time(s.endsAt)}`}
                              className="absolute top-1.5 flex h-8 items-center overflow-hidden rounded-lg px-2 text-[11px] font-medium text-white shadow-sm"
                              style={{
                                left: `${position.left}%`,
                                width: `${position.width}%`,
                                background: COLORS[i % COLORS.length],
                              }}
                            >
                              <span className="truncate">{s.title}</span>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </section>
        <section className="pz-health-panel overflow-hidden">
          <div className="border-b border-border p-5">
            <h2 className="font-semibold text-foreground">
              Disponibilidade da equipe
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Presença e ações de plantão
            </p>
          </div>
          <div className="max-h-[460px] space-y-2 overflow-y-auto p-3">
            {day.length === 0 ? (
              <p className="p-5 text-center text-sm text-muted-foreground">
                Sem profissionais escalados para esta data.
              </p>
            ) : (
              day.map(s => (
                <div key={s.id} className="rounded-xl bg-muted p-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent text-sm font-semibold text-primary">
                      {s.professionalName.slice(0, 1).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-foreground">
                        {s.professionalName}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {s.title}
                      </p>
                    </div>
                    <span
                      className={`h-2.5 w-2.5 rounded-full ${s.checkInAt && !s.checkOutAt ? "bg-emerald-500" : "bg-slate-300"}`}
                    />
                  </div>
                  <div className="mt-3 flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock3 size={13} />
                      {time(s.startsAt)} – {time(s.endsAt)}
                    </span>
                    {!s.checkInAt ? (
                      <button
                        disabled={attendance.isPending}
                        onClick={() =>
                          attendance.mutate({ id: s.id, action: "in" })
                        }
                        className="rounded-full bg-primary px-3 py-1.5 text-xs font-semibold text-white"
                      >
                        Check-in
                      </button>
                    ) : !s.checkOutAt ? (
                      <button
                        disabled={attendance.isPending}
                        onClick={() =>
                          attendance.mutate({ id: s.id, action: "out" })
                        }
                        className="rounded-full bg-teal-700 px-3 py-1.5 text-xs font-semibold text-white"
                      >
                        Check-out
                      </button>
                    ) : (
                      <span className="text-xs font-medium text-teal-700">
                        Concluído
                      </span>
                    )}
                  </div>
                  {s.status === "planned" && !s.checkInAt && (
                    <div className="mt-2 flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => beginEdit(s)}
                        className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground"
                      >
                        Editar
                      </button>
                      <button
                        type="button"
                        disabled={cancel.isPending}
                        onClick={() => {
                          if (
                            window.confirm(
                              `Cancelar o plantão de ${s.professionalName}?`
                            )
                          )
                            cancel.mutate({ id: s.id });
                        }}
                        className="rounded-lg border border-red-200 px-3 py-1.5 text-xs font-semibold text-red-700"
                      >
                        Cancelar
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </section>
      </div>
      <section className="pz-health-panel p-5">
        <div className="flex items-center gap-2 font-semibold text-foreground">
          <ShieldCheck size={18} className="text-teal-600" /> Histórico e
          auditoria
        </div>
        <div className="mt-3">
          {auditQuery.isError ? (
            <p role="alert" className="text-sm text-red-700">
              Histórico indisponível.{" "}
              <button
                onClick={() => void auditQuery.refetch()}
                className="underline"
              >
                Tentar novamente
              </button>
            </p>
          ) : auditQuery.isLoading ? (
            <p role="status">Carregando histórico...</p>
          ) : audit.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Nenhum evento registrado.
            </p>
          ) : (
            audit.slice(0, 8).map(a => (
              <div
                key={a.id}
                className="flex justify-between gap-3 border-t border-border py-3 text-sm"
              >
                <span>
                  {(
                    {
                      "shift.created": "Plantão cadastrado",
                      "shift.updated": "Plantão atualizado",
                      "shift.cancelled": "Plantão cancelado",
                      "attendance.in": "Entrada registrada",
                      "attendance.out": "Saída registrada",
                    } as Record<string, string>
                  )[a.action] ?? a.action}
                </span>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {fmt(a.createdAt)}
                </span>
              </div>
            ))
          )}
        </div>
      </section>
      <p className="text-xs text-muted-foreground">
        Indicadores calculados a partir dos registros do sistema. Este painel
        não contém informações financeiras. Presença administrativa não
        substitui registro de ponto legal.
      </p>
    </div>
  );
}

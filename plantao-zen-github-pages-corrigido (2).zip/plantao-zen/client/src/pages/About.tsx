import {
  CalendarDays,
  HeartPulse,
  MessageCircle,
  ShieldCheck,
  ArrowRight,
  Watch,
} from "lucide-react";
import { Link } from "wouter";
import PublicLayout from "@/components/PublicLayout";
const features = [
  {
    icon: CalendarDays,
    title: "Uma rotina organizada",
    text: "Cadastre horários, acompanhe presenças e consulte os plantões em uma linha do tempo.",
  },
  {
    icon: HeartPulse,
    title: "Espaço para você",
    text: "Registre como está se sentindo e mantenha suas anotações de cuidado por perto.",
  },
  {
    icon: MessageCircle,
    title: "Conexões de confiança",
    text: "Organize seus contatos e converse com outros participantes, com controles de privacidade.",
  },
  {
    icon: ShieldCheck,
    title: "Informação quando importa",
    text: "Prepare seu plano pessoal de segurança e acesse os recursos de emergência.",
  },
];
export default function About() {
  return (
    <PublicLayout>
      <main>
        <section className="pz-about-intro">
          <p className="pz-eyebrow">SOBRE O PLANTÃO ZEN</p>
          <h1>
            Quem cuida também
            <br />
            precisa de cuidado.
          </h1>
          <p>
            Uma agenda para sua rotina. Um espaço para perceber como você está.
            Uma rede de confiança mais próxima.
          </p>
          <Link href="/demo" className="pz-health-primary">
            Conhecer a experiência <ArrowRight size={17} />
          </Link>
        </section>
        <div className="grid gap-5 sm:grid-cols-2 mt-10">
          {features.map(({ icon: Icon, title, text }, i) => (
            <section className="pz-health-panel p-7" key={title}>
              <div className="flex justify-between items-center">
                <span className="pz-care-icon">
                  <Icon size={22} />
                </span>
                <span className="text-xs text-muted-foreground">0{i + 1}</span>
              </div>
              <h2 className="mt-6 text-lg font-semibold">{title}</h2>
              <p className="mt-3 text-sm leading-7 text-muted-foreground">
                {text}
              </p>
            </section>
          ))}
        </div>
        <section className="mt-10 grid gap-7 border-t border-border pt-8 md:grid-cols-2">
          <div>
            <p className="pz-eyebrow">CONSTRUÍDO PARA A ROTINA DE CUIDADO</p>
            <h2 className="text-2xl font-medium tracking-tight">
              Clareza, autonomia
              <br />e organização.
            </h2>
          </div>
          <div className="text-sm leading-7 text-muted-foreground">
            <p>
              O Plantão Zen reúne organização de plantões, registros pessoais e
              comunicação para profissionais de saúde, estudantes e pessoas que
              desejam estruturar sua rede de apoio.
            </p>
            <p className="mt-4">
              Os registros de bem-estar são pessoais. Não representam
              diagnóstico e não substituem atendimento profissional.
            </p>
          </div>
        </section>
        <section className="pz-health-panel mt-9 p-6">
          <div className="flex gap-3 items-center">
            <Watch size={20} />
            <h2 className="font-semibold">Dispositivos e notificações</h2>
          </div>
          <p className="mt-3 text-sm leading-7 text-muted-foreground">
            O funcionamento de notificações e relógios depende da configuração
            do servidor, das permissões e do modelo conectado. A integração Wear
            OS ainda requer validação em dispositivo. O uso do Colmi Fit não
            confirma compatibilidade com o aplicativo nativo Wear OS.
          </p>
          <p className="mt-3 text-sm leading-7 text-muted-foreground">
            A demonstração usa dados fictícios. Alertas simulados não notificam
            contatos nem acionam atendimento.
          </p>
        </section>
      </main>
    </PublicLayout>
  );
}

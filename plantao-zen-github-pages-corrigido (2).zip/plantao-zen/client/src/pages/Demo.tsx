import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { getQueryKey } from "@trpc/react-query";
import { httpBatchLink } from "@trpc/client";
import superjson from "superjson";
import { useLocation, Link } from "wouter";
import { Info, Plus, RotateCcw } from "lucide-react";
import { trpc } from "@/lib/trpc";
import AppShell from "@/components/AppShell";
import Overview from "./Overview";
import { localDateKey } from "@shared/workforce";
function createDemoClient() {
  const cache = new QueryClient({
    defaultOptions: { queries: { staleTime: Infinity, retry: false } },
  });
  const now = new Date();
  const date = localDateKey(now);
  const starts = new Date(`${date}T07:00:00`);
  const ends = new Date(`${date}T19:00:00`);
  const tomorrow = new Date(starts);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowEnd = new Date(tomorrow);
  tomorrowEnd.setHours(19);
  const base = {
    ownerId: 0,
    hourlyCents: 0,
    status: "planned",
    checkInAt: null,
    checkOutAt: null,
    createdAt: now,
  };
  cache.setQueryData(getQueryKey(trpc.workforce.list, undefined, "query"), [
    {
      ...base,
      id: 1,
      professionalName: "Marina Oliveira",
      title: "UTI adulto · Plantão diurno",
      startsAt: starts,
      endsAt: ends,
    },
    {
      ...base,
      id: 2,
      professionalName: "Rafael Mendes",
      title: "Pronto atendimento",
      startsAt: tomorrow,
      endsAt: tomorrowEnd,
    },
  ]);
  cache.setQueryData(
    getQueryKey(trpc.contacts.list, undefined, "query"),
    ["Ana Souza", "Rafael Mendes", "Luciana Costa"].map((name, i) => ({
      id: i,
      userId: 0,
      name,
      phone: "",
      email: null,
      relationship: "Rede de apoio",
      isEmergency: 1,
      emergencyPriority: i,
      linkedOpenId: null,
      createdAt: now,
      updatedAt: now,
    }))
  );
  cache.setQueryData(getQueryKey(trpc.checkins.list, undefined, "query"), [
    { id: 1, userId: 0, mood: "Estou bem", notes: null, createdAt: now },
  ]);
  cache.setQueryData(getQueryKey(trpc.inbox.list, undefined, "query"), [
    {
      id: 1,
      userId: 0,
      relatedEmergencyId: null,
      eventType: "demo",
      title: "Este espaço é uma demonstração",
      body: "Os plantões, contatos e registros desta tela são fictícios.",
      isRead: 0,
      createdAt: now,
    },
  ]);
  cache.setQueryData(
    getQueryKey(trpc.emergency.active, undefined, "query"),
    null
  );
  return cache;
}
export default function Demo() {
  const [, navigate] = useLocation();
  const [cache] = useState(createDemoClient);
  // An isolated cache prevents sample data from appearing in an authenticated account.
  const [client] = useState(() =>
    trpc.createClient({
      links: [
        httpBatchLink({
          url: "/api/trpc",
          transformer: superjson,
          fetch: async () => {
            throw new Error("A demonstração não faz chamadas ao servidor.");
          },
        }),
      ],
    })
  );
  const [sos, setSos] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    title: "",
    start: "07:00",
    end: "19:00",
  });
  const [revision, setRevision] = useState(0);
  return (
    <trpc.Provider client={client} queryClient={cache}>
      <QueryClientProvider client={cache}>
        <AppShell
          user={{ name: "Marina · Demonstração" }}
          location="/"
          setLocation={navigate}
          logout={async () => navigate("/login")}
          preview
        >
          <div className="pz-demo-banner">
            <Info size={17} />
            <p>
              <strong>Prévia interativa.</strong> Dados fictícios, sem envio de
              alertas. As outras áreas exigem acesso à conta.
            </p>
            <Link href="/login">Entrar →</Link>
          </div>
          <Overview user={{ name: "Marina" }} preview key={revision} />
          <section className="pz-health-panel p-6 mt-7">
            <div className="flex flex-wrap gap-4 items-center justify-between">
              <div>
                <p className="pz-eyebrow">
                  EXPERIMENTE SEM ALTERAR DADOS REAIS
                </p>
                <h2 className="text-lg font-semibold">Simulações locais</h2>
              </div>
              <button
                className="pz-health-outline"
                onClick={() => {
                  cache.clear();
                  const initial = createDemoClient();
                  initial
                    .getQueryCache()
                    .getAll()
                    .forEach(q => cache.setQueryData(q.queryKey, q.state.data));
                  setSos(false);
                  setFormOpen(false);
                  setRevision(r => r + 1);
                }}
              >
                <RotateCcw size={16} /> Reiniciar prévia
              </button>
            </div>
            <div className="flex flex-wrap gap-3 mt-5">
              <button
                className="pz-health-primary"
                onClick={() => setFormOpen(!formOpen)}
              >
                <Plus size={17} /> Adicionar plantão fictício
              </button>
              <button
                className="pz-health-outline"
                onClick={() => setSos(!sos)}
              >
                {sos ? "Encerrar simulação SOS" : "Simular SOS"}
              </button>
            </div>
            {sos && (
              <p
                className="mt-4 rounded-lg bg-red-50 p-4 text-sm text-red-800"
                role="status"
              >
                Simulação em andamento. Nenhum contato foi notificado e nenhum
                atendimento foi acionado.
              </p>
            )}
            {formOpen && (
              <form
                className="grid sm:grid-cols-2 gap-4 mt-6"
                onSubmit={e => {
                  e.preventDefault();
                  const day = localDateKey();
                  const startsAt = new Date(`${day}T${form.start}`);
                  const endsAt = new Date(`${day}T${form.end}`);
                  if (endsAt <= startsAt) endsAt.setDate(endsAt.getDate() + 1);
                  const key = getQueryKey(
                    trpc.workforce.list,
                    undefined,
                    "query"
                  );
                  cache.setQueryData(key, (old: unknown) => [
                    ...(Array.isArray(old) ? old : []),
                    {
                      id: Date.now(),
                      ownerId: 0,
                      professionalName: form.name,
                      title: form.title,
                      startsAt,
                      endsAt,
                      status: "planned",
                      hourlyCents: 0,
                      checkInAt: null,
                      checkOutAt: null,
                      createdAt: new Date(),
                    },
                  ]);
                  setFormOpen(false);
                }}
              >
                {(
                  [
                    {
                      key: "name",
                      label: "Profissional fictício",
                      type: "text",
                    },
                    {
                      key: "title",
                      label: "Unidade / atividade",
                      type: "text",
                    },
                    { key: "start", label: "Início", type: "time" },
                    { key: "end", label: "Término", type: "time" },
                  ] as const
                ).map(f => (
                  <label key={f.key} className="grid gap-2 text-xs">
                    {f.label}
                    <input
                      required
                      type={f.type}
                      value={form[f.key]}
                      onChange={e =>
                        setForm({ ...form, [f.key]: e.target.value })
                      }
                      className="rounded-lg border border-input bg-card p-3"
                    />
                  </label>
                ))}
                <button className="pz-health-primary sm:col-span-2">
                  Adicionar à demonstração
                </button>
              </form>
            )}
          </section>
        </AppShell>
      </QueryClientProvider>
    </trpc.Provider>
  );
}

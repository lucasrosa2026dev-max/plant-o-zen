import PageHeading from "@/components/PageHeading";
import { useEffect, useState } from "react";
import {
  Activity,
  Check,
  HeartHandshake,
  MapPin,
  MessageCircle,
  Phone,
  Send,
  ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type CheckinMood =
  | "Estou bem"
  | "Preciso de atenção"
  | "Estou ansioso"
  | "Preciso conversar"
  | "Preciso de apoio";
const moods: CheckinMood[] = [
  "Estou bem",
  "Preciso de atenção",
  "Estou ansioso",
  "Preciso conversar",
  "Preciso de apoio",
];
const quickMessages = [
  "Preciso conversar.",
  "Pode me ligar?",
  "Estou em um momento difícil.",
  "Estou seguro, não precisa responder.",
];

function Panel({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`pz-card rounded-2xl border border-border bg-card p-6 shadow-sm ${className}`}
    >
      {children}
    </section>
  );
}
function Button({
  children,
  onClick,
  variant = "primary",
  type = "button",
  disabled = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost";
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  const styles = {
    primary: "bg-primary text-white hover:bg-primary",
    secondary: "bg-[#2f4d5b] text-white hover:bg-[#263f4b]",
    ghost: "bg-muted text-muted-foreground hover:bg-muted",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`pz-button inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${styles[variant]}`}
    >
      {children}
    </button>
  );
}
function TextArea({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={event => onChange(event.target.value)}
      placeholder={placeholder}
      className="pz-input min-h-28 w-full resize-y rounded-xl border border-border bg-card px-3 py-3 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/15"
    />
  );
}

export function CheckinPage() {
  const utils = trpc.useUtils();
  const query = trpc.checkins.list.useQuery();
  const create = trpc.checkins.create.useMutation({
    onSuccess: () => utils.checkins.list.invalidate(),
  });
  const [mood, setMood] = useState<CheckinMood>("Estou bem");
  const [notes, setNotes] = useState("");
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await create.mutateAsync({ mood, notes: notes || undefined });
      setNotes("");
      toast.success("Seu registro foi salvo.");
    } catch {
      toast.error("Não foi possível salvar o registro. Tente novamente.");
    }
  };
  const checkins = query.data ?? [];
  return (
    <div className="max-w-5xl">
      <PageHeading
        eyebrow="Um minuto para você"
        title="Como você está hoje?"
        description="Registre como você está hoje para acompanhar sua rotina. Este registro não é diagnóstico médico."
      />
      <div className="grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
        <Panel>
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-muted text-warning-ink">
              <HeartHandshake className="h-5 w-5" />
            </span>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.15em] text-muted-foreground">
                Agora
              </p>
              <h3 className="mt-1 text-xl font-bold text-foreground">
                Como você está?
              </h3>
            </div>
          </div>
          <form onSubmit={submit} className="mt-6 grid gap-4">
            <div className="grid gap-2">
              {moods.map(option => (
                <button
                  type="button"
                  key={option}
                  onClick={() => setMood(option)}
                  aria-pressed={mood === option}
                  className={`pz-mood-choice rounded-xl border p-3 text-left text-sm font-semibold transition ${mood === option ? "border-primary bg-muted text-primary" : "border-border bg-card text-muted-foreground hover:border-border"}`}
                >
                  {option}
                </button>
              ))}
            </div>
            <label className="grid gap-2 text-sm font-semibold text-foreground">
              O que você quer registrar?
              <TextArea
                value={notes}
                onChange={setNotes}
                placeholder="Uma frase já é suficiente..."
              />
            </label>
            <Button type="submit" disabled={create.isPending}>
              <Check className="h-4 w-4" />{" "}
              {create.isPending ? "Salvando..." : "Salvar check-in"}
            </Button>
          </form>
        </Panel>
        <Panel>
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.15em] text-muted-foreground">
                Acompanhamento
              </p>
              <h3 className="mt-1 text-xl font-bold text-foreground">
                Seus últimos registros
              </h3>
            </div>
            <Activity className="h-5 w-5 text-primary" />
          </div>
          {query.isError ? (
            <div className="pz-query-error" role="status">
              Não foi possível carregar os registros.
              <button onClick={() => void query.refetch()}>
                Tentar novamente
              </button>
            </div>
          ) : query.isPending ? (
            <p className="pz-empty">Carregando registros…</p>
          ) : checkins.length === 0 ? (
            <p className="mt-7 rounded-xl bg-muted p-5 text-sm leading-6 text-muted-foreground">
              Seu primeiro check-in aparecerá aqui. Use este espaço sem pressão
              e no seu ritmo.
            </p>
          ) : (
            <div className="mt-5 grid gap-3">
              {checkins.map(item => (
                <div
                  key={item.id}
                  className="rounded-xl border border-border p-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-bold text-primary">
                      {item.mood}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Intl.DateTimeFormat("pt-BR", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      }).format(new Date(item.createdAt))}
                    </span>
                  </div>
                  {item.notes && (
                    <p className="mt-3 text-sm leading-6 text-muted-foreground">
                      {item.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

export function SafetyPlanPage() {
  const query = trpc.safetyPlan.get.useQuery();
  const save = trpc.safetyPlan.save.useMutation({
    onSuccess: () => query.refetch(),
  });
  const clear = trpc.safetyPlan.clear.useMutation({
    onSuccess: () => {
      setForm({
        safeLocation: "",
        medications: "",
        allergies: "",
        priorityContacts: "",
        instructions: "",
        localServices: "",
      });
      void query.refetch();
    },
  });
  const [form, setForm] = useState({
    safeLocation: "",
    medications: "",
    allergies: "",
    priorityContacts: "",
    instructions: "",
    localServices: "",
  });
  useEffect(() => {
    if (query.data)
      setForm({
        safeLocation: query.data.safeLocation || "",
        medications: query.data.medications || "",
        allergies: query.data.allergies || "",
        priorityContacts: query.data.priorityContacts || "",
        instructions: query.data.instructions || "",
        localServices: query.data.localServices || "",
      });
  }, [query.data]);
  const update = (key: keyof typeof form, value: string) =>
    setForm(previous => ({ ...previous, [key]: value }));
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      await save.mutateAsync(form);
      toast.success("Plano de segurança salvo.");
    } catch {
      toast.error("Não foi possível salvar o plano. Tente novamente.");
    }
  };
  if (query.isPending)
    return (
      <p className="pz-empty" role="status">
        Carregando seu plano de segurança…
      </p>
    );
  if (query.isError)
    return (
      <section className="pz-health-panel p-6">
        <h1 className="text-xl font-semibold">Plano de segurança</h1>
        <p className="mt-3 text-muted-foreground">
          Não foi possível carregar o plano. Tente novamente antes de editar.
        </p>
        <button
          className="pz-health-outline mt-4"
          onClick={() => void query.refetch()}
        >
          Tentar novamente
        </button>
      </section>
    );
  return (
    <div className="max-w-5xl">
      <PageHeading
        eyebrow="Para momentos difíceis"
        title="Plano pessoal de segurança"
        description="Organize informações que você gostaria de ter à mão. Salve somente o que fizer sentido para você."
      />
      <Panel>
        <div className="flex items-start gap-3 rounded-xl bg-muted p-4">
          <ShieldCheck className="mt-0.5 h-5 w-5 text-primary" />
          <p className="text-sm leading-6 text-muted-foreground">
            Estas informações ficam vinculadas à sua conta e só aparecem para
            você. Elas não substituem atendimento médico ou serviços de
            emergência.
          </p>
        </div>
        <form onSubmit={submit} className="mt-6 grid gap-5 sm:grid-cols-2">
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Local seguro
            <textarea
              value={form.safeLocation}
              onChange={event => update("safeLocation", event.target.value)}
              placeholder="Onde você costuma se sentir seguro?"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Medicamentos importantes
            <textarea
              value={form.medications}
              onChange={event => update("medications", event.target.value)}
              placeholder="Somente o que você deseja lembrar"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Alergias e restrições
            <textarea
              value={form.allergies}
              onChange={event => update("allergies", event.target.value)}
              placeholder="Informações relevantes para seu cuidado"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Contatos prioritários
            <textarea
              value={form.priorityContacts}
              onChange={event => update("priorityContacts", event.target.value)}
              placeholder="Quem deve ser procurado primeiro?"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Instrução para contatos
            <textarea
              value={form.instructions}
              onChange={event => update("instructions", event.target.value)}
              placeholder="O que costuma ajudar você?"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <label className="grid gap-2 text-sm font-semibold text-foreground">
            Serviços locais de emergência
            <textarea
              value={form.localServices}
              onChange={event => update("localServices", event.target.value)}
              placeholder="Ex.: SAMU 192, serviço local"
              className="min-h-24 rounded-xl border border-border bg-card p-3 text-sm"
            />
          </label>
          <div className="flex flex-wrap gap-3 sm:col-span-2">
            <Button type="submit" disabled={save.isPending}>
              <Check className="h-4 w-4" />{" "}
              {save.isPending ? "Salvando..." : "Salvar plano"}
            </Button>
            <Button
              variant="ghost"
              onClick={() => {
                if (window.confirm("Apagar todo o plano de segurança?"))
                  void clear.mutateAsync();
              }}
              disabled={clear.isPending}
            >
              Apagar plano
            </Button>
          </div>
        </form>
      </Panel>
    </div>
  );
}

export function MessagesPage() {
  const query = trpc.contacts.list.useQuery();
  const send = trpc.contacts.sendMessage.useMutation();
  const [contactId, setContactId] = useState<number | undefined>();
  const [message, setMessage] = useState(quickMessages[0]);
  const linkedContacts = (query.data ?? []).filter(
    contact => contact.linkedOpenId
  );
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!contactId) {
      toast("Escolha um contato vinculado.");
      return;
    }
    await send.mutateAsync({ contactId, message });
    toast("Mensagem enviada para a caixa de entrada do contato.");
  };
  return (
    <div className="max-w-4xl">
      <PageHeading
        eyebrow="Comunicação sem complicar"
        title="Mensagens rápidas"
        description="Envie uma mensagem para contatos vinculados ao Plantão Zen. Para outros contatos, use SMS ou telefone na área Contatos."
      />
      <Panel>
        <div className="flex items-start gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-muted text-primary">
            <MessageCircle className="h-5 w-5" />
          </span>
          <div>
            <h3 className="text-xl font-bold text-foreground">
              Escolha uma mensagem
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Você pode editar antes de enviar.
            </p>
          </div>
        </div>
        {linkedContacts.length === 0 ? (
          <div className="mt-6 rounded-xl bg-warning-soft p-5 text-sm leading-6 text-warning-ink">
            Nenhum contato vinculado ainda. Vincule uma conta Plantão Zen na
            área Contatos para usar a inbox interna.
          </div>
        ) : (
          <form onSubmit={submit} className="mt-6 grid gap-5">
            <label className="grid gap-2 text-sm font-semibold text-foreground">
              Enviar para
              <select
                value={contactId ?? ""}
                onChange={event =>
                  setContactId(Number(event.target.value) || undefined)
                }
                className="h-11 rounded-xl border border-border bg-card px-3 text-sm"
              >
                <option value="">Selecione um contato</option>
                {linkedContacts.map(contact => (
                  <option key={contact.id} value={contact.id}>
                    {contact.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="flex flex-wrap gap-2">
              {quickMessages.map(item => (
                <button
                  type="button"
                  key={item}
                  onClick={() => setMessage(item)}
                  className={`rounded-full border px-3 py-2 text-xs font-semibold ${message === item ? "border-primary bg-muted text-primary" : "border-border text-muted-foreground"}`}
                >
                  {item}
                </button>
              ))}
            </div>
            <textarea
              value={message}
              onChange={event => setMessage(event.target.value)}
              className="min-h-28 rounded-xl border border-border bg-card p-3 text-sm"
            />
            <Button type="submit" disabled={send.isPending}>
              <Send className="h-4 w-4" />{" "}
              {send.isPending ? "Enviando..." : "Enviar mensagem"}
            </Button>
          </form>
        )}
        <div className="mt-8 grid gap-3 border-t border-border pt-6 sm:grid-cols-2">
          <div className="rounded-xl bg-muted p-4">
            <MapPin className="h-4 w-4 text-primary" />
            <p className="mt-2 text-sm font-bold text-foreground">
              SMS externo
            </p>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">
              Disponível pelos botões de telefone e mensagem dos contatos,
              conforme o aparelho.
            </p>
          </div>
          <div className="rounded-xl bg-muted p-4">
            <Phone className="h-4 w-4 text-primary" />
            <p className="mt-2 text-sm font-bold text-foreground">Ligação</p>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">
              O app não inicia ligações sem sua confirmação.
            </p>
          </div>
        </div>
      </Panel>
    </div>
  );
}

import { postAuth } from "@/lib/authRequest";
import { useRef, useState, type FormEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  CheckCheck,
  Eye,
  EyeOff,
  HeartPulse,
  LockKeyhole,
  Mail,
  ShieldCheck,
  UserRound,
  LoaderCircle,
  AlertCircle,
} from "lucide-react";
import "./login.css";

export default function LoginScreen({
  register = false,
}: {
  register?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [recoveryMode, setRecoveryMode] = useState<"request" | "reset" | null>(
    () =>
      new URLSearchParams(window.location.search).has("reset") ? "reset" : null
  );
  const [feedback, setFeedback] = useState("");
  const [twoFactorRequired, setTwoFactorRequired] = useState(false);
  const [totpCode, setTotpCode] = useState("");
  const [error, setError] = useState("");
  const [visible, setVisible] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [capsLock, setCapsLock] = useState(false);
  const errorRef = useRef<HTMLDivElement>(null);
  const submitting = useRef(false);
  const mismatch =
    (register || recoveryMode === "reset") &&
    confirmation.length > 0 &&
    password !== confirmation;

  function showError(message: string) {
    setError(message);
    requestAnimationFrame(() => errorRef.current?.focus());
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    if ((register || recoveryMode === "reset") && password !== confirmation) {
      showError(
        "As senhas não conferem. Digite a mesma senha nos dois campos."
      );
      return;
    }
    const data = new FormData(event.currentTarget);
    submitting.current = true;
    setBusy(true);
    setError("");
    setFeedback("");
    try {
      if (recoveryMode) {
        await postAuth(
          recoveryMode === "request" ? "forgot-password" : "reset-password",
          recoveryMode === "request"
            ? { email: String(data.get("email")).trim() }
            : {
                token: new URLSearchParams(window.location.search).get("reset"),
                password,
              }
        );
        setFeedback(
          recoveryMode === "request"
            ? "Se o e-mail estiver cadastrado, enviaremos um link válido por 10 minutos."
            : "Senha alterada! Entre novamente com sua nova senha."
        );
        if (recoveryMode === "reset") {
          window.history.replaceState(null, "", "/login");
          setRecoveryMode(null);
          setPassword("");
          setConfirmation("");
          setTotpCode("");
          setTwoFactorRequired(false);
        }
        return;
      }
      const result = await postAuth(register ? "register" : "login", {
        email: String(data.get("email")).trim(),
        password,
        ...(register
          ? { name: String(data.get("name")).trim() }
          : totpCode
            ? { totpCode }
            : {}),
      });
      if ("requires2fa" in result) {
        setTwoFactorRequired(true);
        return;
      }
      window.location.assign("/");
    } catch (err) {
      showError(
        err instanceof Error
          ? err.message
          : "Não foi possível concluir. Tente novamente."
      );
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  }

  return (
    <main className="zen-access">
      <section className="zen-story" aria-label="Plantão Zen Health">
        <a
          className="zen-brand"
          href="/login"
          aria-label="Plantão Zen Health — entrar"
        >
          <span className="zen-brand-icon">
            <HeartPulse size={27} />
          </span>
          <span>
            plantão<span className="zen-brand-light">zen</span>
            <small>HEALTH</small>
          </span>
        </a>
        <div className="zen-story-content">
          <p className="zen-eyebrow">
            <span /> CUIDADO EM CADA TURNO
          </p>
          <h1>
            Seu plantão
            <br />
            em ordem.
            <br />
            <em>Você em paz.</em>
          </h1>
          <p className="zen-story-description">
            Um lugar para organizar sua rotina, estar perto de quem importa e
            cuidar de você.
          </p>
          <div
            className="zen-preview"
            aria-label="Ilustração da organização de plantões, com dados de exemplo"
          >
            <div className="zen-preview-heading">
              <span>
                <CalendarDays size={17} /> Sua semana, mais leve
              </span>
              <small>EXEMPLO</small>
            </div>
            <div className="zen-week" aria-hidden="true">
              {["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"].map(
                (day, i) => (
                  <div className={i === 2 ? "selected" : ""} key={day}>
                    <span>{day}</span>
                    <strong>{12 + i}</strong>
                    <i
                      className={
                        i === 0 || i === 2 || i === 4 ? "has-shift" : ""
                      }
                    />
                  </div>
                )
              )}
            </div>
            <div className="zen-shift">
              <span className="zen-shift-icon">
                <HeartPulse size={21} />
              </span>
              <div>
                <strong>Plantão diurno</strong>
                <span>07:00 – 19:00 · Unidade de saúde</span>
              </div>
              <CheckCheck size={20} />
            </div>
            <div className="zen-preview-bottom">
              <span>
                <span className="zen-mini-dot" /> Espaço para o que importa
              </span>
              <span>12h</span>
            </div>
          </div>
          <div className="zen-story-features">
            <span>
              <CalendarDays size={17} /> Sua rotina
            </span>
            <span>
              <HeartPulse size={17} /> Seu cuidado
            </span>
            <span>
              <ShieldCheck size={17} /> Sua rede
            </span>
          </div>
        </div>
        <p className="zen-story-footer">
          Feito para quem cuida. Pensado para você.
        </p>
        <div className="zen-orbit zen-orbit-one" aria-hidden="true" />
        <div className="zen-orbit zen-orbit-two" aria-hidden="true" />
      </section>
      <section className="zen-form-side" aria-labelledby="access-heading">
        <div className="zen-top-link">
          <span>{register ? "Já tem uma conta?" : "Ainda não tem conta?"}</span>
          <a href={register ? "/login" : "/register"}>
            {register ? "Entrar" : "Criar conta"}
            <ArrowUpRight size={16} />
          </a>
        </div>
        <div className="zen-form-content">
          <div className="zen-form-symbol">
            <HeartPulse size={25} />
          </div>
          <p className="zen-form-eyebrow">SEU ESPAÇO DE CUIDADO</p>
          <h2 id="access-heading">
            {recoveryMode === "request"
              ? "Recupere seu acesso."
              : recoveryMode === "reset"
                ? "Crie uma nova senha."
                : register
                  ? "Comece por você."
                  : "Que bom ter você aqui."}
          </h2>
          <p className="zen-form-description">
            {register
              ? "Crie sua conta e dê mais tranquilidade à sua rotina."
              : "Entre na sua conta e encontre tudo no seu lugar."}
          </p>
          <form onSubmit={submit} aria-busy={busy}>
            <fieldset disabled={busy}>
              {register && !recoveryMode && (
                <div className="zen-field">
                  <label htmlFor="access-name">Seu nome</label>
                  <div className="zen-input-wrap">
                    <UserRound size={18} />
                    <input
                      id="access-name"
                      name="name"
                      autoComplete="name"
                      placeholder="Como podemos chamar você?"
                      required
                      minLength={2}
                      maxLength={120}
                    />
                  </div>
                </div>
              )}
              {recoveryMode !== "reset" && (
                <div className="zen-field">
                  <label htmlFor="access-email">E-mail</label>
                  <div className="zen-input-wrap">
                    <Mail size={18} />
                    <input
                      id="access-email"
                      name="email"
                      type="email"
                      inputMode="email"
                      autoComplete="email"
                      autoCapitalize="none"
                      spellCheck={false}
                      placeholder="voce@exemplo.com"
                      required
                      maxLength={254}
                    />
                  </div>
                </div>
              )}
              {recoveryMode !== "request" && (
                <div className="zen-field">
                  <label htmlFor="access-password">
                    {recoveryMode === "reset"
                      ? "Nova senha"
                      : register
                        ? "Crie uma senha"
                        : "Senha"}
                  </label>
                  <div className="zen-input-wrap">
                    <LockKeyhole size={18} />
                    <input
                      id="access-password"
                      name="password"
                      type={visible ? "text" : "password"}
                      autoComplete={
                        register || recoveryMode === "reset"
                          ? "new-password"
                          : "current-password"
                      }
                      placeholder={
                        register
                          ? "Pelo menos 12 caracteres"
                          : "Digite sua senha"
                      }
                      required
                      minLength={12}
                      maxLength={128}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      onKeyUp={e => setCapsLock(e.getModifierState("CapsLock"))}
                      onKeyDown={e =>
                        setCapsLock(e.getModifierState("CapsLock"))
                      }
                      onBlur={() => setCapsLock(false)}
                      aria-describedby={register ? "password-hint" : undefined}
                    />
                    <button
                      className="zen-password-toggle"
                      type="button"
                      onClick={() => setVisible(v => !v)}
                      aria-label={visible ? "Ocultar senha" : "Mostrar senha"}
                      aria-pressed={visible}
                    >
                      {visible ? <EyeOff size={19} /> : <Eye size={19} />}
                    </button>
                  </div>
                  {register && (
                    <p
                      id="password-hint"
                      className={`zen-hint ${password.length >= 12 ? "is-valid" : ""}`}
                    >
                      <Check size={14} /> Use de 12 a 128 caracteres.
                    </p>
                  )}
                  {capsLock && (
                    <p role="status" className="zen-hint">
                      Caps Lock está ativado.
                    </p>
                  )}
                </div>
              )}
              {(register || recoveryMode === "reset") && (
                <div className="zen-field">
                  <label htmlFor="access-confirm">Confirme a senha</label>
                  <div
                    className={`zen-input-wrap ${mismatch ? "has-error" : ""}`}
                  >
                    <LockKeyhole size={18} />
                    <input
                      id="access-confirm"
                      name="confirmation"
                      type={visible ? "text" : "password"}
                      autoComplete="new-password"
                      placeholder="Repita sua senha"
                      required
                      minLength={12}
                      maxLength={128}
                      value={confirmation}
                      onChange={e => setConfirmation(e.target.value)}
                      aria-invalid={mismatch}
                      aria-describedby={
                        mismatch ? "confirmation-error" : undefined
                      }
                    />
                  </div>
                  {mismatch && (
                    <p id="confirmation-error" className="zen-field-error">
                      As senhas ainda não conferem.
                    </p>
                  )}
                </div>
              )}
              {!register && !recoveryMode && (
                <button
                  type="button"
                  className="zen-recovery"
                  onClick={() => {
                    setRecoveryMode("request");
                    setTotpCode("");
                    setFeedback("");
                    setTwoFactorRequired(false);
                    setError("");
                  }}
                >
                  Esqueceu sua senha? Recuperar por e-mail
                </button>
              )}
              {!register && !recoveryMode && twoFactorRequired && (
                <div className="zen-field">
                  <label htmlFor="access-totp">
                    Código de autenticação em duas etapas
                  </label>
                  <div className="zen-input-wrap">
                    <ShieldCheck size={18} />
                    <input
                      id="access-totp"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      pattern="[0-9]{6}"
                      maxLength={6}
                      value={totpCode}
                      onChange={e =>
                        setTotpCode(e.target.value.replace(/\D/g, ""))
                      }
                      required
                      placeholder="000000"
                    />
                  </div>
                </div>
              )}
              {recoveryMode && (
                <button
                  className="zen-recovery"
                  type="button"
                  onClick={() => {
                    setRecoveryMode(null);
                    setError("");
                    window.history.replaceState(null, "", "/login");
                  }}
                >
                  Voltar ao login
                </button>
              )}
              {feedback && (
                <p role="status" className="zen-hint">
                  {feedback}
                </p>
              )}
              {error && (
                <div
                  className="zen-form-error"
                  role="alert"
                  tabIndex={-1}
                  ref={errorRef}
                >
                  <AlertCircle size={19} />
                  <span>{error}</span>
                </div>
              )}
              <button type="submit" className="zen-submit">
                {busy ? (
                  <>
                    <LoaderCircle className="zen-spin" size={19} />{" "}
                    {recoveryMode
                      ? "Enviando…"
                      : register
                        ? "Criando sua conta…"
                        : "Entrando…"}
                  </>
                ) : (
                  <>
                    {recoveryMode === "request"
                      ? "Enviar link de recuperação"
                      : recoveryMode === "reset"
                        ? "Redefinir minha senha"
                        : register
                          ? "Criar minha conta"
                          : "Entrar na minha conta"}
                    <ArrowRight size={19} />
                  </>
                )}
              </button>
            </fieldset>
          </form>
          <div className="zen-divider">
            <span />
            {register ? "CONHEÇA ANTES DE COMEÇAR" : "QUER CONHECER PRIMEIRO?"}
            <span />
          </div>
          <a href="/demo" className="zen-demo">
            Explorar a demonstração
            <ArrowUpRight size={17} />
          </a>
          <p className="zen-demo-hint">
            Conheça o aplicativo com dados de exemplo.
          </p>
          <p className="zen-security">
            <ShieldCheck size={16} /> Seu acesso é pessoal. Sua rotina é só sua.
          </p>
        </div>
        <footer className="zen-form-footer">
          <a href="/privacidade">Aviso de Privacidade</a>
          <span>Plantão Zen Health</span>
          <a href="/about">
            Sobre o projeto
            <ArrowUpRight size={13} />
          </a>
        </footer>
      </section>
    </main>
  );
}

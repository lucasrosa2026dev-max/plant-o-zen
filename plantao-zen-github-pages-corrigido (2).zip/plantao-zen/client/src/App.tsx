import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
const Home = lazy(() => import("./pages/Home"));
const Demo = lazy(() => import("./pages/Demo"));
const About = lazy(() => import("./pages/About"));
const Privacy = lazy(() => import("./pages/Privacy"));

function Router() {
  return (
    <Switch>
      <Route path="/demo" component={Demo} />
      <Route path="/about" component={About} />
      <Route path="/privacidade" component={Privacy} />
      <Route path="/" component={Home} />
      <Route path="/workforce" component={Home} />
      <Route path="/emergency" component={Home} />
      <Route path="/contacts" component={Home} />
      <Route path="/analyses" component={Home} />
      <Route path="/analyses/:id" component={Home} />
      <Route path="/checkin" component={Home} />
      <Route path="/safety" component={Home} />
      <Route path="/messages" component={Home} />
      <Route path="/messages/moderation" component={Home} />
      <Route path="/profile" component={Home} />
      <Route path="/smartwatch" component={Home} />
      <Route path="/settings" component={Home} />
      <Route path="/login" component={Home} />
      <Route path="/register" component={Home} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <Suspense
            fallback={
              <div className="pz-empty min-h-screen" role="status">
                Abrindo seu espaço…
              </div>
            }
          >
            <Router />
          </Suspense>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

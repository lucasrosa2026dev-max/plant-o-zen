import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { PushNotifications } from "@capacitor/push-notifications";
import type { PluginListenerHandle } from "@capacitor/core";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  clearNativePush,
  isAndroidApp,
  readPushRegistration,
  savePushRegistration,
} from "@/lib/nativePush";

export default function NativePush() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const register = trpc.push.register.useMutation();
  const unregister = trpc.push.unregister.useMutation();
  const test = trpc.push.test.useMutation();
  const status = trpc.push.status.useQuery(undefined, {
    enabled: Boolean(user) && isAndroidApp(),
    retry: false,
  });
  const callbacks = useRef({ register, navigate });
  callbacks.current = { register, navigate };
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [message, setMessage] = useState(
    "Ative para receber os avisos da caixa de entrada neste Android."
  );
  const timeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    if (!user || !isAndroidApp()) return;
    let active = true;
    const handles: PluginListenerHandle[] = [];
    setReady(false);
    setRegistered(false);
    const keep = async (promise: Promise<PluginListenerHandle>) => {
      const handle = await promise;
      if (active) handles.push(handle);
      else await handle.remove();
    };
    void (async () => {
      await keep(
        PushNotifications.addListener("registration", token => {
          if (!active) return;
          void (async () => {
            try {
              await callbacks.current.register.mutateAsync({
                token: token.value,
              });
              if (!active) return;
              savePushRegistration(token.value, user.id);
              setRegistered(true);
              setMessage(
                "Celular registrado. Envie um teste e confira também o relógio."
              );
            } catch {
              if (active)
                setMessage(
                  "Não foi possível registrar. Confira a configuração do servidor e tente novamente."
                );
            } finally {
              if (active) {
                setBusy(false);
                clearTimeout(timeout.current);
              }
            }
          })();
        })
      );
      await keep(
        PushNotifications.addListener("registrationError", () => {
          if (active) {
            clearTimeout(timeout.current);
            setBusy(false);
            setMessage(
              "Registro indisponível. Verifique Firebase e Google Play Services neste Android."
            );
          }
        })
      );
      await keep(
        PushNotifications.addListener("pushNotificationReceived", () => {
          if (active)
            setMessage(
              "Notificação recebida no celular. Confira se o COLMI Fit a espelhou no relógio."
            );
        })
      );
      await keep(
        PushNotifications.addListener("pushNotificationActionPerformed", () => {
          if (active) callbacks.current.navigate("/");
        })
      );
      await PushNotifications.createChannel({
        id: "plantao_alerts",
        name: "Avisos do Plantão Zen",
        importance: 4,
        vibration: true,
        visibility: 0,
        sound: "default",
      });
      if (!active) return;
      setReady(true);
      if (
        readPushRegistration()?.userId === user.id &&
        (await PushNotifications.checkPermissions()).receive === "granted"
      ) {
        if (active) await PushNotifications.register();
      }
    })().catch(() => {
      if (active)
        setMessage(
          "As notificações nativas não estão disponíveis nesta instalação."
        );
    });
    return () => {
      active = false;
      clearTimeout(timeout.current);
      handles.forEach(handle => {
        void handle.remove();
      });
    };
  }, [user?.id]);

  if (!user || location !== "/smartwatch") return null;
  if (!isAndroidApp())
    return (
      <section className="mx-auto my-6 max-w-4xl rounded-xl border bg-card p-6 text-foreground">
        <h2 className="text-xl font-bold">Push e COLMI Fit</h2>
        <p className="mt-2">
          O envio remoto desta versão funciona no aplicativo Android com
          Firebase configurado. No navegador e no iPhone, o push nativo ainda
          não está disponível. A permissão do navegador não ativa esse recurso.
        </p>
      </section>
    );
  const enable = async () => {
    setBusy(true);
    try {
      const permission = await PushNotifications.requestPermissions();
      if (permission.receive !== "granted") {
        setMessage(
          "Permissão não concedida. Confira as notificações do Plantão Zen nas configurações do Android."
        );
        setBusy(false);
        return;
      }
      timeout.current = setTimeout(() => {
        setBusy(false);
        setMessage("O registro demorou. Confira a conexão e tente novamente.");
      }, 20000);
      await PushNotifications.register();
    } catch {
      clearTimeout(timeout.current);
      setBusy(false);
      setMessage("Não foi possível iniciar o registro neste celular.");
    }
  };
  const disable = async () => {
    setBusy(true);
    try {
      const saved = readPushRegistration();
      if (saved) await unregister.mutateAsync({ token: saved.token });
      await clearNativePush();
      setRegistered(false);
      setMessage("Notificações remotas desativadas neste celular.");
    } catch {
      setMessage(
        "Falha ao desativar no servidor. Confira a conexão e tente novamente."
      );
    } finally {
      setBusy(false);
    }
  };
  const sendTest = async () => {
    const saved = readPushRegistration();
    if (!saved || saved.userId !== user.id) return;
    try {
      await test.mutateAsync({ token: saved.token });
      setMessage(
        "Teste colocado na fila. Isso ainda não confirma o recebimento no celular ou no relógio."
      );
    } catch (error) {
      setMessage(
        error instanceof Error ? error.message : "Falha ao solicitar teste."
      );
    }
  };
  return (
    <section className="mx-auto my-6 max-w-4xl rounded-xl border bg-card p-6 text-foreground">
      <h2 className="text-xl font-bold">Notificações Android / COLMI Fit</h2>
      <p className="mt-2">
        Conecte o relógio pelo COLMI Fit, permita a ele acesso às notificações e
        habilite Plantão Zen ou Outros aplicativos, se disponível.
      </p>
      <p role="status" aria-live="polite" className="my-4">
        {status.isError
          ? "Não foi possível consultar o servidor."
          : status.data?.configured === false
            ? "O administrador precisa configurar o Firebase no servidor."
            : message}
      </p>
      <div className="flex flex-wrap gap-3">
        <button
          className="rounded-lg bg-teal-800 px-4 py-2 text-white disabled:opacity-50"
          disabled={!ready || busy || !status.data?.configured}
          onClick={() => void enable()}
        >
          Ativar / atualizar registro
        </button>
        <button
          className="rounded-lg border px-4 py-2 disabled:opacity-50"
          disabled={!registered || busy || test.isPending}
          onClick={() => void sendTest()}
        >
          Testar envio pelo servidor
        </button>
        <button
          className="rounded-lg border px-4 py-2 disabled:opacity-50"
          disabled={busy || !readPushRegistration()}
          onClick={() => void disable()}
        >
          Desativar neste celular
        </button>
      </div>
      <p className="mt-4 text-sm">
        O teste não aciona emergência. Não há confirmação automática de conexão
        ao relógio nem SOS pelo relógio. A entrega depende de internet,
        permissões e restrições do Android.
      </p>
    </section>
  );
}

import type { ReactNode } from "react";
export default function PageHeading({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <header className="pz-page-heading">
      <div>
        <p className="pz-eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="max-w-2xl">{description}</p>
      </div>
      {children}
    </header>
  );
}

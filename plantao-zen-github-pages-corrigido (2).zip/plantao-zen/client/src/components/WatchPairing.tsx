import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function WatchPairing() {
  const [pair, setPair] = useState<{ code: string; expiresAt: Date } | null>(null);
  const utils = trpc.useUtils();
  const devices = trpc.watch.devices.useQuery();
  const begin = trpc.watch.beginPairing.useMutation({ onSuccess: setPair, onError: err => toast.error(err.message) });
  const revoke = trpc.watch.revoke.useMutation({ onSuccess: async () => { toast.success("Relógio desconectado."); await utils.watch.devices.invalidate(); }, onError: err => toast.error(err.message) });
  return <section className="mt-5 rounded-2xl border border-border bg-card p-6">
    <h3 className="text-xl font-bold text-foreground">Plantão Zen Watch — pareamento seguro</h3>
    <p className="mt-2 text-sm text-foreground">Abra o aplicativo no relógio, informe a URL HTTPS do Plantão Zen e digite o código de 8 números. O código expira após 5 minutos e pode ser usado uma vez.</p>
    <button className="mt-4 rounded-xl bg-primary px-4 py-2 font-semibold text-white disabled:opacity-50" disabled={begin.isPending} onClick={() => begin.mutate()}>{begin.isPending ? "Gerando…" : "Gerar código de conexão"}</button>
    {pair && <div className="mt-4 rounded-xl bg-accent p-4" role="status"><div className="text-sm text-blue-900">Código temporário</div><div className="mt-2 font-mono text-3xl font-bold tracking-widest text-blue-950">{pair.code}</div><p className="text-xs text-primary">Expira em {new Date(pair.expiresAt).toLocaleTimeString("pt-BR")}. Não compartilhe.</p></div>}
    <h4 className="mt-6 font-bold text-foreground">Relógios vinculados</h4>
    {devices.isLoading ? <p className="text-sm">Carregando…</p> : !devices.data?.length ? <p className="mt-2 text-sm text-muted-foreground">Nenhum relógio conectado.</p> : <ul className="mt-2 space-y-2">{devices.data.map(d => <li key={d.id} className="flex items-center justify-between gap-3 rounded-xl border p-3"><div><div className="font-semibold text-foreground">{d.label}</div><p className="text-xs text-muted-foreground">{d.revokedAt ? "Revogado" : new Date(d.expiresAt) < new Date() ? "Expirado" : "Ativo"} · Último acesso: {d.lastSeenAt ? new Date(d.lastSeenAt).toLocaleString("pt-BR") : "Nunca"}</p></div>{!d.revokedAt && <button className="rounded-lg border border-red-300 px-3 py-2 text-sm font-semibold text-red-700" disabled={revoke.isPending} onClick={() => { if (window.confirm("Desconectar este relógio?")) revoke.mutate({ id: d.id }); }}>Revogar</button>}</li>)}</ul>}
    <p className="mt-4 text-xs text-muted-foreground">O relógio usa credencial própria e limitada. Desconecte imediatamente se perder o dispositivo. Notificações em segundo plano exigem configuração adicional de push.</p>
  </section>;
}

import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "wouter";
import {
  CalendarDays,
  LayoutDashboard,
  HeartPulse,
  Users,
  ShieldCheck,
  Activity,
  MessageCircle,
  Watch,
  Settings,
  UserRound,
  LogOut,
  Moon,
  Sun,
  Menu,
  X,
  ArrowUpRight,
  LifeBuoy,
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { toast } from "sonner";

const groups = [
  {
    title: "Rotina",
    items: [
      ["Visão geral", "/", LayoutDashboard],
      ["Plantões", "/workforce", CalendarDays],
      ["Mensagens", "/messages", MessageCircle],
    ],
  },
  {
    title: "Cuidado",
    items: [
      ["Como estou", "/checkin", HeartPulse],
      ["Minhas análises", "/analyses", Activity],
      ["Rede de apoio", "/contacts", Users],
      ["Plano de segurança", "/safety", ShieldCheck],
    ],
  },
  {
    title: "Conta",
    items: [
      ["Meu perfil", "/profile", UserRound],
      ["Relógio e dispositivos", "/smartwatch", Watch],
      ["Configurações", "/settings", Settings],
    ],
  },
] as const;
export function Brand() {
  return (
    <span className="pz-brand">
      <span className="pz-brand-mark">
        <HeartPulse size={22} strokeWidth={1.7} />
      </span>
      <span>
        plantão<span className="font-normal">zen</span>
        <small>ROTINA & CUIDADO</small>
      </span>
    </span>
  );
}
export default function AppShell({
  user,
  location,
  setLocation,
  logout,
  children,
  preview = false,
}: {
  user: { name?: string | null; email?: string | null };
  location: string;
  setLocation: (path: string) => void;
  logout: () => Promise<void>;
  children: ReactNode;
  preview?: boolean;
}) {
  const { theme, toggleTheme } = useTheme();
  const dialog = useRef<HTMLDialogElement>(null);
  const main = useRef<HTMLElement>(null);
  const [leaving, setLeaving] = useState(false);
  const path = location.split("?")[0];
  const active = (target: string) =>
    target === "/"
      ? path === "/"
      : path === target || path.startsWith(target + "/");
  const current = groups
    .flatMap(g => [...g.items])
    .find(([, target]) => active(target));
  const name = user.name || user.email?.split("@")[0] || "Minha conta";
  useEffect(() => {
    dialog.current?.close();
    document.title = `${current?.[0] ?? "Segurança"} · Plantão Zen`;
  }, [path, current]);
  const navigate = (target: string) => {
    if (preview) {
      toast("Esta é uma prévia. Entre na sua conta para acessar esta área.");
      dialog.current?.close();
      return;
    }
    setLocation(target);
    dialog.current?.close();
  };
  const signOut = async () => {
    setLeaving(true);
    try {
      await logout();
    } catch {
      toast.error("Não foi possível sair. Tente novamente.");
    } finally {
      setLeaving(false);
    }
  };
  const navigation = (
    <nav aria-label="Navegação principal">
      {groups.map(group => (
        <div className="pz-nav-group" key={group.title}>
          <p>{group.title}</p>
          {group.items.map(([label, target, Icon]) => (
            <Link
              href={target}
              key={target}
              onClick={event => {
                event.preventDefault();
                navigate(target);
              }}
              aria-current={active(target) ? "page" : undefined}
              className="pz-nav-item"
            >
              <Icon size={18} strokeWidth={1.7} />
              <span>{label}</span>
            </Link>
          ))}
        </div>
      ))}
    </nav>
  );
  return (
    <div className="pz-shell">
      <a className="pz-skip" href="#main-content">
        Ir para o conteúdo
      </a>
      <aside className="pz-sidebar">
        <Link
          href="/"
          className="pz-brand-link"
          aria-label="Plantão Zen — início"
        >
          <Brand />
        </Link>
        {navigation}
        <div className="pz-sidebar-bottom">
          <Link href="/emergency" className="pz-help">
            <LifeBuoy size={18} /> Preciso de ajuda <ArrowUpRight size={15} />
          </Link>
          <Link href="/about" className="pz-about">
            Sobre o Plantão Zen
          </Link>
          <div className="pz-account">
            <span className="pz-avatar">{name.slice(0, 1).toUpperCase()}</span>
            <Link href="/profile">
              <strong>{name}</strong>
              <small>Minha conta</small>
            </Link>
            <button
              aria-label="Sair da conta"
              title="Sair da conta"
              onClick={signOut}
              disabled={leaving}
            >
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>
      <div className="pz-workspace">
        <header className="pz-topbar">
          <span className="pz-breadcrumb">
            Meu espaço <span>/</span>{" "}
            <strong>{current?.[0] ?? "Segurança"}</strong>
          </span>
          <div className="flex items-center gap-3">
            <span className="pz-today">
              {new Intl.DateTimeFormat("pt-BR", {
                day: "numeric",
                month: "long",
              }).format(new Date())}
            </span>
            <button
              className="pz-icon-button"
              onClick={toggleTheme}
              aria-label={
                theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro"
              }
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
        </header>
        <main id="main-content" ref={main} tabIndex={-1} className="pz-content">
          {children}
        </main>
        <footer className="pz-footer">
          <span>
            Plantão Zen <span aria-hidden="true">·</span> Rotina com mais
            cuidado.
          </span>
          <Link href="/privacidade">Privacidade e seus dados</Link>
        </footer>
      </div>
      <nav className="pz-bottom-nav" aria-label="Atalhos no celular">
        {groups[0].items.map(([label, target, Icon]) => (
          <button
            key={target}
            aria-current={active(target) ? "page" : undefined}
            onClick={() => navigate(target)}
          >
            <Icon size={21} />
            <span>{label}</span>
          </button>
        ))}
        <button
          onClick={() => dialog.current?.showModal()}
          aria-haspopup="dialog"
        >
          <Menu size={21} />
          <span>Menu</span>
        </button>
      </nav>
      <dialog
        ref={dialog}
        className="pz-menu-dialog"
        aria-label="Todas as páginas"
      >
        <header>
          <Brand />
          <button
            className="pz-icon-button"
            onClick={() => dialog.current?.close()}
            aria-label="Fechar menu"
          >
            <X size={21} />
          </button>
        </header>
        {navigation}
        <Link
          href="/emergency"
          className="pz-help"
          onClick={() => dialog.current?.close()}
        >
          <LifeBuoy size={18} /> Preciso de ajuda
        </Link>
        <Link href="/about" className="pz-about">
          Sobre o projeto
        </Link>
        <button
          className="pz-health-outline w-full"
          disabled={leaving}
          onClick={signOut}
        >
          <LogOut size={17} /> {leaving ? "Saindo…" : "Sair da conta"}
        </button>
      </dialog>
    </div>
  );
}

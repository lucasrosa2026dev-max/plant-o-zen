import type { ReactNode } from "react";
import { Link } from "wouter";
import { Brand } from "./AppShell";
export default function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="pz-public">
      <header className="pz-public-header">
        <Link href="/" aria-label="Plantão Zen — início">
          <Brand />
        </Link>
        <Link href="/login">Acessar minha conta →</Link>
      </header>
      {children}
      <footer className="mt-12 border-t border-border pt-6 text-xs text-muted-foreground">
        <Link href="/privacidade">Privacidade e seus dados</Link>
        <span className="mx-3">·</span>
        <Link href="/about">Sobre o projeto</Link>
      </footer>
    </div>
  );
}

const CACHE_NAME = "plantao-zen-shell-v3";
const STATIC_FILES = ["/offline.html", "/manifest.webmanifest", "/icon.svg", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith("plantao-zen-shell-") && key !== CACHE_NAME).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname === "/api" || url.pathname.startsWith("/api/")) return;

  // Never persist pages, authentication responses or user-specific endpoints.
  if (request.mode === "navigate") {
    event.respondWith(fetch(request).catch(async () =>
      (await caches.match("/offline.html")) || new Response("Sem conexão. Tente novamente quando a internet voltar.", {
        status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" },
      })
    ));
    return;
  }
  if (url.search || !STATIC_FILES.includes(url.pathname)) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (response.ok && !response.redirected && response.type !== "opaque") {
        const copy = response.clone();
        // Cache failure must not turn a successful network response into an error.
        event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => undefined));
      }
      return response;
    } catch {
      return (await caches.match(request)) || Response.error();
    }
  })());
});

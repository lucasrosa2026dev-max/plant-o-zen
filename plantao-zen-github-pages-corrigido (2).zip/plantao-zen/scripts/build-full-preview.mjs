import { build } from "esbuild";
import fs from "node:fs/promises";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
const assets = path.join(root, "dist/public/assets");
const css = (
  await Promise.all(
    (await fs.readdir(assets))
      .filter(n => n.endsWith(".css"))
      .map(n => fs.readFile(path.join(assets, n), "utf8"))
  )
).join("\n");
const result = await build({
  entryPoints: [path.join(root, "client/src/full-preview/entry.tsx")],
  bundle: true,
  jsx: "automatic",
  minify: true,
  write: false,
  format: "iife",
  platform: "browser",
  loader: { ".css": "empty" },
  define: {
    "process.env.NODE_ENV": '"production"',
    "import.meta.env.DEV": "false",
  },
  alias: {
    "@/lib/notifications": path.join(
      root,
      "client/src/full-preview/notifications.ts"
    ),
    "@/lib/emergency": path.join(
      root,
      "client/src/full-preview/notifications.ts"
    ),
    "@": path.join(root, "client/src"),
    "@shared": path.join(root, "shared"),
  },
  tsconfig: path.join(root, "tsconfig.json"),
});
const script = result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
const extra = `.pz-preview-toolbar{position:sticky;top:0;z-index:60;background:#173f45;color:#eef7f2;display:flex;align-items:center;gap:16px;padding:12px 22px;box-shadow:0 1px 0 #ffffff30}.pz-preview-toolbar>div{flex:1}.pz-preview-toolbar strong{display:block;font-size:10px;letter-spacing:1.5px}.pz-preview-toolbar span:not(.sr-only){font-size:11px;color:#bcd7cc}.pz-preview-toolbar select,.pz-preview-toolbar button{background:#f1f6f3;color:#193a40;border-radius:7px;padding:9px 12px;font-size:12px;max-width:210px}.pz-sidebar{top:66px}.pz-menu-dialog{z-index:100}.zen-access{min-height:calc(100svh - 66px)}@media(max-width:680px){.pz-preview-toolbar{flex-wrap:wrap;padding:10px 14px;gap:8px}.pz-preview-toolbar>div{flex-basis:100%}.pz-preview-toolbar select{max-width:200px}.pz-preview-toolbar span:not(.sr-only){font-size:9px}}`;
const destination = path.resolve(
  root,
  "PREVIA-COMPLETA.html"
);
await fs.writeFile(
  destination,
  `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'"><title>Plantão Zen — prévia completa</title><style>${css}\n${extra}</style></head><body><div id="root"></div><script>${script}</script></body></html>`
);
console.log(destination);

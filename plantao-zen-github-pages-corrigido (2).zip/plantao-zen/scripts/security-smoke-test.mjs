/** Uses the project TypeScript dependency. Not a substitute for DB integration tests. */
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';


const require = createRequire(import.meta.url);
const ts = require('typescript');
const source = fs.readFileSync('server/securityV2.ts','utf8');
const output = ts.transpileModule(source, { fileName: 'server/securityV2.ts', compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'plantao-security-'));
try {
  const file = path.join(tempDir, 'securityV2.cjs'); fs.writeFileSync(file,output);
  const { toBase32, fromBase32, totpAt, matchingTotpStep, createTotpSecret, encryptSecret, decryptSecret } = require(file);
  const secret = toBase32(Buffer.from('12345678901234567890'));
  assert.equal(secret,'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
  assert.equal(fromBase32(secret).toString(),'12345678901234567890');
  assert.equal(totpAt(secret, 1),'287082');
  assert.equal(matchingTotpStep(secret,'287082',0,59000),1);
  assert.equal(matchingTotpStep(secret,'287082',1,59000),null);
  assert.equal(matchingTotpStep(secret,'abcdef',0,59000),null);
  process.env.TOTP_ENCRYPTION_KEY='a'.repeat(64);
  const freshSecret=createTotpSecret(); const encrypted=encryptSecret(freshSecret);
  assert.equal(decryptSecret(encrypted),freshSecret);
  assert.ok(!encrypted.includes(freshSecret));
  assert.throws(()=>decryptSecret(encrypted.slice(0,-1)+'!'));
  const privacy=fs.readFileSync('server/privacy.ts','utf8');
  assert.ok(privacy.includes('matchingTotpStep('));
  assert.ok(privacy.includes('lastUsedStep: step'));
  assert.ok(privacy.includes('verifySensitiveAction(ctx.user.id, input.password, input.totpCode)'));
  const ui=fs.readFileSync('client/src/pages/Portal.tsx','utf8');
  assert.ok(ui.includes('privacyTwoFactor.data?.enabled'));
  assert.ok(ui.includes('totpCode: privacyTwoFactor.data?.enabled ? privacyTotp : undefined'));
  const ddl=fs.readFileSync('drizzle/0010_security_v2.sql','utf8');
  assert.ok(ddl.includes('CREATE TABLE `auth_totp`'));
  assert.ok(ddl.includes('CREATE TABLE `password_resets`'));
  console.log('PASS: 15 checks (TOTP, encryption, MFA step-up code presence, migrations)');
} finally { fs.rmSync(tempDir,{recursive:true,force:true}); }

import "dotenv/config";
import { and, eq, ne } from "drizzle-orm";
import { authCredentials, authSessions, users } from "../drizzle/schema";
import { credentialsSchema, hashPassword } from "../server/auth";
import { getDb } from "../server/db";

// Operação administrativa local: nunca expor como endpoint HTTP.
async function main() {
  const userId = Number(process.env.ACCOUNT_USER_ID);
  if (!Number.isSafeInteger(userId) || userId <= 0) throw new Error("Informe ACCOUNT_USER_ID válido.");
  let password = "";
  for await (const chunk of process.stdin) {
    password += chunk.toString();
    if (password.length > 1024) throw new Error("Entrada muito longa.");
  }
  const input = credentialsSchema.parse({ email: process.env.ACCOUNT_EMAIL, password: password.replace(/\r?\n$/, "") });
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL não configurada.");
  const passwordHash = await hashPassword(input.password);
  await db.transaction(async tx => {
    const [user] = await tx.select().from(users).where(eq(users.id, userId)).for("update");
    if (!user) throw new Error("Conta não encontrada.");
    const [collision] = await tx.select().from(authCredentials).where(and(eq(authCredentials.email, input.email), ne(authCredentials.userId, userId)));
    if (collision) throw new Error("E-mail já associado a outra conta. Nenhum dado alterado.");
    const [existing] = await tx.select().from(authCredentials).where(eq(authCredentials.userId, userId));
    if (existing) await tx.update(authCredentials).set({ email: input.email, passwordHash }).where(eq(authCredentials.userId, userId));
    else await tx.insert(authCredentials).values({ userId, email: input.email, passwordHash });
    await tx.update(users).set({ email: input.email, loginMethod: "password" }).where(eq(users.id, userId));
    await tx.delete(authSessions).where(eq(authSessions.userId, userId));
  });
  console.log("Acesso atualizado; sessões anteriores revogadas.");
}
main().then(() => process.exit(0)).catch(error => {
  console.error(error instanceof Error ? error.message : "Não foi possível atualizar a conta.");
  process.exit(1);
});

import { build } from "esbuild";
import fs from "node:fs/promises";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
const assets = path.join(root, "dist/public/assets");
const cssNames = (await fs.readdir(assets)).filter(name =>
  name.endsWith(".css")
);
const css = (
  await Promise.all(
    cssNames.map(name => fs.readFile(path.join(assets, name), "utf8"))
  )
).join("\n");
const result = await build({
  entryPoints: [path.join(root, "client/src/preview.tsx")],
  bundle: true,
  jsx: "automatic",
  minify: true,
  write: false,
  format: "iife",
  platform: "browser",
  define: { "process.env.NODE_ENV": '"production"' },
  alias: {
    "@": path.join(root, "client/src"),
    "@shared": path.join(root, "shared"),
  },
  tsconfig: path.join(root, "tsconfig.json"),
});
const script = result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
await fs.writeFile(
  path.join(root, "PREVIA-PLANTAO-ZEN.html"),
  `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Plantão Zen · Prévia profissional</title><style>${css}</style></head><body><div id="root"></div><script>${script}</script></body></html>`
);
console.log("Prévia autônoma: PREVIA-PLANTAO-ZEN.html");

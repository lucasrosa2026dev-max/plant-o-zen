import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
const mode = process.argv[2];
const root = new URL("../", import.meta.url);
const entries = {
  dev: ["node_modules/tsx/dist/cli.mjs", "watch", "server/_core/index.ts"],
  start: ["dist/index.js"],
  static: [
    "node_modules/vite/bin/vite.js",
    "--host",
    "127.0.0.1",
    "--port",
    process.env.PORT || "3000",
    "--strictPort",
  ],
};
if (!Object.hasOwn(entries, mode))
  throw new Error("Modo inválido: dev, start ou static");
const [entry, ...args] = entries[mode];
const child = spawn(
  process.execPath,
  [fileURLToPath(new URL(entry, root)), ...args],
  {
    cwd: fileURLToPath(root),
    stdio: "inherit",
    env: {
      ...process.env,
      NODE_ENV: mode === "start" ? "production" : "development",
    },
  }
);
child.on("error", error => {
  console.error(error.message);
  process.exitCode = 1;
});
child.on("exit", code => {
  process.exitCode = code ?? 1;
});
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => child.kill(signal));

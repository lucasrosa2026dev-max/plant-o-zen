export const COOKIE_NAME = "plantao_session";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = "Entre para continuar (10001)";
export const NOT_ADMIN_ERR_MSG = "Você não tem permissão para esta operação (10002)";

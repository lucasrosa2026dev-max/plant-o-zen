export type OverviewShift = {
  startsAt: Date | string;
  endsAt: Date | string;
  status: string;
  checkInAt?: Date | string | null;
  checkOutAt?: Date | string | null;
};
export function weekDays(anchor: Date) {
  const start = new Date(anchor);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return d;
  });
}
/** Hours count only the portion inside the local week, including overnight shifts. */
export function weekSummary<T extends OverviewShift>(
  shifts: T[],
  anchor: Date
) {
  const days = weekDays(anchor);
  const end = new Date(days[0]);
  end.setDate(end.getDate() + 7);
  const included = shifts.filter(
    s =>
      s.status !== "cancelled" &&
      new Date(s.startsAt) < end &&
      new Date(s.endsAt) > days[0]
  );
  const hours = included.reduce(
    (total, s) =>
      total +
      Math.max(
        0,
        Math.min(+new Date(s.endsAt), +end) -
          Math.max(+new Date(s.startsAt), +days[0])
      ) /
        3600000,
    0
  );
  return {
    days,
    shifts: included,
    hours,
    completed: included.filter(s => s.checkOutAt).length,
  };
}

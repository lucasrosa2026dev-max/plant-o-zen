/** Quotes a CSV cell and prevents spreadsheet formula execution, including hidden prefixes. */
export function csvCell(value: unknown): string {
  const text = String(value ?? "");
  const safe = /^[\s\u0000-\u001f\u007f]*[=+@-]/u.test(text) || /^[\t\r\n]/.test(text)
    ? `'${text}` : text;
  return `"${safe.replace(/"/g, '""')}"`;
}

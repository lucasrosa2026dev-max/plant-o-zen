export type ShiftInterval = {
  professionalName: string;
  startsAt: Date;
  endsAt: Date;
};
export const normalizeProfessional = (name: string) =>
  name.trim().replace(/\s+/g, " ").toLocaleLowerCase("pt-BR");
export function shiftConflicts(
  shifts: ShiftInterval[],
  candidate: ShiftInterval,
  restHours = 11
) {
  return shifts
    .filter(
      s =>
        normalizeProfessional(s.professionalName) ===
        normalizeProfessional(candidate.professionalName)
    )
    .flatMap(s => {
      if (candidate.startsAt < s.endsAt && candidate.endsAt > s.startsAt)
        return ["Sobreposição com outro plantão"];
      const gap =
        candidate.startsAt >= s.endsAt
          ? candidate.startsAt.getTime() - s.endsAt.getTime()
          : s.startsAt.getTime() - candidate.endsAt.getTime();
      return gap < restHours * 3600000
        ? [`Descanso inferior a ${restHours} horas`]
        : [];
    });
}
export function localDateKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function intersectsLocalDay(
  start: Date | string,
  end: Date | string,
  day: string
) {
  const lower = new Date(`${day}T00:00:00`);
  const upper = new Date(lower);
  upper.setDate(upper.getDate() + 1);
  return new Date(start) < upper && new Date(end) > lower;
}

/** Clips an interval to the selected local day, including overnight shifts. */
export function dayTimelinePosition(start: Date | string, end: Date | string, day: string) {
  const lower = new Date(`${day}T00:00:00`);
  const upper = new Date(lower);
  upper.setDate(upper.getDate() + 1);
  const duration = upper.getTime() - lower.getTime();
  const from = Math.max(new Date(start).getTime(), lower.getTime());
  const to = Math.min(new Date(end).getTime(), upper.getTime());
  if (!Number.isFinite(from + to + duration) || duration <= 0 || to <= from) return null;
  return { left: (from - lower.getTime()) / duration * 100, width: (to - from) / duration * 100 };
}

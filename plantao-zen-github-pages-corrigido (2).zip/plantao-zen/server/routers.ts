import { revokeSession } from "./auth";
import { privacyRouter } from "./privacy";
import { securityRouter } from "./securityRouter";
import { watchRouter } from "./watch";
import { pushRouter, pushTokenSchema, revokePush } from "./push";
import { workforceRouter } from "./workforce";
import { COOKIE_NAME } from "@shared/const";
import { and, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { contacts, emergencyEvents } from "../drizzle/schema";
import {
  createAnalysis,
  createCheckin,
  createContact,
  createEmergency,
  createInboxNotification,
  deleteAllAnalyses,
  deleteAnalysis,
  deleteContact,
  deleteUserData,
  deleteSafetyPlan,
  getActiveEmergency,
  getAnalysis,
  getDb,
  getPreferences,
  getProfile,
  getSafetyPlan,
  getSmartwatchSettings,
  getUserById,
  getUserByOpenId,
  listAnalyses,
  listContacts,
  listCheckins,
  listInboxNotifications,
  savePreferences,
  saveProfile,
  saveSmartwatchSettings,
  saveSafetyPlan,
  updateContact,
  updateEmergency,
} from "./db";
import { validateEmergencyContactOrder, classifyContactDelivery } from "./emergencyLogic";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  blockChatConversation,
  ChatDataError,
  getChatSettings,
  getChatThread,
  listBlockedChatUsers,
  listChatConversations,
  listChatReportsAdmin,
  markChatMessagesRead,
  reportChatUser,
  respondToChatRequest,
  reviewChatReport,
  saveChatSettings,
  searchChatDirectory,
  sendChatMessage,
  startChatRequest,
  unblockChatUser,
} from "./chatDb";

const boolToInt = (value: boolean | undefined) => (value === undefined ? undefined : value ? 1 : 0);
const optionalEmail = z.string().trim().email().max(320).or(z.literal("")).nullable().optional();
const optionalText = z.string().trim().max(64).or(z.literal("")).nullable().optional();
async function runChat<T>(operation: () => Promise<T>): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof ChatDataError) throw new TRPCError({ code: error.code, message: error.message });
    throw error;
  }
}
const getLinkedUser = async (identifier: string) => {
  const publicId = /^PZ-(\d{1,})$/i.exec(identifier.trim());
  return publicId ? getUserById(Number(publicId[1])) : getUserByOpenId(identifier.trim());
};

export const appRouter = router({
  push: pushRouter,
  workforce: workforceRouter,
  privacy: privacyRouter,
  security: securityRouter,
  watch: watchRouter,
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.input(z.object({ pushToken: pushTokenSchema.optional() }).optional()).mutation(async ({ ctx, input }) => {
      if (ctx.user && input?.pushToken) await revokePush(ctx.user.id, input.pushToken);
      await revokeSession(ctx.req);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  chat: router({
    settings: router({
      get: protectedProcedure.query(({ ctx }) => runChat(() => getChatSettings(ctx.user.id))),
      save: protectedProcedure.input(z.object({ discoverable: z.boolean() })).mutation(({ ctx, input }) => runChat(() => saveChatSettings(ctx.user.id, input.discoverable))),
    }),
    directorySearch: protectedProcedure.input(z.object({ query: z.string().trim().min(2).max(80) })).query(({ ctx, input }) => runChat(() => searchChatDirectory(ctx.user.id, input.query))),
    conversations: protectedProcedure.query(({ ctx }) => runChat(() => listChatConversations(ctx.user.id))),
    thread: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).query(({ ctx, input }) => runChat(() => getChatThread(ctx.user.id, input.conversationId))),
    markRead: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).mutation(({ ctx, input }) => runChat(() => markChatMessagesRead(ctx.user.id, input.conversationId))),
    start: protectedProcedure.input(z.object({ targetPublicChatId: z.string().trim().min(10).max(32), message: z.string().trim().min(1).max(2000) })).mutation(({ ctx, input }) => runChat(() => startChatRequest(ctx.user.id, input.targetPublicChatId, input.message))),
    send: protectedProcedure.input(z.object({ conversationId: z.number().int().positive(), message: z.string().trim().min(1).max(2000) })).mutation(({ ctx, input }) => runChat(() => sendChatMessage(ctx.user.id, input.conversationId, input.message))),
    respond: protectedProcedure.input(z.object({ conversationId: z.number().int().positive(), action: z.enum(["accept", "decline"]) })).mutation(({ ctx, input }) => runChat(() => respondToChatRequest(ctx.user.id, input.conversationId, input.action))),
    block: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).mutation(({ ctx, input }) => runChat(() => blockChatConversation(ctx.user.id, input.conversationId))),
    blocked: router({
      list: protectedProcedure.query(({ ctx }) => runChat(() => listBlockedChatUsers(ctx.user.id))),
      remove: protectedProcedure.input(z.object({ publicChatId: z.string().trim().min(10).max(32) })).mutation(({ ctx, input }) => runChat(() => unblockChatUser(ctx.user.id, input.publicChatId))),
    }),
    report: protectedProcedure.input(z.object({
      conversationId: z.number().int().positive(),
      messageId: z.number().int().positive().optional(),
      reason: z.enum(["harassment", "spam", "safety", "other"]),
      details: z.string().trim().max(500).optional(),
    })).mutation(({ ctx, input }) => runChat(() => reportChatUser({ reporterId: ctx.user.id, ...input }))),
    adminReports: adminProcedure.query(() => runChat(() => listChatReportsAdmin())),
    reviewReport: adminProcedure.input(z.object({ reportId: z.number().int().positive(), status: z.enum(["reviewed", "actioned"]) })).mutation(({ ctx, input }) => runChat(() => reviewChatReport(ctx.user.id, input.reportId, input.status))),
  }),
  profile: router({
    get: protectedProcedure.query(({ ctx }) => getProfile(ctx.user.id)),
    save: protectedProcedure.input(z.object({
      fullName: z.string().trim().max(120).optional(),
      phone: z.string().trim().max(32).optional(),
      birthDate: z.string().trim().max(10).optional(),
      city: z.string().trim().max(100).optional(),
      careNotes: z.string().trim().max(5000).optional(),
    })).mutation(({ ctx, input }) => saveProfile(ctx.user.id, input)),
    clear: protectedProcedure.mutation(() => { throw new TRPCError({ code: "FORBIDDEN", message: "Use a área de privacidade e confirme sua senha para excluir a conta." }); }),
  }),
  contacts: router({
    list: protectedProcedure.query(({ ctx }) => listContacts(ctx.user.id)),
    create: protectedProcedure.input(z.object({
      name: z.string().trim().min(2).max(120),
      phone: z.string().trim().min(5).max(32),
      email: optionalEmail,
      relationship: z.string().trim().max(80).optional(),
      isEmergency: z.boolean().default(false),
      linkedOpenId: optionalText,
    })).mutation(({ ctx, input }) => createContact(ctx.user.id, {
      name: input.name,
      phone: input.phone,
      email: input.email || null,
      relationship: input.relationship || null,
      isEmergency: input.isEmergency ? 1 : 0,
      linkedOpenId: input.linkedOpenId || null,
    })),
    update: protectedProcedure.input(z.object({
      id: z.number().int().positive(),
      name: z.string().trim().min(2).max(120).optional(),
      phone: z.string().trim().min(5).max(32).optional(),
      email: optionalEmail,
      relationship: z.string().trim().max(80).nullable().optional(),
      isEmergency: z.boolean().optional(),
      linkedOpenId: optionalText,
    })).mutation(({ ctx, input }) => updateContact(ctx.user.id, input.id, {
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.phone !== undefined ? { phone: input.phone } : {}),
      ...(input.email !== undefined ? { email: input.email || null } : {}),
      ...(input.relationship !== undefined ? { relationship: input.relationship || null } : {}),
      ...(input.isEmergency !== undefined ? { isEmergency: input.isEmergency ? 1 : 0 } : {}),
      ...(input.linkedOpenId !== undefined ? { linkedOpenId: input.linkedOpenId || null } : {}),
    })),
    remove: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => deleteContact(ctx.user.id, input.id)),
    reorderEmergency: protectedProcedure.input(z.object({ ids: z.array(z.number().int().positive()).max(100) })).mutation(async ({ ctx, input }) => {
      const currentEmergency = (await listContacts(ctx.user.id)).filter(contact => contact.isEmergency === 1);
      let orderedIds: number[];
      try { orderedIds = validateEmergencyContactOrder(currentEmergency.map(contact => contact.id), input.ids); }
      catch { throw new TRPCError({ code: "BAD_REQUEST", message: "Atualize a lista e tente ordenar novamente." }); }
      for (const [index, id] of orderedIds.entries()) await updateContact(ctx.user.id, id, { emergencyPriority: index + 1 });
      return { success: true };
    }),
    sendMessage: protectedProcedure.input(z.object({ contactId: z.number().int().positive(), message: z.string().trim().min(2).max(500) })).mutation(async ({ ctx, input }) => {
      const contact = (await listContacts(ctx.user.id)).find(item => item.id === input.contactId);
      if (!contact?.linkedOpenId) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Este contato ainda não está vinculado a uma conta Plantão Zen." });
      const linkedUser = await getLinkedUser(contact.linkedOpenId);
      if (!linkedUser) throw new TRPCError({ code: "NOT_FOUND", message: "A conta vinculada não foi encontrada." });
      await createInboxNotification(linkedUser.id, { eventType: "message", title: `Mensagem de ${ctx.user.name || "seu contato"}`, body: input.message, isRead: 0 });
      await createInboxNotification(ctx.user.id, { eventType: "message_sent", title: `Mensagem enviada para ${contact.name}`, body: input.message, isRead: 1 });
      return { success: true };
    }),
  }),
  analyses: router({
    list: protectedProcedure.input(z.object({ result: z.string().trim().max(80).optional(), limit: z.number().int().min(1).max(100).default(50), offset: z.number().int().min(0).max(10000).default(0) }).optional()).query(({ ctx, input }) => listAnalyses(ctx.user.id, input)),
    get: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(({ ctx, input }) => getAnalysis(ctx.user.id, input.id)),
    create: protectedProcedure.input(z.object({
      title: z.string().trim().min(2).max(160),
      result: z.string().trim().min(2).max(80),
      details: z.string().trim().min(2).max(10000),
    })).mutation(({ ctx, input }) => createAnalysis(ctx.user.id, input)),
    remove: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => deleteAnalysis(ctx.user.id, input.id)),
    clear: protectedProcedure.mutation(({ ctx }) => deleteAllAnalyses(ctx.user.id)),
  }),
  checkins: router({
    list: protectedProcedure.query(({ ctx }) => listCheckins(ctx.user.id)),
    create: protectedProcedure.input(z.object({ mood: z.string().trim().min(2).max(80), notes: z.string().trim().max(2000).optional() })).mutation(({ ctx, input }) => createCheckin(ctx.user.id, { mood: input.mood, notes: input.notes || null })),
  }),
  safetyPlan: router({
    get: protectedProcedure.query(({ ctx }) => getSafetyPlan(ctx.user.id)),
    save: protectedProcedure.input(z.object({ safeLocation: z.string().trim().max(240).optional(), medications: z.string().trim().max(5000).optional(), allergies: z.string().trim().max(5000).optional(), priorityContacts: z.string().trim().max(2000).optional(), instructions: z.string().trim().max(5000).optional(), localServices: z.string().trim().max(2000).optional() })).mutation(({ ctx, input }) => saveSafetyPlan(ctx.user.id, { ...input })),
    clear: protectedProcedure.mutation(({ ctx }) => deleteSafetyPlan(ctx.user.id)),
  }),
  preferences: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const current = await getPreferences(ctx.user.id);
      return current ?? { notificationsEnabled: 1, soundEnabled: 1, smartwatchEnabled: 1, backgroundEnabled: 1, callConfirmationRequired: 1, theme: "light" as const };
    }),
    save: protectedProcedure.input(z.object({
      notificationsEnabled: z.boolean().optional(),
      soundEnabled: z.boolean().optional(),
      smartwatchEnabled: z.boolean().optional(),
      backgroundEnabled: z.boolean().optional(),
      callConfirmationRequired: z.boolean().optional(),
      theme: z.enum(["light", "dark"]).optional(),
    })).mutation(({ ctx, input }) => savePreferences(ctx.user.id, {
      ...(input.notificationsEnabled !== undefined ? { notificationsEnabled: boolToInt(input.notificationsEnabled) } : {}),
      ...(input.soundEnabled !== undefined ? { soundEnabled: boolToInt(input.soundEnabled) } : {}),
      ...(input.smartwatchEnabled !== undefined ? { smartwatchEnabled: boolToInt(input.smartwatchEnabled) } : {}),
      ...(input.backgroundEnabled !== undefined ? { backgroundEnabled: boolToInt(input.backgroundEnabled) } : {}),
      ...(input.callConfirmationRequired !== undefined ? { callConfirmationRequired: boolToInt(input.callConfirmationRequired) } : {}),
      ...(input.theme !== undefined ? { theme: input.theme } : {}),
    })),
  }),
  smartwatch: router({
    get: protectedProcedure.query(({ ctx }) => getSmartwatchSettings(ctx.user.id)),
    save: protectedProcedure.input(z.object({
      platform: z.string().max(80).optional(),
      pwaInstalled: z.boolean().optional(),
      supportsNotifications: z.boolean().optional(),
      supportsActions: z.boolean().optional(),
      notificationPermission: z.string().max(32).optional(),
      smartwatchMirroring: z.boolean().optional(),
    })).mutation(({ ctx, input }) => saveSmartwatchSettings(ctx.user.id, {
      ...(input.platform !== undefined ? { platform: input.platform } : {}),
      ...(input.pwaInstalled !== undefined ? { pwaInstalled: boolToInt(input.pwaInstalled) } : {}),
      ...(input.supportsNotifications !== undefined ? { supportsNotifications: boolToInt(input.supportsNotifications) } : {}),
      ...(input.supportsActions !== undefined ? { supportsActions: boolToInt(input.supportsActions) } : {}),
      ...(input.notificationPermission !== undefined ? { notificationPermission: input.notificationPermission } : {}),
      ...(input.smartwatchMirroring !== undefined ? { smartwatchMirroring: boolToInt(input.smartwatchMirroring) } : {}),
    })),
  }),
  emergency: router({
    active: protectedProcedure.query(({ ctx }) => getActiveEmergency(ctx.user.id)),
    history: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível. Tente novamente mais tarde." });
      return db.select().from(emergencyEvents).where(eq(emergencyEvents.userId, ctx.user.id)).orderBy(emergencyEvents.createdAt);
    }),
    trigger: protectedProcedure.input(z.object({ message: z.string().trim().max(240).optional() })).mutation(async ({ ctx, input }) => {
      const created = await createEmergency(ctx.user.id, input.message || "Preciso de ajuda agora.");
      const event = created.event;
      if (!event) return { event: null, notificationsSent: 0, duplicate: false };
      if (!created.created) return { event, notificationsSent: event.notificationsSent, duplicate: true };
      let notificationsSent = 0;
      let contactsNotificationStatus: "sent" | "partial" | "failed" | "no_contacts" = "failed";
      try {
        const db = await getDb();
        if (!db) throw new Error("Database is not available for notification delivery");
        const emergencyContacts = await db.select().from(contacts).where(and(eq(contacts.userId, ctx.user.id), eq(contacts.isEmergency, 1)));
        const linkedIds = [...new Set(emergencyContacts.map(contact => contact.linkedOpenId).filter((value): value is string => Boolean(value)))];
        if (linkedIds.length === 0) {
          contactsNotificationStatus = "no_contacts";
        } else {
          const lookups = await Promise.allSettled(linkedIds.map(identifier => getLinkedUser(identifier)));
          const unresolvedRecipients = lookups.filter(result => result.status === "rejected" || result.value === undefined).length;
          const resolvedUsers = lookups.flatMap(result => result.status === "fulfilled" && result.value ? [result.value] : []);
          const uniqueRecipients = [...new Map(resolvedUsers.map(user => [user.id, user])).values()];
          const deliveries = await Promise.allSettled(uniqueRecipients.map(user => createInboxNotification(user.id, {
            relatedEmergencyId: event.id,
            eventType: "emergency",
            title: "Emergência de contato de confiança",
            body: `${ctx.user.name || "Seu contato"} acionou uma emergência. Entre em contato assim que possível.`,
            isRead: 0,
          })));
          notificationsSent = deliveries.filter(result => result.status === "fulfilled").length;
          contactsNotificationStatus = classifyContactDelivery(uniqueRecipients.length + unresolvedRecipients, notificationsSent);
        }
      } catch (error) {
        console.warn("[Emergency] Alert saved, but contact notification delivery failed:", error);
        contactsNotificationStatus = "failed";
      }
      const updated = await updateEmergency(ctx.user.id, event.id, { notificationsSent, contactsNotificationStatus });
      return { event: updated, notificationsSent, duplicate: false };
    }),
    updateNotification: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["sent", "failed", "unsupported"]) })).mutation(async ({ ctx, input }) => {
      const active = await getActiveEmergency(ctx.user.id);
      if (!active || active.id !== input.id) throw new TRPCError({ code: "CONFLICT", message: "A emergência não está mais ativa." });
      return updateEmergency(ctx.user.id, input.id, { webNotificationStatus: input.status });
    }),
    cancel: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const active = await getActiveEmergency(ctx.user.id);
      if (!active || active.id !== input.id) throw new TRPCError({ code: "CONFLICT", message: "A emergência já foi encerrada." });
      return updateEmergency(ctx.user.id, input.id, { status: "cancelled", cancelledAt: new Date() });
    }),
    callStarted: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const active = await getActiveEmergency(ctx.user.id);
      if (!active || active.id !== input.id) throw new TRPCError({ code: "CONFLICT", message: "A emergência não está mais ativa." });
      return updateEmergency(ctx.user.id, input.id, { callStatus: "initiated" });
    }),
    callNotCompleted: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const active = await getActiveEmergency(ctx.user.id);
      if (!active || active.id !== input.id) throw new TRPCError({ code: "CONFLICT", message: "A emergência não está mais ativa." });
      return updateEmergency(ctx.user.id, input.id, { callStatus: "not_completed" });
    }),
  }),
  inbox: router({
    list: protectedProcedure.query(({ ctx }) => listInboxNotifications(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;

import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import { getDb } from "./db";
import { getChatThread, respondToChatRequest, sendChatMessage } from "./chatDb";
import { chatBlocks, chatMessages } from "../drizzle/schema";
import { scriptedDb, type ReadStep } from "./testSupport/scriptedDb";
vi.mock("./db", () => ({ getDb: vi.fn() }));
beforeEach(() => vi.resetAllMocks());
const conversation = {
  id: 10,
  participantAId: 1,
  participantBId: 2,
  requestedById: 1,
  status: "accepted",
};
const people = [
  { id: 1, loginMethod: "password" },
  { id: 2, loginMethod: "password" },
];
function use(reads: ReadStep[]) {
  const h = scriptedDb(reads);
  vi.mocked(getDb).mockResolvedValue(h.db as never);
  return h;
}
describe("chat service flows with scripted persistence", () => {
  it("sends a trimmed message only after validating participants and blocks", async () => {
    const h = use([
      { rows: [conversation] },
      { rows: people },
      { rows: [conversation] },
      { rows: [] },
    ]);
    await expect(sendChatMessage(1, 10, "  Bom plantão!  ")).resolves.toEqual({
      success: true,
      messageId: 42,
    });
    expect(h.writes.find(w => w.table === chatMessages)?.values).toMatchObject({
      conversationId: 10,
      senderId: 1,
      body: "Bom plantão!",
    });
    expect(h.remaining()).toBe(0);
  });
  it.each(["pending", "declined"])(
    "refuses sending to a %s conversation",
    async status => {
      const h = use([
        { rows: [conversation] },
        { rows: people },
        { rows: [{ ...conversation, status }] },
        { rows: [] },
      ]);
      await expect(sendChatMessage(1, 10, "Olá")).rejects.toMatchObject({
        code: "PRECONDITION_FAILED",
      });
      expect(h.writes).toHaveLength(0);
    }
  );
  it("refuses blocked messages without writes", async () => {
    const h = use([
      { rows: [conversation] },
      { rows: people },
      { rows: [conversation] },
      { rows: [{ id: 1 }] },
    ]);
    await expect(sendChatMessage(1, 10, "Olá")).rejects.toMatchObject({
      code: "PRECONDITION_FAILED",
    });
    expect(h.writes).toHaveLength(0);
  });
  it("does not reveal a conversation to a nonparticipant", async () => {
    const h = use([{ rows: [conversation] }]);
    await expect(getChatThread(99, 10)).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
    expect(h.db.transaction).not.toHaveBeenCalled();
  });
  it("checks both real participants before accepting an invitation", async () => {
    const pending = { ...conversation, status: "pending" };
    const h = use([
      { rows: [pending] },
      { rows: people },
      { rows: [pending] },
      {
        rows: [{ id: 9 }],
        inspect: (where, table) => {
          expect(table).toBe(chatBlocks);
          expect(new MySqlDialect().sqlToQuery(where!).params).toEqual([
            2, 1, 1, 2,
          ]);
        },
      },
    ]);
    await expect(respondToChatRequest(2, 10, "accept")).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    expect(h.writes).toHaveLength(0);
  });
  it("allows the recipient to accept an unblocked pending invitation", async () => {
    const pending = { ...conversation, status: "pending" };
    const h = use([
      { rows: [pending] },
      { rows: people },
      { rows: [pending] },
      { rows: [] },
    ]);
    await expect(respondToChatRequest(2, 10, "accept")).resolves.toMatchObject({
      status: "accepted",
    });
    expect(h.writes[0].values.status).toBe("accepted");
  });
  it("rejects self-acceptance by the requester", async () => {
    const pending = { ...conversation, status: "pending" };
    const h = use([{ rows: [pending] }, { rows: people }, { rows: [pending] }]);
    await expect(respondToChatRequest(1, 10, "accept")).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    expect(h.writes).toHaveLength(0);
  });
});

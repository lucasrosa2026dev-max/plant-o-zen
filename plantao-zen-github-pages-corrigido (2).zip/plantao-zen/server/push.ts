import { createHash } from "node:crypto";
import { and, eq, lt, lte, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  pushDevices,
  pushQueue,
  notificationPreferences,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";
import { protectedProcedure, router } from "./_core/trpc";
import { pushConfigured, sendAndroidPush } from "./pushTransport";

export const pushTokenSchema = z
  .string()
  .trim()
  .min(20)
  .max(4096)
  .regex(/^[A-Za-z0-9_:\-]+$/);
const hash = (token: string) =>
  createHash("sha256").update(token).digest("hex");
async function database() {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "SERVICE_UNAVAILABLE",
      message: "Banco indisponível.",
    });
  return db;
}
export async function revokePush(userId: number, token: string) {
  const db = await database();
  await db
    .delete(pushDevices)
    .where(
      and(
        eq(pushDevices.userId, userId),
        eq(pushDevices.tokenHash, hash(token))
      )
    );
}
export const pushRouter = router({
  status: protectedProcedure.query(() => ({
    configured: pushConfigured(),
    platform: "android" as const,
  })),
  register: protectedProcedure
    .input(z.object({ token: pushTokenSchema }))
    .mutation(async ({ ctx, input }) => {
      if (!pushConfigured())
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "O servidor ainda precisa da configuração Firebase.",
        });
      const db = await database();
      await db.transaction(async tx => {
        await tx
          .select({ id: users.id })
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .for("update");
        const devices = await tx
          .select({ tokenHash: pushDevices.tokenHash })
          .from(pushDevices)
          .where(eq(pushDevices.userId, ctx.user.id));
        if (
          devices.length >= 10 &&
          !devices.some(device => device.tokenHash === hash(input.token))
        ) {
          throw new TRPCError({
            code: "PRECONDITION_FAILED",
            message:
              "Limite de dez dispositivos. Desative um celular antes de adicionar outro.",
          });
        }
        await tx
          .insert(pushDevices)
          .values({
            userId: ctx.user.id,
            tokenHash: hash(input.token),
            token: input.token,
          })
          .onDuplicateKeyUpdate({
            set: {
              userId: ctx.user.id,
              token: input.token,
              updatedAt: new Date(),
            },
          });
      });
      return { registered: true };
    }),
  unregister: protectedProcedure
    .input(z.object({ token: pushTokenSchema }))
    .mutation(async ({ ctx, input }) => {
      await revokePush(ctx.user.id, input.token);
      return { registered: false };
    }),
  test: protectedProcedure
    .input(z.object({ token: pushTokenSchema }))
    .mutation(async ({ ctx, input }) => {
      if (!pushConfigured())
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "Configure o Firebase no servidor.",
        });
      const db = await database();
      return db.transaction(async tx => {
        // Lock this device to enforce the cooldown across server processes.
        const [device] = await tx
          .select()
          .from(pushDevices)
          .where(
            and(
              eq(pushDevices.userId, ctx.user.id),
              eq(pushDevices.tokenHash, hash(input.token))
            )
          )
          .for("update");
        if (!device)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Ative as notificações neste celular primeiro.",
          });
        const [recent] = await tx
          .select({ id: pushQueue.id })
          .from(pushQueue)
          .where(
            and(
              eq(pushQueue.deviceId, device.id),
              eq(pushQueue.isTest, 1),
              sql`${pushQueue.createdAt} > DATE_SUB(NOW(), INTERVAL 60 SECOND)`
            )
          )
          .limit(1);
        if (recent)
          throw new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message: "Aguarde um minuto antes de testar novamente.",
          });
        await tx
          .insert(pushQueue)
          .values({ userId: ctx.user.id, deviceId: device.id, isTest: 1 });
        return { queued: true };
      });
    }),
});

let running = false;
export async function processPushQueue() {
  if (running || !pushConfigured()) return;
  running = true;
  try {
    const db = await database();
    const due = await db
      .select()
      .from(pushQueue)
      .where(
        and(
          eq(pushQueue.status, "pending"),
          lte(pushQueue.availableAt, new Date())
        )
      )
      .limit(10);
    for (const item of due) {
      // A conditional update leases the item; a crash makes it eligible again.
      const [claim] = await db
        .update(pushQueue)
        .set({
          availableAt: new Date(Date.now() + 120000),
          attempts: sql`${pushQueue.attempts} + 1`,
        })
        .where(
          and(
            eq(pushQueue.id, item.id),
            eq(pushQueue.status, "pending"),
            lte(pushQueue.availableAt, new Date())
          )
        );
      if (!claim.affectedRows) continue;
      const [device] = await db
        .select()
        .from(pushDevices)
        .where(
          and(
            eq(pushDevices.id, item.deviceId),
            eq(pushDevices.userId, item.userId)
          )
        )
        .limit(1);
      const [preferences] = await db
        .select()
        .from(notificationPreferences)
        .where(eq(notificationPreferences.userId, item.userId))
        .limit(1);
      const expired = Date.now() - item.createdAt.getTime() > 5 * 60 * 1000;
      if (
        !device ||
        expired ||
        (!item.isTest && preferences?.notificationsEnabled === 0)
      ) {
        await db
          .update(pushQueue)
          .set({ status: "cancelled" })
          .where(eq(pushQueue.id, item.id));
        continue;
      }
      const result = await sendAndroidPush(
        device.token,
        Boolean(item.isTest),
        item.id
      );
      if (result === "invalid_token")
        await db
          .delete(pushDevices)
          .where(
            and(
              eq(pushDevices.id, device.id),
              eq(pushDevices.tokenHash, device.tokenHash)
            )
          );
      await db
        .update(pushQueue)
        .set({
          status:
            result === "accepted"
              ? "accepted"
              : result === "invalid_token" || item.attempts >= 4
                ? "failed"
                : "pending",
          availableAt: new Date(
            Date.now() + Math.min(120000, 10000 * 2 ** item.attempts)
          ),
        })
        .where(eq(pushQueue.id, item.id));
    }
    await db
      .delete(pushQueue)
      .where(lt(pushQueue.createdAt, new Date(Date.now() - 7 * 86400000)));
    await db
      .delete(pushDevices)
      .where(lt(pushDevices.updatedAt, new Date(Date.now() - 30 * 86400000)));
  } catch {
    // No tokens, provider responses, credentials or personal data in logs.
    console.warn(
      "[Push] Worker unavailable; check migration and server configuration."
    );
  } finally {
    running = false;
  }
}
export function startPushWorker() {
  const timer = setInterval(() => {
    void processPushQueue();
  }, 10000);
  timer.unref();
  void processPushQueue();
}

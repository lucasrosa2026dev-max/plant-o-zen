import { describe, expect, it } from "vitest";
import { weekDays, weekSummary } from "../shared/overview";
const shift = (
  start: string,
  end: string,
  status = "planned",
  checkOutAt: Date | null = null
) => ({ startsAt: new Date(start), endsAt: new Date(end), status, checkOutAt });
describe("weekly planning summary", () => {
  it("starts the week on Monday even when the selected day is Sunday", () => {
    const days = weekDays(new Date(2026, 10, 15, 18));
    expect(days[0].getDay()).toBe(1);
    expect(days[0].getDate()).toBe(9);
    expect(days[6].getDate()).toBe(15);
    expect(days[0].getHours()).toBe(0);
  });
  it("clips overnight shifts to the week and ignores cancelled or adjacent intervals", () => {
    const result = weekSummary(
      [
        shift("2026-11-08T19:00:00", "2026-11-09T07:00:00"),
        shift("2026-11-15T19:00:00", "2026-11-16T07:00:00"),
        shift("2026-11-10T07:00:00", "2026-11-10T19:00:00", "cancelled"),
        shift("2026-11-08T12:00:00", "2026-11-09T00:00:00"),
        shift("2026-11-16T00:00:00", "2026-11-16T08:00:00"),
      ],
      new Date(2026, 10, 11)
    );
    expect(result.shifts).toHaveLength(2);
    expect(result.hours).toBe(12);
  });
  it("counts actual registered checkouts and handles an empty week", () => {
    const result = weekSummary(
      [
        shift(
          "2026-11-10T07:00:00",
          "2026-11-10T19:00:00",
          "planned",
          new Date(2026, 10, 10, 19)
        ),
        shift("2026-11-11T07:00:00", "2026-11-11T19:00:00"),
      ],
      new Date(2026, 10, 11)
    );
    expect(result.completed).toBe(1);
    expect(result.hours).toBe(24);
    expect(weekSummary([], new Date()).hours).toBe(0);
  });
});

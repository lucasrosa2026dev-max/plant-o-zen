import { pushDevices, pushQueue } from "../drizzle/schema";
import {
  and,
  asc,
  desc,
  eq,
  inArray,
  or,
} from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  analyses,
  chatBlocks,
  chatConversations,
  watchDevices,
  watchPairings,
  chatMessages,
  chatReports,
  chatSettings,
  contacts,
  dailyCheckins,
  emergencyEvents,
  inboxNotifications,
  InsertUser,
  NotificationPreferences,
  notificationPreferences,
  profiles,
  safetyPlans,
  smartwatchSettings,
  users,
} from "../drizzle/schema";
import { authCredentials, authSessions, authTotp, passwordResets, workShifts, workAudit } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;

  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result[0];
}

export async function getProfile(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(profiles).where(eq(profiles.userId, userId)).limit(1);
  return rows[0];
}

export async function saveProfile(userId: number, values: Partial<typeof profiles.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getProfile(userId);
  if (existing) {
    await db.update(profiles).set({ ...values, updatedAt: new Date() }).where(eq(profiles.userId, userId));
  } else {
    await db.insert(profiles).values({ userId, ...values });
  }
  return getProfile(userId);
}

export async function listCheckins(userId: number, limit = 30) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  return db.select().from(dailyCheckins).where(eq(dailyCheckins.userId, userId)).orderBy(desc(dailyCheckins.createdAt)).limit(limit);
}

export async function createCheckin(userId: number, values: Omit<typeof dailyCheckins.$inferInsert, "id" | "userId" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(dailyCheckins).values({ userId, ...values });
  const rows = await db.select().from(dailyCheckins).where(and(eq(dailyCheckins.id, Number(result[0].insertId)), eq(dailyCheckins.userId, userId))).limit(1);
  return rows[0];
}

export async function getSafetyPlan(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(safetyPlans).where(eq(safetyPlans.userId, userId)).limit(1);
  return rows[0];
}

export async function saveSafetyPlan(userId: number, values: Partial<typeof safetyPlans.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getSafetyPlan(userId);
  if (existing) {
    await db.update(safetyPlans).set({ ...values, updatedAt: new Date() }).where(eq(safetyPlans.userId, userId));
  } else {
    await db.insert(safetyPlans).values({ userId, ...values });
  }
  return getSafetyPlan(userId);
}

export async function deleteSafetyPlan(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(safetyPlans).where(eq(safetyPlans.userId, userId));
  return { success: true };
}

export async function deleteUserData(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const lockedUser = await tx
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, userId))
      .for("update")
      .limit(1);
    if (lockedUser.length === 0) return { success: true };

    // Keep the surviving participant's messages. Deleting chatConversations here
    // would cascade into their messages and destroy another person's records.
    // Remove only messages authored by the account being erased. The user row
    // becomes a non-login tombstone to satisfy existing chat foreign keys.
    await tx.delete(chatReports).where(or(eq(chatReports.reporterId, userId), eq(chatReports.reportedUserId, userId)));
    await tx.delete(chatMessages).where(eq(chatMessages.senderId, userId));
    await tx.update(chatConversations)
      .set({ status: "declined" })
      .where(and(
        or(eq(chatConversations.participantAId, userId), eq(chatConversations.participantBId, userId)),
        eq(chatConversations.status, "pending"),
      ));
    await tx.delete(chatBlocks).where(or(eq(chatBlocks.blockerId, userId), eq(chatBlocks.blockedUserId, userId)));
    await tx.delete(chatSettings).where(eq(chatSettings.userId, userId));
    await tx.delete(pushQueue).where(eq(pushQueue.userId, userId));
    await tx.delete(pushDevices).where(eq(pushDevices.userId, userId));
    await tx.delete(inboxNotifications).where(eq(inboxNotifications.userId, userId));
    await tx.delete(dailyCheckins).where(eq(dailyCheckins.userId, userId));
    await tx.delete(safetyPlans).where(eq(safetyPlans.userId, userId));
    await tx.delete(emergencyEvents).where(eq(emergencyEvents.userId, userId));
    await tx.delete(analyses).where(eq(analyses.userId, userId));
    await tx.delete(contacts).where(eq(contacts.userId, userId));
    await tx.delete(notificationPreferences).where(eq(notificationPreferences.userId, userId));
    await tx.delete(smartwatchSettings).where(eq(smartwatchSettings.userId, userId));
    await tx.delete(profiles).where(eq(profiles.userId, userId));
    await tx.delete(workAudit).where(eq(workAudit.ownerId, userId));
    await tx.delete(workShifts).where(eq(workShifts.ownerId, userId));
    await tx.delete(passwordResets).where(eq(passwordResets.userId, userId));
    await tx.delete(authTotp).where(eq(authTotp.userId, userId));
    await tx.delete(watchPairings).where(eq(watchPairings.userId, userId));
    await tx.delete(watchDevices).where(eq(watchDevices.userId, userId));
    await tx.delete(authSessions).where(eq(authSessions.userId, userId));
    await tx.delete(authCredentials).where(eq(authCredentials.userId, userId));
    // The opaque technical row is NOT an active account: no credentials or
    // sessions remain, and the original OAuth/openId is no longer linked.
    // Preserve the id solely for FK integrity and the other participant's chat.
    await tx.update(users).set({
      openId: `deleted:${userId}`,
      name: "Conta excluída",
      email: null,
      loginMethod: "deleted",
      role: "user",
    }).where(eq(users.id, userId));
    return { success: true };
  });
}

export async function listContacts(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  return db.select().from(contacts).where(eq(contacts.userId, userId)).orderBy(desc(contacts.isEmergency), asc(contacts.emergencyPriority), asc(contacts.name));
}

export async function createContact(userId: number, values: Omit<typeof contacts.$inferInsert, "id" | "userId" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(contacts).values({ userId, ...values });
  const id = Number(result[0].insertId);
  const rows = await db.select().from(contacts).where(and(eq(contacts.id, id), eq(contacts.userId, userId))).limit(1);
  return rows[0];
}

export async function updateContact(userId: number, id: number, values: Partial<typeof contacts.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(contacts).set({ ...values, updatedAt: new Date() }).where(and(eq(contacts.id, id), eq(contacts.userId, userId)));
  const rows = await db.select().from(contacts).where(and(eq(contacts.id, id), eq(contacts.userId, userId))).limit(1);
  return rows[0];
}

export async function deleteContact(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(contacts).where(and(eq(contacts.id, id), eq(contacts.userId, userId)));
  return { success: true };
}

export async function listAnalyses(userId: number, options?: { result?: string; limit?: number; offset?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const where = options?.result ? and(eq(analyses.userId, userId), eq(analyses.result, options.result)) : eq(analyses.userId, userId);
  return db.select().from(analyses).where(where).orderBy(desc(analyses.createdAt)).limit(options?.limit ?? 50).offset(options?.offset ?? 0);
}

export async function getAnalysis(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(analyses).where(and(eq(analyses.id, id), eq(analyses.userId, userId))).limit(1);
  return rows[0];
}

export async function createAnalysis(userId: number, values: Omit<typeof analyses.$inferInsert, "id" | "userId" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(analyses).values({ userId, ...values });
  const rows = await db.select().from(analyses).where(and(eq(analyses.id, Number(result[0].insertId)), eq(analyses.userId, userId))).limit(1);
  return rows[0];
}

export async function deleteAnalysis(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(analyses).where(and(eq(analyses.id, id), eq(analyses.userId, userId)));
  return { success: true };
}

export async function deleteAllAnalyses(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(analyses).where(eq(analyses.userId, userId));
  return { success: true };
}

export async function getPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, userId)).limit(1);
  return rows[0];
}

export async function savePreferences(userId: number, values: Partial<NotificationPreferences>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getPreferences(userId);
  if (existing) {
    await db.update(notificationPreferences).set({ ...values, updatedAt: new Date() }).where(eq(notificationPreferences.userId, userId));
  } else {
    await db.insert(notificationPreferences).values({ userId, ...values });
  }
  return getPreferences(userId);
}

export async function getSmartwatchSettings(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(smartwatchSettings).where(eq(smartwatchSettings.userId, userId)).limit(1);
  return rows[0];
}

export async function saveSmartwatchSettings(userId: number, values: Partial<typeof smartwatchSettings.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getSmartwatchSettings(userId);
  if (existing) {
    await db.update(smartwatchSettings).set({ ...values, updatedAt: new Date() }).where(eq(smartwatchSettings.userId, userId));
  } else {
    await db.insert(smartwatchSettings).values({ userId, ...values });
  }
  return getSmartwatchSettings(userId);
}

export async function getActiveEmergency(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  const rows = await db.select().from(emergencyEvents).where(and(eq(emergencyEvents.userId, userId), eq(emergencyEvents.status, "active"))).orderBy(desc(emergencyEvents.createdAt)).limit(1);
  // React Query treats an `undefined` query result as an invalid/failed query.
  // Return null so the API can distinguish a confirmed inactive state from a
  // real database or authentication failure.
  return rows[0] ?? null;
}

export async function createEmergency(userId: number, message?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const active = await getActiveEmergency(userId);
  if (active) return { event: active, created: false };
  try {
    const result = await db.insert(emergencyEvents).values({ userId, activeKey: String(userId), message });
    const rows = await db.select().from(emergencyEvents).where(and(eq(emergencyEvents.id, Number(result[0].insertId)), eq(emergencyEvents.userId, userId))).limit(1);
    return { event: rows[0], created: true };
  } catch (error) {
    const concurrent = await getActiveEmergency(userId);
    if (concurrent) return { event: concurrent, created: false };
    throw error;
  }
}

export async function updateEmergency(userId: number, id: number, values: Partial<typeof emergencyEvents.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(emergencyEvents).set({ ...values, ...(values.status === "cancelled" ? { activeKey: null } : {}) }).where(and(eq(emergencyEvents.id, id), eq(emergencyEvents.userId, userId)));
  const rows = await db.select().from(emergencyEvents).where(and(eq(emergencyEvents.id, id), eq(emergencyEvents.userId, userId))).limit(1);
  return rows[0];
}

export async function createInboxNotification(userId: number, values: Omit<typeof inboxNotifications.$inferInsert, "id" | "userId" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.transaction(async tx => {
    await tx.insert(inboxNotifications).values({ userId, ...values });
    if (values.isRead === 1) return;
    const devices = await tx.select({ id: pushDevices.id }).from(pushDevices).where(eq(pushDevices.userId, userId));
    if (devices.length) await tx.insert(pushQueue).values(devices.map(device => ({ userId, deviceId: device.id })));
  });
  return { success: true };
}

export async function listInboxNotifications(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível. Tente novamente mais tarde.");
  return db.select().from(inboxNotifications).where(eq(inboxNotifications.userId, userId)).orderBy(desc(inboxNotifications.createdAt)).limit(20);
}

import { createHash, randomBytes, randomInt } from "node:crypto";
import { and, desc, eq, gt, isNull } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import type { Express, Request, Response } from "express";
import { watchDevices, watchPairings, users } from "../drizzle/schema";
import { getDb } from "./db";
import { createLoginLimiter } from "./auth";
import type { AppRouter } from "./routers";
import { protectedProcedure, router } from "./_core/trpc";

const digest = (s: string) => createHash("sha256").update(s).digest("hex");
const PAIR_MINUTES = 5;
const TOKEN_DAYS = 30;
const pairInput = z.object({ code: z.string().regex(/^\d{8}$/), label: z.string().trim().min(1).max(80) });

async function database() {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  return db;
}

// A senha de emparelhamento é digitada no relógio. Ela nunca vira credencial duradoura.
export const watchRouter = router({
  beginPairing: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await database();
    const code = String(randomInt(0, 100_000_000)).padStart(8, "0");
    await db.delete(watchPairings).where(eq(watchPairings.userId, ctx.user.id));
    const expiresAt = new Date(Date.now() + PAIR_MINUTES * 60_000);
    await db.insert(watchPairings).values({ userId: ctx.user.id, codeHash: digest(code), expiresAt });
    return { code, expiresAt }; // mostrar uma vez só, para usuário autenticado no navegador
  }),
  devices: protectedProcedure.query(async ({ ctx }) => {
    const db = await database();
    return db.select({ id: watchDevices.id, label: watchDevices.label, lastSeenAt: watchDevices.lastSeenAt,
      createdAt: watchDevices.createdAt, expiresAt: watchDevices.expiresAt, revokedAt: watchDevices.revokedAt })
      .from(watchDevices).where(eq(watchDevices.userId, ctx.user.id)).orderBy(desc(watchDevices.createdAt));
  }),
  revoke: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const db = await database();
    await db.update(watchDevices).set({ revokedAt: new Date() })
      .where(and(eq(watchDevices.id, input.id), eq(watchDevices.userId, ctx.user.id), isNull(watchDevices.revokedAt)));
    return { success: true };
  }),
});

function sendError(res: Response, error: unknown) {
  if (error instanceof TRPCError) {
    const statuses: Record<string, number> = { UNAUTHORIZED: 401, FORBIDDEN: 403, NOT_FOUND: 404, BAD_REQUEST: 400, CONFLICT: 409, PRECONDITION_FAILED: 412 };
    return res.status(statuses[error.code] ?? 500).json({ error: error.message });
  }
  console.error("[Watch API]", error instanceof Error ? error.message : "Erro inesperado");
  return res.status(500).json({ error: "Não foi possível processar a solicitação." });
}

// Rota REST do dispositivo, isolada dos cookies do navegador. Token é bearer revogável.
export function registerWatchRoutes(app: Express, apiRouter: AppRouter) {
  const pairLimiter = createLoginLimiter(); // exige controle de taxa no proxy em múltiplas instâncias
  app.post("/api/watch/pair", pairLimiter, async (req, res) => {
    const parsed = pairInput.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "Código ou identificação inválida." }); return; }
    try {
      const db = await database();
      const codeHash = digest(parsed.data.code);
      const now = new Date();
      const token = randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + TOKEN_DAYS * 86400000);
      // Consumo atômico: código de uso único mesmo entre chamadas concorrentes.
      const userId = await db.transaction(async tx => {
        const [pair] = await tx.select().from(watchPairings)
          .where(and(eq(watchPairings.codeHash, codeHash), gt(watchPairings.expiresAt, now)))
          .for("update").limit(1);
        if (!pair) return null;
        await tx.delete(watchPairings).where(eq(watchPairings.id, pair.id));
        // Administradores também podem utilizar o relógio, mas sempre com escopo de usuário.
        const [anyAccount] = await tx.select({ id: users.id, loginMethod: users.loginMethod }).from(users).where(eq(users.id, pair.userId)).limit(1);
        if (!anyAccount || anyAccount.loginMethod === "deleted") return null;
        await tx.insert(watchDevices).values({ userId: pair.userId, tokenHash: digest(token), label: parsed.data.label, expiresAt });
        return pair.userId;
      });
      if (!userId) { res.status(401).json({ error: "Código inválido ou expirado." }); return; }
      res.json({ token, expiresAt, userId });
    } catch (err) { sendError(res, err); }
  });

  // Não disponibiliza credenciais de sessão de browser nem conta pessoal a este cliente.
  const authenticated = async (req: Request, res: Response, next: () => void) => {
    try {
      const header = req.get("authorization") ?? "";
      const match = /^Bearer ([0-9a-f]{64})$/.exec(header);
      if (!match) { res.status(401).json({ error: "Relógio não vinculado." }); return; }
      const db = await database();
      const [record] = await db.select({ device: watchDevices, user: users }).from(watchDevices)
        .innerJoin(users, eq(users.id, watchDevices.userId))
        .where(and(eq(watchDevices.tokenHash, digest(match[1])), isNull(watchDevices.revokedAt), gt(watchDevices.expiresAt, new Date())))
        .limit(1);
      if (!record || record.user.loginMethod === "deleted") { res.status(401).json({ error: "Acesso revogado ou expirado." }); return; }
      // Atualização leve; operação de auditoria ou geo não precisa acontecer a cada requisição.
      res.locals.watchUser = record.user;
      res.locals.watchDeviceId = record.device.id;
      await db.update(watchDevices).set({ lastSeenAt: new Date() }).where(eq(watchDevices.id, record.device.id));
      next();
    } catch (err) { sendError(res, err); }
  };

  app.use("/api/watch/v1", authenticated);
  function caller(req: Request, res: Response) {
    // O tRPC usa o mesmo usuário e as mesmas validações de ownership do portal.
    return apiRouter.createCaller({ req, res, user: res.locals.watchUser });
  }
  app.get("/api/watch/v1/shifts", async (req, res) => {
    try {
      const shifts = await caller(req, res).workforce.list();
      res.json({ shifts: shifts.slice(0, 100).map(s => ({ id: s.id, title: s.title, professionalName: s.professionalName,
        startsAt: s.startsAt, endsAt: s.endsAt, status: s.status, checkInAt: s.checkInAt, checkOutAt: s.checkOutAt })) });
    } catch (err) { sendError(res, err); }
  });
  app.post("/api/watch/v1/attendance", async (req, res) => {
    const input = z.object({ id: z.number().int().positive(), action: z.enum(["in", "out"]) }).safeParse(req.body);
    if (!input.success) { res.status(400).json({ error: "Presença inválida." }); return; }
    try { res.json(await caller(req, res).workforce.attendance(input.data)); }
    catch (err) { sendError(res, err); }
  });
  app.get("/api/watch/v1/conversations", async (req, res) => {
    try {
      const items = await caller(req, res).chat.conversations();
      res.json({ conversations: items.slice(0, 30) });
    } catch (err) { sendError(res, err); }
  });
  app.get("/api/watch/v1/messages/:id", async (req, res) => {
    const conversationId = Number(req.params.id);
    if (!Number.isSafeInteger(conversationId) || conversationId <= 0) { res.status(400).json({ error: "Conversa inválida." }); return; }
    try { res.json(await caller(req, res).chat.thread({ conversationId })); }
    catch (err) { sendError(res, err); }
  });
  app.post("/api/watch/v1/messages", async (req, res) => {
    const parsed = z.object({ conversationId: z.number().int().positive(), message: z.string().trim().min(1).max(2000) }).safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "Mensagem inválida." }); return; }
    try { res.json(await caller(req, res).chat.send(parsed.data)); }
    catch (err) { sendError(res, err); }
  });
  app.get("/api/watch/v1/alerts", async (req, res) => {
    try {
      const all = await caller(req, res).inbox.list();
      res.json({ alerts: all.slice(0, 30).map(n => ({ id: n.id, title: n.title, eventType: n.eventType,
        createdAt: n.createdAt, isRead: n.isRead })) }); // sem corpo de alerta ou dados médicos
    } catch (err) { sendError(res, err); }
  });
  app.post("/api/watch/v1/unpair", async (req, res) => {
    try {
      const db = await database();
      await db.update(watchDevices).set({ revokedAt: new Date() }).where(eq(watchDevices.id, res.locals.watchDeviceId));
      res.json({ success: true });
    } catch (err) { sendError(res, err); }
  });
}

import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import { getDb } from "./db";
import { workforceRouter } from "./workforce";
import { workShifts, workAudit } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";
import { scriptedDb, type ReadStep } from "./testSupport/scriptedDb";
vi.mock("./db", () => ({ getDb: vi.fn() }));
beforeEach(() => vi.resetAllMocks());
const caller = () =>
  workforceRouter.createCaller({
    user: { id: 7, role: "user" },
  } as TrpcContext);
const input = {
  professionalName: "Ana Silva",
  title: "UTI",
  startsAt: new Date("2026-11-09T07:00:00-03:00"),
  endsAt: new Date("2026-11-09T19:00:00-03:00"),
};
const planned = {
  ...input,
  id: 42,
  ownerId: 7,
  status: "planned",
  checkInAt: null,
  checkOutAt: null,
};
function use(reads: ReadStep[]) {
  const h = scriptedDb(reads);
  vi.mocked(getDb).mockResolvedValue(h.db as never);
  return h;
}
describe("workforce flows with scripted persistence", () => {
  it("creates a shift under the authenticated owner with an audit entry", async () => {
    const h = use([{ rows: [{ id: 7 }] }, { rows: [] }]);
    await expect(caller().create(input)).resolves.toMatchObject({ id: 42 });
    expect(h.writes.find(w => w.table === workShifts)?.values).toMatchObject({
      ...input,
      ownerId: 7,
      hourlyCents: 0,
    });
    expect(h.writes.find(w => w.table === workAudit)?.values).toMatchObject({
      ownerId: 7,
      shiftId: 42,
      action: "shift.created",
    });
  });
  it("refuses overlapping shifts without writing", async () => {
    const h = use([{ rows: [{ id: 7 }] }, { rows: [planned] }]);
    await expect(caller().create(input)).rejects.toMatchObject({
      code: "CONFLICT",
    });
    expect(h.writes).toHaveLength(0);
  });
  it("edits a planned shift and records the audit", async () => {
    const h = use([
      { rows: [{ id: 7 }] },
      { rows: [planned] },
      { rows: [planned] },
    ]);
    await expect(
      caller().update({ ...input, id: 42, title: "Enfermaria" })
    ).resolves.toEqual({ success: true });
    expect(h.writes.find(w => w.kind === "update")?.values.title).toBe(
      "Enfermaria"
    );
    expect(h.writes.find(w => w.table === workAudit)?.values.action).toBe(
      "shift.updated"
    );
  });
  it("restricts attendance lookup to the authenticated owner", async () => {
    const h = use([
      {
        rows: [],
        inspect: where =>
          expect(new MySqlDialect().sqlToQuery(where!).params).toEqual([42, 7]),
      },
    ]);
    await expect(
      caller().attendance({ id: 42, action: "in" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(h.writes).toHaveLength(0);
  });
  it("records entry then exit, and rejects repeated entry or editing a started shift", async () => {
    const entry = use([{ rows: [planned] }]);
    await caller().attendance({ id: 42, action: "in" });
    const recorded = entry.writes.find(w => w.kind === "update")!.values;
    expect(recorded).toMatchObject({
      status: "confirmed",
      checkInAt: expect.any(Date),
    });
    const started = { ...planned, ...recorded };
    const duplicate = use([{ rows: [started] }]);
    await expect(
      caller().attendance({ id: 42, action: "in" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(duplicate.writes).toHaveLength(0);
    const edit = use([{ rows: [{ id: 7 }] }, { rows: [started] }]);
    await expect(caller().update({ ...input, id: 42 })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
    expect(edit.writes).toHaveLength(0);
    const exit = use([{ rows: [started] }]);
    await caller().attendance({ id: 42, action: "out" });
    expect(exit.writes.find(w => w.kind === "update")?.values).toMatchObject({
      status: "completed",
      checkOutAt: expect.any(Date),
    });
  });
  it("cancels a planned shift and refuses attendance on cancellation", async () => {
    const cancel = use([{ rows: [planned] }]);
    await caller().cancel({ id: 42 });
    expect(cancel.writes.find(w => w.kind === "update")?.values.status).toBe(
      "cancelled"
    );
    const attendance = use([{ rows: [{ ...planned, status: "cancelled" }] }]);
    await expect(
      caller().attendance({ id: 42, action: "in" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(attendance.writes).toHaveLength(0);
  });
});

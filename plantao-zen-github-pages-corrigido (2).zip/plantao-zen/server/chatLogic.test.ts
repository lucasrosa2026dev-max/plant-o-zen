import { describe, expect, it } from "vitest";
import {
  canRespondToChatRequest,
  canSearchChatDirectory,
  canSendChatMessage,
  makeChatPairKey,
  orderChatParticipantIds,
  MAX_CHAT_MESSAGE_LENGTH,
  normalizeChatMessage,
} from "./chatLogic";

describe("chat access and validation", () => {
  it("uses the same stable pair key regardless of participant order", () => {
    expect(makeChatPairKey(8, 3)).toBe("3:8");
    expect(makeChatPairKey(3, 8)).toBe("3:8");
    expect(() => makeChatPairKey(3, 3)).toThrow("consigo mesmo");
  });

  it("orders and deduplicates participant IDs for database locks", () => {
    expect(orderChatParticipantIds(8, 3)).toEqual([3, 8]);
    expect(orderChatParticipantIds(8, 3, 8)).toEqual([3, 8]);
  });

  it("only exposes a user to directory searches after explicit opt-in", () => {
    expect(
      canSearchChatDirectory({
        discoverable: false,
        query: "Ana",
        isSelf: false,
        isBlocked: false,
      }),
    ).toBe(false);
    expect(
      canSearchChatDirectory({
        discoverable: true,
        query: "A",
        isSelf: false,
        isBlocked: false,
      }),
    ).toBe(false);
    expect(
      canSearchChatDirectory({
        discoverable: true,
        query: "Ana",
        isSelf: false,
        isBlocked: false,
      }),
    ).toBe(true);
    expect(
      canSearchChatDirectory({
        discoverable: true,
        query: "Ana",
        isSelf: true,
        isBlocked: false,
      }),
    ).toBe(false);
    expect(
      canSearchChatDirectory({
        discoverable: true,
        query: "Ana",
        isSelf: false,
        isBlocked: true,
      }),
    ).toBe(false);
  });

  it("allows only the request recipient to accept or decline a pending request", () => {
    expect(
      canRespondToChatRequest({
        status: "pending",
        actorId: 2,
        recipientId: 2,
      }),
    ).toBe(true);
    expect(
      canRespondToChatRequest({
        status: "pending",
        actorId: 1,
        recipientId: 2,
      }),
    ).toBe(false);
    expect(
      canRespondToChatRequest({
        status: "accepted",
        actorId: 2,
        recipientId: 2,
      }),
    ).toBe(false);
  });

  it("permits messages only for accepted, unblocked participants", () => {
    expect(
      canSendChatMessage({
        status: "accepted",
        isParticipant: true,
        isBlocked: false,
      }),
    ).toBe(true);
    expect(
      canSendChatMessage({
        status: "pending",
        isParticipant: true,
        isBlocked: false,
      }),
    ).toBe(false);
    expect(
      canSendChatMessage({
        status: "accepted",
        isParticipant: false,
        isBlocked: false,
      }),
    ).toBe(false);
    expect(
      canSendChatMessage({
        status: "accepted",
        isParticipant: true,
        isBlocked: true,
      }),
    ).toBe(false);
  });

  it("trims and bounds chat message text", () => {
    expect(normalizeChatMessage("  Olá!  ")).toBe("Olá!");
    expect(() => normalizeChatMessage("  ")).toThrow("Escreva uma mensagem");
    expect(() =>
      normalizeChatMessage("x".repeat(MAX_CHAT_MESSAGE_LENGTH + 1)),
    ).toThrow("no máximo");
  });
});

import { and, eq, ne } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { authCredentials, authSessions, authTotp } from "../drizzle/schema";
import { getDb } from "./db";
import { hashToken, sessionToken, verifyPassword } from "./auth";
import { createTotpSecret, decryptSecret, encryptSecret, matchingTotpStep } from "./securityV2";
import { protectedProcedure, router } from "./_core/trpc";

async function accountDb(id: number, password: string) {
  const db = await getDb(); if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE" });
  const [creds] = await db.select().from(authCredentials).where(eq(authCredentials.userId, id)).limit(1);
  if (!creds || !(await verifyPassword(password, creds.passwordHash))) throw new TRPCError({ code: "FORBIDDEN", message: "Senha incorreta." });
  return db;
}
const passwordInput = z.object({ password: z.string().min(1).max(128) });
export const securityRouter = router({
  twoFactorStatus: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb(); if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE" });
    const [record] = await db.select({ enabledAt: authTotp.enabledAt }).from(authTotp).where(eq(authTotp.userId, ctx.user.id));
    return { enabled: !!record?.enabledAt, setupPending: !!record && !record.enabledAt };
  }),
  beginTwoFactor: protectedProcedure.input(passwordInput).mutation(async ({ ctx, input }) => {
    const db = await accountDb(ctx.user.id, input.password);
    const [current] = await db.select().from(authTotp).where(eq(authTotp.userId, ctx.user.id));
    if (current?.enabledAt) throw new TRPCError({ code: "CONFLICT", message: "2FA já está ativo." });
    const secret = createTotpSecret();
    await db.delete(authTotp).where(eq(authTotp.userId, ctx.user.id));
    await db.insert(authTotp).values({ userId: ctx.user.id, secretEncrypted: encryptSecret(secret) });
    const account = encodeURIComponent(ctx.user.email ?? String(ctx.user.id));
    return { secret, uri: `otpauth://totp/Plantao%20Zen%20Health:${account}?secret=${secret}&issuer=Plantao%20Zen%20Health&digits=6&period=30` };
  }),
  enableTwoFactor: protectedProcedure.input(z.object({ code: z.string().regex(/^\d{6}$/) })).mutation(async ({ ctx, input }) => {
    const db = await getDb(); if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE" });
    const [record] = await db.select().from(authTotp).where(eq(authTotp.userId, ctx.user.id));
    if (!record || record.enabledAt) throw new TRPCError({ code: "BAD_REQUEST", message: "Inicie a ativação." });
    const step = matchingTotpStep(decryptSecret(record.secretEncrypted), input.code);
    if (step === null) throw new TRPCError({ code: "FORBIDDEN", message: "Código inválido." });
    const updated = await db.update(authTotp).set({ enabledAt: new Date(), lastUsedStep: step }).where(and(eq(authTotp.userId, ctx.user.id), eq(authTotp.lastUsedStep, record.lastUsedStep)));
    if (!updated[0].affectedRows) throw new TRPCError({ code: "CONFLICT", message: "Código já utilizado." });
    // Existing sessions on other devices are no longer trusted after enabling MFA.
    const token = sessionToken(ctx.req);
    if (token) await db.delete(authSessions).where(and(eq(authSessions.userId, ctx.user.id), ne(authSessions.tokenHash, hashToken(token))));
    return { success: true };
  }),
  disableTwoFactor: protectedProcedure.input(passwordInput.extend({ code: z.string().regex(/^\d{6}$/) })).mutation(async ({ ctx, input }) => {
    const db = await accountDb(ctx.user.id, input.password);
    const [record] = await db.select().from(authTotp).where(eq(authTotp.userId, ctx.user.id));
    if (!record?.enabledAt || matchingTotpStep(decryptSecret(record.secretEncrypted), input.code, record.lastUsedStep) === null) throw new TRPCError({ code: "FORBIDDEN", message: "Código inválido." });
    await db.delete(authTotp).where(eq(authTotp.userId, ctx.user.id));
    await db.delete(authSessions).where(eq(authSessions.userId, ctx.user.id));
    return { success: true, signInAgain: true };
  }),
  revokeOtherSessions: protectedProcedure.input(passwordInput).mutation(async ({ ctx, input }) => {
    const db = await accountDb(ctx.user.id, input.password);
    const token = sessionToken(ctx.req); if (!token) throw new TRPCError({ code: "UNAUTHORIZED" });
    await db.delete(authSessions).where(and(eq(authSessions.userId, ctx.user.id), ne(authSessions.tokenHash, hashToken(token))));
    return { success: true };
  }),
  sessionCount: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb(); if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE" });
    const rows = await db.select({ tokenHash: authSessions.tokenHash }).from(authSessions).where(eq(authSessions.userId, ctx.user.id));
    return { count: rows.length }; // Never disclose raw session tokens.
  }),
});

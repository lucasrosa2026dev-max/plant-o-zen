import { createCipheriv, createDecipheriv, createHmac, randomBytes, timingSafeEqual } from "node:crypto";

// RFC 6238 SHA-1, compatível com apps autenticadores comuns; aceita +/- 30 s.
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
export function toBase32(input: Buffer): string {
  let acc = 0, bits = 0, output = "";
  for (const byte of input) { acc = (acc << 8) | byte; bits += 8; while (bits >= 5) { bits -= 5; output += alphabet[(acc >>> bits) & 31]; } }
  if (bits) output += alphabet[(acc << (5 - bits)) & 31];
  return output;
}
export function fromBase32(secret: string): Buffer {
  let acc = 0, bits = 0; const bytes: number[] = [];
  for (const ch of secret.toUpperCase().replace(/=+$/, "")) {
    const n = alphabet.indexOf(ch); if (n < 0) throw new Error("Invalid secret");
    acc = (acc << 5) | n; bits += 5;
    if (bits >= 8) { bits -= 8; bytes.push((acc >>> bits) & 255); }
  }
  return Buffer.from(bytes);
}
export function createTotpSecret() { return toBase32(randomBytes(20)); }
export function totpAt(secret: string, step: number): string {
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(step));
  const digest = createHmac("sha1", fromBase32(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 15;
  const code = ((digest.readUInt32BE(offset) & 0x7fffffff) % 1_000_000);
  return code.toString().padStart(6, "0");
}
export function matchingTotpStep(secret: string, code: string, lastUsedStep = 0, now = Date.now()): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const step = Math.floor(now / 30_000);
  for (let s = step - 1; s <= step + 1; s++) {
    if (s <= lastUsedStep) continue;
    if (timingSafeEqual(Buffer.from(totpAt(secret, s)), Buffer.from(code))) return s;
  }
  return null;
}
function encryptionKey(): Buffer {
  const key = process.env.TOTP_ENCRYPTION_KEY;
  if (!key || !/^[0-9a-fA-F]{64}$/.test(key)) throw new Error("TOTP_ENCRYPTION_KEY precisa conter 32 bytes em hexadecimal");
  return Buffer.from(key, "hex");
}
export function encryptSecret(secret: string): string {
  const iv = randomBytes(12); const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return [iv, cipher.getAuthTag(), encrypted].map(part => part.toString("base64url")).join(".");
}
export function decryptSecret(value: string): string {
  const [iv, tag, ciphertext] = value.split(".");
  if (!iv || !tag || !ciphertext) throw new Error("Invalid encrypted secret");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64url"));
  decipher.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertext, "base64url")), decipher.final()]).toString("utf8");
}

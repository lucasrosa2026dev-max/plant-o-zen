import { importPKCS8, SignJWT } from "jose";

export type PushResult = "accepted" | "invalid_token" | "retry";
export function pushConfigured() {
  return Boolean(
    process.env.FCM_PROJECT_ID &&
      process.env.FCM_CLIENT_EMAIL &&
      process.env.FCM_PRIVATE_KEY
  );
}
let cached: { value: string; until: number } | undefined;
let pending: Promise<string> | undefined;
async function accessToken(): Promise<string> {
  if (cached && cached.until > Date.now()) return cached.value;
  if (pending) return pending;
  pending = (async () => {
    const key = await importPKCS8(
      process.env.FCM_PRIVATE_KEY!.replace(/\\n/g, "\n"),
      "RS256"
    );
    const assertion = await new SignJWT({
      scope: "https://www.googleapis.com/auth/firebase.messaging",
    })
      .setProtectedHeader({ alg: "RS256" })
      .setIssuer(process.env.FCM_CLIENT_EMAIL!)
      .setAudience("https://oauth2.googleapis.com/token")
      .setIssuedAt()
      .setExpirationTime("1h")
      .sign(key);
    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      signal: AbortSignal.timeout(10000),
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion,
      }),
    });
    if (!response.ok) throw new Error("FCM authentication failed");
    const data = (await response.json()) as {
      access_token?: string;
      expires_in?: number;
    };
    if (!data.access_token) throw new Error("FCM access token missing");
    cached = {
      value: data.access_token,
      until: Date.now() + Math.max(0, (data.expires_in ?? 3600) - 120) * 1000,
    };
    return cached.value;
  })().finally(() => {
    pending = undefined;
  });
  return pending;
}
export function classifyFcmResponse(status: number, body: unknown): PushResult {
  if (status >= 200 && status < 300) return "accepted";
  const details = (
    body as {
      error?: { details?: Array<{ "@type"?: string; errorCode?: string }> };
    }
  )?.error?.details;
  return Array.isArray(details) &&
    details.some(
      item =>
        item["@type"] ===
          "type.googleapis.com/google.firebase.fcm.v1.FcmError" &&
        item.errorCode === "UNREGISTERED"
    )
    ? "invalid_token"
    : "retry";
}
export function pushMessage(token: string, test: boolean, id: number) {
  // Never send names, health data, contact details or the emergency message to FCM.
  return {
    message: {
      token,
      notification: {
        title: test ? "Plantão Zen • teste" : "Plantão Zen • novo aviso",
        body: test
          ? "Teste de notificação. Nenhuma emergência foi acionada."
          : "Abra o Plantão Zen para conferir sua caixa de entrada.",
      },
      data: { route: "/", pushId: String(id) },
      android: {
        priority: "high",
        ttl: "300s",
        notification: {
          channel_id: "plantao_alerts",
          sound: "default",
          icon: "ic_notification",
          tag: `plantao-${id}`,
          visibility: "PRIVATE",
        },
      },
    },
  };
}
export async function sendAndroidPush(
  token: string,
  test: boolean,
  id: number
): Promise<PushResult> {
  if (!pushConfigured()) return "retry";
  try {
    const response = await fetch(
      `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(process.env.FCM_PROJECT_ID!)}/messages:send`,
      {
        method: "POST",
        signal: AbortSignal.timeout(15000),
        headers: {
          Authorization: `Bearer ${await accessToken()}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(pushMessage(token, test, id)),
      }
    );
    if (response.status === 401) cached = undefined;
    return classifyFcmResponse(
      response.status,
      await response.json().catch(() => null)
    );
  } catch {
    return "retry";
  }
}

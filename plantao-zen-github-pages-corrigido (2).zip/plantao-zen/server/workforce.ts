import { and, desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { users, workAudit, workShifts } from "../drizzle/schema";
import { shiftConflicts } from "../shared/workforce";
export { shiftConflicts } from "../shared/workforce";
import { getDb } from "./db";
import { protectedProcedure, router } from "./_core/trpc";

const dbOrThrow = async () => {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Banco indisponível",
    });
  return db;
};
const shiftInput = z.object({
  professionalName: z.string().trim().min(2).max(120),
  title: z.string().trim().min(2).max(160),
  startsAt: z.coerce.date(),
  endsAt: z.coerce.date(),
});
export const workforceRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await dbOrThrow();
    return db
      .select()
      .from(workShifts)
      .where(eq(workShifts.ownerId, ctx.user.id))
      .orderBy(desc(workShifts.startsAt));
  }),
  create: protectedProcedure
    .input(shiftInput)
    .mutation(async ({ ctx, input }) => {
      if (input.endsAt <= input.startsAt)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Término deve ser após o início",
        });
      const db = await dbOrThrow();
      return db.transaction(async tx => {
        // Lock the owner even for empty schedules to serialize concurrent creations.
        const [owner] = await tx
          .select({ id: users.id })
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .for("update");
        if (!owner) throw new TRPCError({ code: "UNAUTHORIZED" });
        const existing = await tx
          .select()
          .from(workShifts)
          .where(eq(workShifts.ownerId, ctx.user.id));
        const conflicts = shiftConflicts(
          existing.filter(s => s.status !== "cancelled"),
          input
        );
        if (conflicts.length)
          throw new TRPCError({
            code: "CONFLICT",
            message: [...new Set(conflicts)].join("; "),
          });
        const result = await tx
          .insert(workShifts)
          .values({ ...input, hourlyCents: 0, ownerId: ctx.user.id });
        const shiftId = Number(result[0].insertId);
        await tx
          .insert(workAudit)
          .values({
            ownerId: ctx.user.id,
            shiftId,
            action: "shift.created",
            details: JSON.stringify({
              professionalName: input.professionalName,
              title: input.title,
            }),
          });
        return { success: true, id: shiftId };
      });
    }),
  update: protectedProcedure
    .input(shiftInput.extend({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      if (input.endsAt <= input.startsAt)
        throw new TRPCError({ code: "BAD_REQUEST", message: "Término deve ser após o início" });
      const db = await dbOrThrow();
      return db.transaction(async tx => {
        const [owner] = await tx.select({ id: users.id }).from(users)
          .where(eq(users.id, ctx.user.id)).for("update");
        if (!owner) throw new TRPCError({ code: "UNAUTHORIZED" });
        const [shift] = await tx.select().from(workShifts)
          .where(and(eq(workShifts.id, input.id), eq(workShifts.ownerId, ctx.user.id)))
          .for("update");
        if (!shift) throw new TRPCError({ code: "NOT_FOUND" });
        if (shift.status !== "planned" || shift.checkInAt)
          throw new TRPCError({ code: "BAD_REQUEST", message: "Apenas plantões planejados sem presença podem ser editados" });
        const others = await tx.select().from(workShifts)
          .where(eq(workShifts.ownerId, ctx.user.id));
        const conflicts = shiftConflicts(others.filter(s => s.id !== input.id && s.status !== "cancelled"), input);
        if (conflicts.length)
          throw new TRPCError({ code: "CONFLICT", message: [...new Set(conflicts)].join("; ") });
        await tx.update(workShifts).set({
          professionalName: input.professionalName, title: input.title,
          startsAt: input.startsAt, endsAt: input.endsAt,
        }).where(and(eq(workShifts.id, input.id), eq(workShifts.ownerId, ctx.user.id)));
        await tx.insert(workAudit).values({ ownerId: ctx.user.id, shiftId: input.id,
          action: "shift.updated", details: JSON.stringify({
            before: { professionalName: shift.professionalName, title: shift.title, startsAt: shift.startsAt, endsAt: shift.endsAt },
            after: { professionalName: input.professionalName, title: input.title, startsAt: input.startsAt, endsAt: input.endsAt },
          }) });
        return { success: true };
      });
    }),
  cancel: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await dbOrThrow();
      return db.transaction(async tx => {
        const [shift] = await tx.select().from(workShifts)
          .where(and(eq(workShifts.id, input.id), eq(workShifts.ownerId, ctx.user.id)))
          .for("update");
        if (!shift) throw new TRPCError({ code: "NOT_FOUND" });
        if (shift.status !== "planned" || shift.checkInAt)
          throw new TRPCError({ code: "BAD_REQUEST", message: "Não é possível cancelar plantão iniciado ou concluído" });
        await tx.update(workShifts).set({ status: "cancelled" })
          .where(and(eq(workShifts.id, input.id), eq(workShifts.ownerId, ctx.user.id)));
        await tx.insert(workAudit).values({ ownerId: ctx.user.id, shiftId: input.id,
          action: "shift.cancelled", details: JSON.stringify({ title: shift.title, professionalName: shift.professionalName }) });
        return { success: true };
      });
    }),
  attendance: protectedProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        action: z.enum(["in", "out"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await dbOrThrow();
      return db.transaction(async tx => {
        const [shift] = await tx
          .select()
          .from(workShifts)
          .where(
            and(
              eq(workShifts.id, input.id),
              eq(workShifts.ownerId, ctx.user.id)
            )
          )
          .for("update");
        if (!shift) throw new TRPCError({ code: "NOT_FOUND" });
        if (shift.status === "cancelled")
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Plantão cancelado",
          });
        if (
          (input.action === "in" && shift.checkInAt) ||
          (input.action === "out" && (!shift.checkInAt || shift.checkOutAt))
        )
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Sequência de presença inválida",
          });
        await tx
          .update(workShifts)
          .set(
            input.action === "in"
              ? { checkInAt: new Date(), status: "confirmed" }
              : { checkOutAt: new Date(), status: "completed" }
          )
          .where(
            and(
              eq(workShifts.id, input.id),
              eq(workShifts.ownerId, ctx.user.id)
            )
          );
        await tx
          .insert(workAudit)
          .values({
            ownerId: ctx.user.id,
            shiftId: input.id,
            action: `attendance.${input.action}`,
          });
        return { success: true };
      });
    }),
  audit: protectedProcedure.query(async ({ ctx }) => {
    const db = await dbOrThrow();
    return db
      .select()
      .from(workAudit)
      .where(eq(workAudit.ownerId, ctx.user.id))
      .orderBy(desc(workAudit.createdAt))
      .limit(100);
  }),
});

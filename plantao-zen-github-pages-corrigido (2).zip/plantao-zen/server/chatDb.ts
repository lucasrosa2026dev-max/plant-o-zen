import {
  and,
  asc,
  desc,
  eq,
  gt,
  inArray,
  isNull,
  like,
  ne,
  or,
  sql,
} from "drizzle-orm";
import { nanoid } from "nanoid";
import {
  chatBlocks,
  chatConversations,
  chatMessages,
  chatReports,
  chatSettings,
  profiles,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";
import {
  canRespondToChatRequest,
  canSearchChatDirectory,
  canSendChatMessage,
  makeChatPairKey,
  normalizeChatMessage,
  orderChatParticipantIds,
} from "./chatLogic";

export type ChatDataErrorCode =
  | "BAD_REQUEST"
  | "CONFLICT"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "PRECONDITION_FAILED";

export class ChatDataError extends Error {
  constructor(
    readonly code: ChatDataErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "ChatDataError";
  }
}

function requireDatabase(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db)
    throw new ChatDataError(
      "PRECONDITION_FAILED",
      "O serviço de mensagens está indisponível no momento.",
    );
  return db;
}

async function isBlockedPair(userId: number, otherUserId: number) {
  const db = requireDatabase(await getDb());
  const rows = await db
    .select({ id: chatBlocks.id })
    .from(chatBlocks)
    .where(
      or(
        and(
          eq(chatBlocks.blockerId, userId),
          eq(chatBlocks.blockedUserId, otherUserId),
        ),
        and(
          eq(chatBlocks.blockerId, otherUserId),
          eq(chatBlocks.blockedUserId, userId),
        ),
      ),
    )
    .limit(1);
  return rows.length > 0;
}

export async function getChatSettings(userId: number) {
  const db = requireDatabase(await getDb());
  const rows = await db
    .select({
      discoverable: chatSettings.discoverable,
      publicChatId: chatSettings.publicChatId,
    })
    .from(chatSettings)
    .where(eq(chatSettings.userId, userId))
    .limit(1);
  return {
    discoverable: rows[0]?.discoverable === 1,
    publicChatId: rows[0]?.publicChatId ?? null,
  };
}

export async function saveChatSettings(userId: number, discoverable: boolean) {
  const db = requireDatabase(await getDb());
  await db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, userId))
      .for("update")
      .limit(1);
    if (lockedUsers.length !== 1)
      throw new ChatDataError("NOT_FOUND", "Esta conta não foi encontrada.");
    const rows = await tx
      .select({ userId: chatSettings.userId })
      .from(chatSettings)
      .where(eq(chatSettings.userId, userId))
      .limit(1);
    if (rows[0]) {
      await tx
        .update(chatSettings)
        .set({ discoverable: discoverable ? 1 : 0, updatedAt: new Date() })
        .where(eq(chatSettings.userId, userId));
    } else {
      await tx.insert(chatSettings).values({
        userId,
        publicChatId: nanoid(20),
        discoverable: discoverable ? 1 : 0,
      });
    }
  });
  return getChatSettings(userId);
}

export async function searchChatDirectory(userId: number, rawQuery: string) {
  const query = rawQuery.trim();
  if (query.length < 2) return [];
  const db = requireDatabase(await getDb());
  const ownSettings = await getChatSettings(userId);
  if (
    !canSearchChatDirectory({
      discoverable: ownSettings.discoverable,
      query,
      isSelf: false,
      isBlocked: false,
    })
  )
    return [];
  const escaped = query.replace(/[\\%_]/g, "\\$&");
  const displayName = sql<string>`COALESCE(NULLIF(TRIM(${profiles.fullName}), ''), NULLIF(TRIM(${users.name}), ''), 'Pessoa do Plantão Zen')`;
  const matches = await db
    .select({
      userId: users.id,
      publicChatId: chatSettings.publicChatId,
      name: displayName,
    })
    .from(chatSettings)
    .innerJoin(users, eq(chatSettings.userId, users.id))
    .leftJoin(profiles, eq(profiles.userId, users.id))
    .where(
      and(
        eq(chatSettings.discoverable, 1),
        ne(users.id, userId),
        like(displayName, `${escaped}%`),
      ),
    )
    .orderBy(asc(displayName))
    .limit(100);
  const blockedByMe = await db
    .select({ userId: chatBlocks.blockedUserId })
    .from(chatBlocks)
    .where(eq(chatBlocks.blockerId, userId));
  const blockedMe = await db
    .select({ userId: chatBlocks.blockerId })
    .from(chatBlocks)
    .where(eq(chatBlocks.blockedUserId, userId));
  const excluded = new Set(
    [...blockedByMe, ...blockedMe].map((row) => row.userId),
  );
  return matches
    .filter((match) => !excluded.has(match.userId))
    .slice(0, 20)
    .map(({ publicChatId, name }) => ({
      publicChatId,
      name,
    }));
}

export async function startChatRequest(
  userId: number,
  targetPublicChatId: string,
  rawMessage: string,
) {
  const body = normalizeChatMessage(rawMessage);
  const db = requireDatabase(await getDb());
  const ownSettings = await getChatSettings(userId);
  if (!ownSettings.discoverable)
    throw new ChatDataError(
      "PRECONDITION_FAILED",
      "Ative a participação no chat para iniciar uma conversa.",
    );
  const targets = await db
    .select({ userId: chatSettings.userId })
    .from(chatSettings)
    .where(
      and(
        eq(chatSettings.publicChatId, targetPublicChatId),
        eq(chatSettings.discoverable, 1),
      ),
    )
    .limit(1);
  const target = targets[0];
  if (!target)
    throw new ChatDataError(
      "NOT_FOUND",
      "Esta pessoa não está disponível no diretório do chat.",
    );
  if (target.userId === userId)
    throw new ChatDataError(
      "BAD_REQUEST",
      "Não é possível iniciar uma conversa consigo mesmo.",
    );
  if (await isBlockedPair(userId, target.userId))
    throw new ChatDataError("FORBIDDEN", "A conversa não está disponível.");

  const pairKey = makeChatPairKey(userId, target.userId);
  return db.transaction(async (tx) => {
    const participantIds = orderChatParticipantIds(userId, target.userId);
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== participantIds.length)
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta pessoa não está disponível no diretório do chat.",
      );
    const [currentOwnSettings] = await tx
      .select({ discoverable: chatSettings.discoverable })
      .from(chatSettings)
      .where(eq(chatSettings.userId, userId))
      .limit(1);
    if (currentOwnSettings?.discoverable !== 1)
      throw new ChatDataError(
        "PRECONDITION_FAILED",
        "Ative a participação no chat para iniciar uma conversa.",
      );
    const [currentTargetSettings] = await tx
      .select({
        publicChatId: chatSettings.publicChatId,
        discoverable: chatSettings.discoverable,
      })
      .from(chatSettings)
      .where(eq(chatSettings.userId, target.userId))
      .limit(1);
    if (
      currentTargetSettings?.discoverable !== 1 ||
      currentTargetSettings.publicChatId !== targetPublicChatId
    )
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta pessoa não está disponível no diretório do chat.",
      );
    const transactionBlocks = await tx
      .select({ id: chatBlocks.id })
      .from(chatBlocks)
      .where(
        or(
          and(
            eq(chatBlocks.blockerId, userId),
            eq(chatBlocks.blockedUserId, target.userId),
          ),
          and(
            eq(chatBlocks.blockerId, target.userId),
            eq(chatBlocks.blockedUserId, userId),
          ),
        ),
      )
      .limit(1);
    if (transactionBlocks.length > 0)
      throw new ChatDataError("FORBIDDEN", "A conversa não está disponível.");
    const existingRows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.pairKey, pairKey))
      .limit(1);
    const existing = existingRows[0];
    if (existing) {
      if (existing.status === "accepted") {
        const inserted = await tx
          .insert(chatMessages)
          .values({ conversationId: existing.id, senderId: userId, body });
        const messageId = Number(inserted[0].insertId);
        await tx
          .update(chatConversations)
          .set({ lastMessageAt: new Date(), updatedAt: new Date() })
          .where(eq(chatConversations.id, existing.id));
        return {
          conversationId: existing.id,
          status: existing.status,
          created: false,
          messageId,
        };
      }
      if (existing.status === "pending")
        return {
          conversationId: existing.id,
          status: existing.status,
          created: false,
          messageId: null,
        };
      throw new ChatDataError(
        "CONFLICT",
        "Este pedido foi recusado e não pode ser enviado novamente.",
      );
    }

    const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recentRequests = await tx
      .select({ id: chatConversations.id })
      .from(chatConversations)
      .where(
        and(
          eq(chatConversations.requestedById, userId),
          gt(chatConversations.createdAt, hourAgo),
        ),
      )
      .limit(5);
    if (recentRequests.length >= 5)
      throw new ChatDataError(
        "PRECONDITION_FAILED",
        "Você atingiu o limite de 5 novos pedidos por hora. Tente novamente mais tarde.",
      );

    const [participantAId, participantBId] = [userId, target.userId].sort(
      (a, b) => a - b,
    );
    const inserted = await tx.insert(chatConversations).values({
      pairKey,
      participantAId,
      participantBId,
      requestedById: userId,
      status: "pending",
    });
    const conversationId = Number(inserted[0].insertId);
    const firstMessage = await tx
      .insert(chatMessages)
      .values({ conversationId, senderId: userId, body });
    await tx
      .update(chatConversations)
      .set({ lastMessageAt: new Date() })
      .where(eq(chatConversations.id, conversationId));
    return {
      conversationId,
      status: "pending" as const,
      created: true,
      messageId: Number(firstMessage[0].insertId),
    };
  });
}

export async function listChatConversations(userId: number) {
  const db = requireDatabase(await getDb());
  return db.transaction(async (tx) => {
    const lockedUser = await tx
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, userId))
      .for("update")
      .limit(1);
    if (lockedUser.length !== 1) return [];
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(
        and(
          or(
            eq(chatConversations.participantAId, userId),
            eq(chatConversations.participantBId, userId),
          ),
          ne(chatConversations.status, "declined"),
        ),
      )
      .orderBy(desc(chatConversations.lastMessageAt))
      .limit(50);
    const result = await Promise.all(
      rows.map(async (conversation) => {
        const otherUserId =
          conversation.participantAId === userId
            ? conversation.participantBId
            : conversation.participantAId;
        const blocks = await tx
          .select({ id: chatBlocks.id })
          .from(chatBlocks)
          .where(
            or(
              and(
                eq(chatBlocks.blockerId, userId),
                eq(chatBlocks.blockedUserId, otherUserId),
              ),
              and(
                eq(chatBlocks.blockerId, otherUserId),
                eq(chatBlocks.blockedUserId, userId),
              ),
            ),
          )
          .limit(1);
        if (blocks.length > 0) return null;
        const [otherUser] = await tx
          .select({
            name: sql<string>`COALESCE(NULLIF(TRIM(${profiles.fullName}), ''), NULLIF(TRIM(${users.name}), ''), 'Pessoa do Plantão Zen')`,
          })
          .from(users)
          .leftJoin(profiles, eq(profiles.userId, users.id))
          .where(eq(users.id, otherUserId))
          .limit(1);
        const [lastMessage] = await tx
          .select({
            body: chatMessages.body,
            senderId: chatMessages.senderId,
            createdAt: chatMessages.createdAt,
            readAt: chatMessages.readAt,
          })
          .from(chatMessages)
          .where(eq(chatMessages.conversationId, conversation.id))
          .orderBy(desc(chatMessages.id))
          .limit(1);
        return {
          id: conversation.id,
          status: conversation.status,
          direction:
            conversation.requestedById === userId
              ? ("outgoing" as const)
              : ("incoming" as const),
          otherName: otherUser?.name || "Pessoa do Plantão Zen",
          lastMessage: lastMessage?.body || "",
          lastMessageAt: lastMessage?.createdAt || conversation.createdAt,
          lastMessageIsMine: lastMessage?.senderId === userId,
          lastMessageReadAt: lastMessage?.readAt || null,
        };
      }),
    );
    return result.filter(
      (item): item is NonNullable<typeof item> => item !== null,
    );
  });
}

export async function getChatThread(userId: number, conversationId: number) {
  const db = requireDatabase(await getDb());
  const candidates = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);
  const candidate = candidates[0];
  if (
    !candidate ||
    (candidate.participantAId !== userId && candidate.participantBId !== userId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta conversa não está disponível.",
      );
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== userId &&
        conversation.participantBId !== userId) ||
      conversation.status === "declined"
    )
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta conversa não está disponível.",
      );
    const otherUserId =
      conversation.participantAId === userId
        ? conversation.participantBId
        : conversation.participantAId;
    const blocks = await tx
      .select({ id: chatBlocks.id })
      .from(chatBlocks)
      .where(
        or(
          and(
            eq(chatBlocks.blockerId, userId),
            eq(chatBlocks.blockedUserId, otherUserId),
          ),
          and(
            eq(chatBlocks.blockerId, otherUserId),
            eq(chatBlocks.blockedUserId, userId),
          ),
        ),
      )
      .limit(1);
    if (blocks.length > 0)
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta conversa não está disponível.",
      );
    const messages = await tx
      .select({
        id: chatMessages.id,
        senderId: chatMessages.senderId,
        body: chatMessages.body,
        createdAt: chatMessages.createdAt,
        readAt: chatMessages.readAt,
      })
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(desc(chatMessages.id))
      .limit(100);
    const [otherUser] = await tx
      .select({
        name: sql<string>`COALESCE(NULLIF(TRIM(${profiles.fullName}), ''), NULLIF(TRIM(${users.name}), ''), 'Pessoa do Plantão Zen')`,
      })
      .from(users)
      .leftJoin(profiles, eq(profiles.userId, users.id))
      .where(eq(users.id, otherUserId))
      .limit(1);
    return {
      conversation: {
        id: conversation.id,
        status: conversation.status,
        direction:
          conversation.requestedById === userId
            ? ("outgoing" as const)
            : ("incoming" as const),
        otherName: otherUser?.name || "Pessoa do Plantão Zen",
      },
      messages: messages.reverse().map(({ senderId, ...message }) => ({
        ...message,
        isMine: senderId === userId,
      })),
    };
  });
}

export async function sendChatMessage(
  userId: number,
  conversationId: number,
  rawMessage: string,
) {
  const body = normalizeChatMessage(rawMessage);
  const db = requireDatabase(await getDb());
  const candidates = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);
  const candidate = candidates[0];
  if (
    !candidate ||
    (candidate.participantAId !== userId && candidate.participantBId !== userId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id, loginMethod: users.loginMethod })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    if (lockedUsers.some(person => person.loginMethod === "deleted"))
      throw new ChatDataError("PRECONDITION_FAILED", "Esta conversa é somente leitura porque uma conta foi excluída.");
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== userId &&
        conversation.participantBId !== userId)
    )
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const otherUserId =
      conversation.participantAId === userId
        ? conversation.participantBId
        : conversation.participantAId;
    const blocks = await tx
      .select({ id: chatBlocks.id })
      .from(chatBlocks)
      .where(
        or(
          and(
            eq(chatBlocks.blockerId, userId),
            eq(chatBlocks.blockedUserId, otherUserId),
          ),
          and(
            eq(chatBlocks.blockerId, otherUserId),
            eq(chatBlocks.blockedUserId, userId),
          ),
        ),
      )
      .limit(1);
    const allowed = canSendChatMessage({
      status: conversation.status,
      isParticipant: true,
      isBlocked: blocks.length > 0,
    });
    if (!allowed)
      throw new ChatDataError(
        "PRECONDITION_FAILED",
        "Só é possível enviar mensagens após a pessoa aceitar o pedido e enquanto não houver bloqueio.",
      );
    const inserted = await tx
      .insert(chatMessages)
      .values({ conversationId, senderId: userId, body });
    await tx
      .update(chatConversations)
      .set({ lastMessageAt: new Date(), updatedAt: new Date() })
      .where(eq(chatConversations.id, conversationId));
    return { success: true, messageId: Number(inserted[0].insertId) };
  });
}

export async function respondToChatRequest(
  userId: number,
  conversationId: number,
  action: "accept" | "decline",
) {
  const db = requireDatabase(await getDb());
  const candidates = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);
  const candidate = candidates[0];
  if (
    !candidate ||
    (candidate.participantAId !== userId && candidate.participantBId !== userId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id, loginMethod: users.loginMethod })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    if (lockedUsers.some(person => person.loginMethod === "deleted"))
      throw new ChatDataError("PRECONDITION_FAILED", "Esta conversa é somente leitura porque uma conta foi excluída.");
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== userId &&
        conversation.participantBId !== userId)
    )
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const recipientId =
      conversation.participantAId === conversation.requestedById
        ? conversation.participantBId
        : conversation.participantAId;
    if (
      !canRespondToChatRequest({
        status: conversation.status,
        actorId: userId,
        recipientId,
      })
    )
      throw new ChatDataError(
        "FORBIDDEN",
        "Somente quem recebeu o pedido pode aceitar ou recusar uma solicitação pendente.",
      );
    const otherUserId = conversation.participantAId === userId
      ? conversation.participantBId : conversation.participantAId;
    const blocks = await tx
      .select({ id: chatBlocks.id })
      .from(chatBlocks)
      .where(
        or(
          and(
            eq(chatBlocks.blockerId, userId),
            eq(chatBlocks.blockedUserId, otherUserId),
          ),
          and(
            eq(chatBlocks.blockerId, otherUserId),
            eq(chatBlocks.blockedUserId, userId),
          ),
        ),
      )
      .limit(1);
    if (blocks.length > 0)
      throw new ChatDataError("FORBIDDEN", "Esta conversa está bloqueada.");
    const updated = await tx
      .update(chatConversations)
      .set({
        status: action === "accept" ? "accepted" : "declined",
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(chatConversations.id, conversationId),
          eq(chatConversations.status, "pending"),
        ),
      );
    if (Number(updated[0]?.affectedRows ?? 0) !== 1)
      throw new ChatDataError(
        "CONFLICT",
        "Este pedido já foi respondido. Atualize a lista de conversas.",
      );
    return {
      success: true,
      status:
        action === "accept" ? ("accepted" as const) : ("declined" as const),
    };
  });
}

export async function blockChatConversation(
  userId: number,
  conversationId: number,
) {
  const db = requireDatabase(await getDb());
  const candidates = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);
  const candidate = candidates[0];
  if (
    !candidate ||
    (candidate.participantAId !== userId && candidate.participantBId !== userId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== userId &&
        conversation.participantBId !== userId)
    )
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const otherUserId =
      conversation.participantAId === userId
        ? conversation.participantBId
        : conversation.participantAId;
    await tx
      .insert(chatBlocks)
      .values({ blockerId: userId, blockedUserId: otherUserId })
      .onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
    return { success: true };
  });
}

export async function listBlockedChatUsers(userId: number) {
  const db = requireDatabase(await getDb());
  const blocks = await db
    .select({
      blockedUserId: chatBlocks.blockedUserId,
      createdAt: chatBlocks.createdAt,
    })
    .from(chatBlocks)
    .where(eq(chatBlocks.blockerId, userId))
    .orderBy(desc(chatBlocks.createdAt));
  const result = await Promise.all(
    blocks.map(async (block) => {
      const [user] = await db
        .select({
          publicChatId: chatSettings.publicChatId,
          name: sql<string>`COALESCE(NULLIF(TRIM(${profiles.fullName}), ''), NULLIF(TRIM(${users.name}), ''), 'Pessoa do Plantão Zen')`,
        })
        .from(users)
        .leftJoin(chatSettings, eq(chatSettings.userId, users.id))
        .leftJoin(profiles, eq(profiles.userId, users.id))
        .where(eq(users.id, block.blockedUserId))
        .limit(1);
      return user?.publicChatId
        ? {
            publicChatId: user.publicChatId,
            name: user.name || "Pessoa do Plantão Zen",
            createdAt: block.createdAt,
          }
        : null;
    }),
  );
  return result.filter(
    (item): item is NonNullable<typeof item> => item !== null,
  );
}

export async function unblockChatUser(
  userId: number,
  targetPublicChatId: string,
) {
  const db = requireDatabase(await getDb());
  const [target] = await db
    .select({ userId: chatSettings.userId })
    .from(chatSettings)
    .where(eq(chatSettings.publicChatId, targetPublicChatId))
    .limit(1);
  if (!target)
    throw new ChatDataError(
      "NOT_FOUND",
      "A pessoa bloqueada não foi encontrada.",
    );
  if (target.userId === userId)
    throw new ChatDataError(
      "BAD_REQUEST",
      "Você não pode desbloquear a própria conta.",
    );
  const participantIds = orderChatParticipantIds(userId, target.userId);
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError(
        "NOT_FOUND",
        "A pessoa bloqueada não foi encontrada.",
      );
    const [currentTarget] = await tx
      .select({ userId: chatSettings.userId })
      .from(chatSettings)
      .where(
        and(
          eq(chatSettings.userId, target.userId),
          eq(chatSettings.publicChatId, targetPublicChatId),
        ),
      )
      .limit(1);
    if (!currentTarget)
      throw new ChatDataError(
        "NOT_FOUND",
        "A pessoa bloqueada não foi encontrada.",
      );
    await tx
      .delete(chatBlocks)
      .where(
        and(
          eq(chatBlocks.blockerId, userId),
          eq(chatBlocks.blockedUserId, currentTarget.userId),
        ),
      );
    return { success: true };
  });
}

export async function reportChatUser(input: {
  reporterId: number;
  conversationId: number;
  messageId?: number;
  reason: "harassment" | "spam" | "safety" | "other";
  details?: string;
}) {
  const db = requireDatabase(await getDb());
  const candidates = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, input.conversationId))
    .limit(1);
  const candidate = candidates[0];
  if (
    !candidate ||
    (candidate.participantAId !== input.reporterId &&
      candidate.participantBId !== input.reporterId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, input.conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== input.reporterId &&
        conversation.participantBId !== input.reporterId)
    )
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    if (conversation.status === "declined")
      throw new ChatDataError(
        "NOT_FOUND",
        "Esta conversa não está disponível para denúncia.",
      );
    const otherUserId =
      conversation.participantAId === input.reporterId
        ? conversation.participantBId
        : conversation.participantAId;
    if (input.messageId) {
      const [message] = await tx
        .select({ senderId: chatMessages.senderId })
        .from(chatMessages)
        .where(
          and(
            eq(chatMessages.id, input.messageId),
            eq(chatMessages.conversationId, input.conversationId),
          ),
        )
        .limit(1);
      if (!message || message.senderId !== otherUserId)
        throw new ChatDataError(
          "BAD_REQUEST",
          "Selecione uma mensagem da outra pessoa para denunciar.",
        );
    }
    await tx.insert(chatReports).values({
      conversationId: input.conversationId,
      messageId: input.messageId ?? null,
      reporterId: input.reporterId,
      reportedUserId: otherUserId,
      reason: input.reason,
      details: input.details?.trim() || null,
      status: "open",
    });
    return { success: true };
  });
}

export async function listChatReportsAdmin() {
  const db = requireDatabase(await getDb());
  const reports = await db
    .select()
    .from(chatReports)
    .orderBy(desc(chatReports.createdAt))
    .limit(100);
  return Promise.all(
    reports.map(async (report) => {
      const [reporter] = await db
        .select({ name: users.name })
        .from(users)
        .where(eq(users.id, report.reporterId))
        .limit(1);
      const [reported] = await db
        .select({ name: users.name })
        .from(users)
        .where(eq(users.id, report.reportedUserId))
        .limit(1);
      let message: string | null = null;
      if (report.messageId) {
        const [row] = await db
          .select({ body: chatMessages.body })
          .from(chatMessages)
          .where(eq(chatMessages.id, report.messageId))
          .limit(1);
        message = row?.body || null;
      }
      return {
        ...report,
        reporterName: reporter?.name || "Conta removida",
        reportedName: reported?.name || "Conta removida",
        message,
      };
    }),
  );
}

export async function reviewChatReport(
  adminId: number,
  reportId: number,
  status: "reviewed" | "actioned",
) {
  const db = requireDatabase(await getDb());
  const rows = await db
    .select({ id: chatReports.id })
    .from(chatReports)
    .where(eq(chatReports.id, reportId))
    .limit(1);
  if (!rows[0])
    throw new ChatDataError("NOT_FOUND", "Esta denúncia não foi encontrada.");
  await db
    .update(chatReports)
    .set({ status, reviewedById: adminId, reviewedAt: new Date() })
    .where(eq(chatReports.id, reportId));
  return { success: true };
}

export async function markChatMessagesRead(
  userId: number,
  conversationId: number,
) {
  const db = requireDatabase(await getDb());
  const [candidate] = await db
    .select()
    .from(chatConversations)
    .where(eq(chatConversations.id, conversationId))
    .limit(1);
  if (
    !candidate ||
    (candidate.participantAId !== userId && candidate.participantBId !== userId)
  )
    throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
  const participantIds = orderChatParticipantIds(
    candidate.participantAId,
    candidate.participantBId,
  );
  return db.transaction(async (tx) => {
    const lockedUsers = await tx
      .select({ id: users.id })
      .from(users)
      .where(inArray(users.id, participantIds))
      .orderBy(asc(users.id))
      .for("update");
    if (lockedUsers.length !== 2)
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    const rows = await tx
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .for("update")
      .limit(1);
    const conversation = rows[0];
    if (
      !conversation ||
      (conversation.participantAId !== userId &&
        conversation.participantBId !== userId)
    )
      throw new ChatDataError("NOT_FOUND", "Esta conversa não foi encontrada.");
    if (conversation.status === "declined") return { success: true };
    const otherUserId =
      conversation.participantAId === userId
        ? conversation.participantBId
        : conversation.participantAId;
    const blocks = await tx
      .select({ id: chatBlocks.id })
      .from(chatBlocks)
      .where(
        or(
          and(
            eq(chatBlocks.blockerId, userId),
            eq(chatBlocks.blockedUserId, otherUserId),
          ),
          and(
            eq(chatBlocks.blockerId, otherUserId),
            eq(chatBlocks.blockedUserId, userId),
          ),
        ),
      )
      .limit(1);
    if (blocks.length > 0) return { success: true };
    await tx
      .update(chatMessages)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(chatMessages.conversationId, conversationId),
          ne(chatMessages.senderId, userId),
          isNull(chatMessages.readAt),
        ),
      );
    return { success: true };
  });
}

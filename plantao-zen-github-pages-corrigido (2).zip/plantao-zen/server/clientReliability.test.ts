import { describe, it, expect, vi } from "vitest";
import { QueryClient } from "@tanstack/react-query";
import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { csvCell } from "../shared/csv";
import { clearSessionCache } from "../client/src/lib/sessionCache";

describe("safe CSV export", () => {
  it.each(["=1+1", "+cmd", "@SUM(A1)", "-1", " \t=1", "\r=1", "\ntext"])("neutralizes %j", value => {
    expect(csvCell(value)).toBe(`"'${value}"`);
  });
  it("preserves names, empty values, quotes and separators", () => {
    expect(csvCell('João; "UTI"')).toBe('"João; ""UTI"""');
    expect(csvCell(null)).toBe('""');
  });
});

describe("session cache isolation", () => {
  it("removes previous account data, mutations and in-flight responses", async () => {
    const client = new QueryClient();
    client.setQueryData(["contacts"], [{ name: "Private" }]);
    let finish!: (value: string) => void;
    const pending = client.fetchQuery({ queryKey: ["messages"], queryFn: () => new Promise<string>(resolve => { finish = resolve; }) }).catch(() => undefined);
    client.getMutationCache().build(client, { mutationFn: async () => "private" });
    await clearSessionCache(client);
    finish("late private response");
    await pending;
    expect(client.getQueryCache().getAll()).toEqual([]);
    expect(client.getMutationCache().getAll()).toEqual([]);
  });
});

function worker() {
  const handlers: Record<string, (event: any) => void> = {};
  const put = vi.fn().mockResolvedValue(undefined);
  const fetch = vi.fn();
  const caches = { open: vi.fn().mockResolvedValue({ put, addAll: vi.fn().mockResolvedValue(undefined) }),
    match: vi.fn().mockResolvedValue(undefined), keys: vi.fn().mockResolvedValue(["plantao-zen-shell-v2", "another-app"]), delete: vi.fn().mockResolvedValue(true) };
  runInNewContext(readFileSync(new URL("../client/public/sw.js", import.meta.url), "utf8"), {
    self: { location: { origin: "https://example.test" }, addEventListener: (name: string, fn: (event: any) => void) => { handlers[name] = fn; }, clients: { claim: vi.fn() }, skipWaiting: vi.fn() },
    caches, fetch, URL, Response,
  });
  function request(path: string, mode = "cors") {
    const event = { request: { url: `https://example.test${path}`, method: "GET", mode }, respondWith: vi.fn(), waitUntil: vi.fn() };
    handlers.fetch(event); return event;
  }
  return { handlers, request, put, fetch, caches };
}
describe("offline privacy and recovery", () => {
  it.each(["/api", "/api/trpc/auth.me", "/oauth/callback?code=secret", "/private-report.pdf", "/icon.svg?token=secret"])("does not intercept %s", path => {
    expect(worker().request(path).respondWith).not.toHaveBeenCalled();
  });
  it("does not persist authenticated navigation", async () => {
    const w = worker();w.fetch.mockResolvedValue(new Response("private page"));
    await w.request("/profile", "navigate").respondWith.mock.calls[0][0];expect(w.put).not.toHaveBeenCalled();
  });
  it("returns a dedicated offline page instead of cached account data", async () => {
    const w = worker(); w.fetch.mockRejectedValue(new Error("offline"));w.caches.match.mockResolvedValue(new Response("offline page") as never);
    const result = await w.request("/profile", "navigate").respondWith.mock.calls[0][0];
    expect(await result.text()).toBe("offline page");expect(w.caches.match).toHaveBeenCalledWith("/offline.html");
  });
  it("does not cache unsuccessful static responses", async () => {
    const w = worker();w.fetch.mockResolvedValue(new Response("error", { status: 500 }));
    const result = await w.request("/icon.svg").respondWith.mock.calls[0][0];
    expect(result.status).toBe(500);expect(w.put).not.toHaveBeenCalled();
  });
  it("does not return HTML for a failed image request", async () => {
    const w = worker();w.fetch.mockRejectedValue(new Error("offline"));
    const result = await w.request("/icon.svg").respondWith.mock.calls[0][0];expect(result.type).toBe("error");
  });
  it("deletes only old Plantão Zen caches", async () => {
    const w = worker();const waitUntil = vi.fn();w.handlers.activate({ waitUntil });await waitUntil.mock.calls[0][0];
    expect(w.caches.delete.mock.calls).toEqual([["plantao-zen-shell-v2"]]);
  });
});

import { dayTimelinePosition } from "../shared/workforce";
describe("24-hour shift timeline", () => {
  it("shows the evening portion of an overnight shift", () => {
    const result = dayTimelinePosition("2026-11-04T19:00:00", "2026-11-05T07:00:00", "2026-11-04");
    expect(result?.left).toBeCloseTo(19 / 24 * 100);
    expect(result?.width).toBeCloseTo(5 / 24 * 100);
  });
  it("shows the morning portion on the following day", () => {
    const result = dayTimelinePosition("2026-11-04T19:00:00", "2026-11-05T07:00:00", "2026-11-05");
    expect(result?.left).toBe(0);expect(result?.width).toBeCloseTo(7 / 24 * 100);
  });
  it("does not draw a phantom bar for a different day", () => {
    expect(dayTimelinePosition("2026-11-03T07:00:00", "2026-11-04T00:00:00", "2026-11-04")).toBeNull();
  });
});

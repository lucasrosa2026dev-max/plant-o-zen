import { afterEach, describe, expect, it, vi } from "vitest";
import { postAuth } from "../client/src/lib/authRequest";
afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
});
describe("browser access response contract", () => {
  it("sends same-origin credentials and accepts explicit success", async () => {
    const fetch = vi
      .fn()
      .mockResolvedValue(new Response(JSON.stringify({ success: true })));
    vi.stubGlobal("fetch", fetch);
    await expect(
      postAuth("register", { email: "test@example.com" })
    ).resolves.toEqual({ success: true });
    expect(fetch.mock.calls[0][1]).toMatchObject({
      credentials: "same-origin",
      method: "POST",
    });
  });
  it("requires an explicit second-factor challenge and never treats 202 as a session", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockImplementation(
          async () =>
            new Response(JSON.stringify({ requires2fa: true }), { status: 202 })
        )
    );
    await expect(postAuth("login", {})).resolves.toEqual({ requires2fa: true });
    await expect(postAuth("register", {})).rejects.toThrow("resposta");
  });
  it("rejects a successful HTTP status with a malformed result", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("{}")));
    await expect(postAuth("reset-password", {})).rejects.toThrow("confirmar");
  });
  it("identifies the second factor in rejection feedback", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response("{}", { status: 401 }))
    );
    await expect(postAuth("login", { totpCode: "123456" })).rejects.toThrow(
      "autenticador"
    );
  });
  it("times out recovery and releases its timer after failure", async () => {
    vi.useFakeTimers();
    vi.stubGlobal(
      "fetch",
      vi.fn(
        (_url, init) =>
          new Promise((_resolve, reject) =>
            init.signal.addEventListener("abort", () =>
              reject(new DOMException("Aborted", "AbortError"))
            )
          )
      )
    );
    const request = expect(postAuth("forgot-password", {})).rejects.toThrow(
      "demorou"
    );
    await vi.advanceTimersByTimeAsync(20000);
    await request;
    expect(vi.getTimerCount()).toBe(0);
  });
});

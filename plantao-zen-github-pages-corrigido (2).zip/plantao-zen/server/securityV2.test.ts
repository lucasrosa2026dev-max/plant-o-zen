import { describe, it, expect, beforeEach } from "vitest";
import { createTotpSecret, toBase32, fromBase32, totpAt, matchingTotpStep, encryptSecret, decryptSecret } from "./securityV2";

describe("security v2: TOTP e criptografia", () => {
  beforeEach(() => { process.env.TOTP_ENCRYPTION_KEY = "a".repeat(64); });
  it("reproduz vetor RFC 6238 SHA1 truncado em 6 dígitos", () => {
    const secret = toBase32(Buffer.from("12345678901234567890"));
    expect(secret).toBe("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ");
    expect(totpAt(secret, 1)).toBe("287082");
    expect(fromBase32(secret).toString()).toBe("12345678901234567890");
  });
  it("não reutiliza o mesmo código na mesma janela", () => {
    const secret = toBase32(Buffer.from("12345678901234567890"));
    expect(matchingTotpStep(secret, "287082", 0, 59_000)).toBe(1);
    expect(matchingTotpStep(secret, "287082", 1, 59_000)).toBeNull();
    expect(matchingTotpStep(secret, "abcdef", 0, 59_000)).toBeNull();
  });
  it("cifra e autentica o segredo", () => {
    const secret = createTotpSecret();
    const encrypted = encryptSecret(secret);
    expect(encrypted).not.toContain(secret);
    expect(decryptSecret(encrypted)).toBe(secret);
    expect(() => decryptSecret(encrypted.slice(0, -1) + "X")).toThrow();
  });
});

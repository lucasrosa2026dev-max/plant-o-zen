import { afterEach, describe, expect, it, vi } from "vitest";
import express, { type Request, type Response, type NextFunction } from "express";
import { createServer } from "node:http";
import { authenticateRequest, createLoginLimiter, credentialsSchema, hashPassword, registerAuthRoutes, sameOriginOnly, sessionToken, verifyPassword } from "./auth";
import { COOKIE_NAME } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";

afterEach(() => vi.unstubAllEnvs());
describe("standalone authentication", () => {
  it("salts passwords and rejects incorrect passwords and malformed hashes", async () => {
    const hash = await hashPassword("test-password-123");
    expect(hash).not.toContain("test-password");
    expect(await hashPassword("test-password-123")).not.toBe(hash);
    expect(await verifyPassword("test-password-123", hash)).toBe(true);
    expect(await verifyPassword("wrong-password-123", hash)).toBe(false);
    expect(await verifyPassword("test-password-123", "invalid")).toBe(false);
  });
  it("normalizes emails and enforces password bounds", () => {
    expect(credentialsSchema.parse({ email: " TEST@example.com ", password: "a".repeat(12) }).email).toBe("test@example.com");
    for (const password of ["short", "a".repeat(129)]) expect(credentialsSchema.safeParse({ email: "a@b.com", password }).success).toBe(false);
  });
  it("uses only its own opaque session cookie, never bearer credentials", async () => {
    const req = { headers: { authorization: "Bearer arbitrary" } } as Request;
    expect(sessionToken(req)).toBeUndefined();
    expect(await authenticateRequest(req)).toBeNull();
    expect(sessionToken({ headers: { cookie: `${COOKIE_NAME}=invalid` } } as Request)).toBeUndefined();
    expect(sessionToken({ headers: { cookie: `${COOKIE_NAME}=${"a".repeat(64)}` } } as Request)).toBe("a".repeat(64));
  });
  it("protects production cookies while allowing local HTTP development", () => {
    vi.stubEnv("NODE_ENV", "production");
    expect(getSessionCookieOptions({ protocol: "http" } as Request)).toMatchObject({ secure: true, httpOnly: true, sameSite: "lax" });
    vi.stubEnv("NODE_ENV", "development");
    expect(getSessionCookieOptions({ protocol: "http" } as Request).secure).toBe(false);
  });
  it("limits attempts and allows retry after the window", () => {
    let time = 0;
    const limiter = createLoginLimiter(() => time);
    const next = vi.fn(); const res = { status: vi.fn().mockReturnThis(), set: vi.fn().mockReturnThis(), json: vi.fn() };
    for (let i = 0; i < 21; i++) limiter({ ip: "127.0.0.1" } as Request, res as unknown as Response, next as NextFunction);
    expect(next).toHaveBeenCalledTimes(20); expect(res.status).toHaveBeenCalledWith(429);
    time = 15 * 60 * 1000;
    limiter({ ip: "127.0.0.1" } as Request, res as unknown as Response, next as NextFunction);
    expect(next).toHaveBeenCalledTimes(21);
  });
  it("blocks cross-origin and missing-origin writes, validates login, reports missing DB", async () => {
    vi.stubEnv("APP_URL", "https://plantao.example");
    vi.stubEnv("DATABASE_URL", "");
    const app = express(); app.use(express.json()); app.use(sameOriginOnly); registerAuthRoutes(app);
    const server = createServer(app);
    await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
    try {
      const address = server.address() as { port: number };
      const url = `http://127.0.0.1:${address.port}/api/auth/login`;
      for (const origin of [undefined, "https://attacker.example"]) {
        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (origin) headers.Origin = origin;
        expect((await fetch(url, { method: "POST", headers, body: "{}" })).status).toBe(403);
      }
      const headers = { "Content-Type": "application/json", Origin: "https://plantao.example" };
      expect((await fetch(url, { method: "POST", headers, body: "{}" })).status).toBe(400);
      const response = await fetch(url, { method: "POST", headers, body: JSON.stringify({ email: "test@example.com", password: "test-password-123" }) });
      expect(response.status).toBe(503); expect(response.headers.get("set-cookie")).toBeNull();
    } finally { await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve())); }
  });
});

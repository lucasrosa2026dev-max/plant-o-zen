import { beforeEach, describe, expect, it, vi } from "vitest";
import { classifyFcmResponse, pushMessage } from "./pushTransport";
import type { TrpcContext } from "./_core/context";
const mocked = vi.hoisted(() => ({ db: vi.fn() }));
vi.mock("./db", () => ({ getDb: mocked.db }));
import { pushRouter, pushTokenSchema } from "./push";
const context = (user: boolean) =>
  ({
    user: user ? { id: 42, role: "user" } : null,
    req: {},
    res: {},
  }) as TrpcContext;
const token = "a".repeat(150);
beforeEach(() => {
  vi.unstubAllEnvs();
  mocked.db.mockReset();
});

describe("FCM delivery classification", () => {
  it("distinguishes acceptance from invalid registration", () => {
    expect(
      classifyFcmResponse(200, { name: "projects/test/messages/123" })
    ).toBe("accepted");
    expect(
      classifyFcmResponse(404, {
        error: {
          details: [
            {
              "@type": "type.googleapis.com/google.firebase.fcm.v1.FcmError",
              errorCode: "UNREGISTERED",
            },
          ],
        },
      })
    ).toBe("invalid_token");
  });
  it.each([400, 401, 403, 404, 429, 500, 503])(
    "does not delete tokens on generic HTTP %i",
    status => {
      expect(classifyFcmResponse(status, null)).toBe("retry");
    }
  );
  it("uses a private generic notification with bounded TTL", () => {
    const { message } = pushMessage(token, false, 7);
    expect(message.android.notification.visibility).toBe("PRIVATE");
    expect(message.android.ttl).toBe("300s");
    expect(message.notification.body).toBe(
      "Abra o Plantão Zen para conferir sua caixa de entrada."
    );
    expect(pushMessage(token, true, 8).message.notification.body).toContain(
      "Nenhuma emergência"
    );
  });
});

describe("push authorization and configuration", () => {
  it("rejects anonymous device registration before touching storage", async () => {
    await expect(
      pushRouter.createCaller(context(false)).register({ token })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(mocked.db).not.toHaveBeenCalled();
  });
  it("does not report registration success without credentials", async () => {
    vi.stubEnv("FCM_PROJECT_ID", "");
    await expect(
      pushRouter.createCaller(context(true)).register({ token })
    ).rejects.toMatchObject({ code: "PRECONDITION_FAILED" });
    expect(mocked.db).not.toHaveBeenCalled();
  });
  it("rejects oversized tokens and control characters", () => {
    expect(pushTokenSchema.safeParse("x".repeat(4097)).success).toBe(false);
    expect(
      pushTokenSchema.safeParse("x".repeat(30) + "\nAuthorization: injected")
        .success
    ).toBe(false);
  });
  it("refuses tests without an owned device", async () => {
    vi.stubEnv("FCM_PROJECT_ID", "test");
    vi.stubEnv("FCM_CLIENT_EMAIL", "test@example.com");
    vi.stubEnv("FCM_PRIVATE_KEY", "test");
    const insert = vi.fn();
    const tx = {
      select: () => ({
        from: () => ({ where: () => ({ for: async () => [] }) }),
      }),
      insert,
    };
    mocked.db.mockResolvedValue({
      transaction: (callback: (value: typeof tx) => unknown) => callback(tx),
    });
    await expect(
      pushRouter.createCaller(context(true)).test({ token })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(insert).not.toHaveBeenCalled();
  });
});

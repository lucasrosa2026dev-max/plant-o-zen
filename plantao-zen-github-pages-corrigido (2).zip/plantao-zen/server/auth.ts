import { createHash, randomBytes, randomUUID, scrypt, timingSafeEqual } from "node:crypto";
import { parse } from "cookie";
import { and, eq, gt, lt } from "drizzle-orm";
import type { Express, Request, RequestHandler } from "express";
import { z } from "zod";
import { authCredentials, authSessions, passwordResets, authTotp, users } from "../drizzle/schema";
import { COOKIE_NAME } from "../shared/const";
import { getDb } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { decryptSecret, matchingTotpStep } from "./securityV2";

export const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
export const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");
function derive(password: string, salt: string): Promise<Buffer> {
  return new Promise((resolve, reject) => scrypt(password, salt, 64,
    { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
    (error, key) => error ? reject(error) : resolve(key)));
}
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  return `scrypt:${salt}:${(await derive(password, salt)).toString("hex")}`;
}
export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const [algorithm, salt, key] = encoded.split(":");
  if (algorithm !== "scrypt" || !/^[a-f0-9]{32}$/.test(salt ?? "") || !/^[a-f0-9]{128}$/.test(key ?? "")) return false;
  return timingSafeEqual(await derive(password, salt), Buffer.from(key, "hex"));
}
const dummyHash = `scrypt:${"0".repeat(32)}:${"0".repeat(128)}`;
export function sessionToken(req: Request): string | undefined {
  const token = parse(req.headers.cookie ?? "")[COOKIE_NAME];
  return token && /^[a-f0-9]{64}$/.test(token) ? token : undefined;
}
export async function authenticateRequest(req: Request) {
  const token = sessionToken(req);
  if (!token) return null;
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const [row] = await db.select({ user: users }).from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(and(eq(authSessions.tokenHash, hashToken(token)), gt(authSessions.expiresAt, new Date()))).limit(1);
  return row?.user ?? null;
}
export async function revokeSession(req: Request) {
  const token = sessionToken(req);
  if (!token) return;
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  await db.delete(authSessions).where(eq(authSessions.tokenHash, hashToken(token)));
}

// Browser mutations must originate from this deployment, including login CSRF.
export const sameOriginOnly: RequestHandler = (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) { next(); return; }
  const origin = req.headers.origin;
  const expected = process.env.APP_URL ? new URL(process.env.APP_URL).origin : `${req.protocol}://${req.get("host")}`;
  if (req.headers["sec-fetch-site"] === "cross-site" || origin !== expected) {
    res.status(403).json({ error: "Origem da requisição não permitida." }); return;
  }
  next();
};

export function createLoginLimiter(now = Date.now): RequestHandler {
  const attempts = new Map<string, { count: number; expires: number }>();
  return (req, res, next) => {
    const time = now();
    for (const [key, value] of attempts) if (value.expires <= time) attempts.delete(key);
    const key = req.ip ?? "unknown";
    let entry = attempts.get(key);
    if (!entry) {
      if (attempts.size >= 10000) { res.status(429).json({ error: "Tente novamente mais tarde." }); return; }
      entry = { count: 0, expires: time + 15 * 60 * 1000 }; attempts.set(key, entry);
    }
    if (++entry.count > 20) {
      res.set("Retry-After", String(Math.ceil((entry.expires - time) / 1000)));
      res.status(429).json({ error: "Muitas tentativas. Aguarde 15 minutos." }); return;
    }
    next();
  };
}
export const credentialsSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(12).max(128),
  name: z.string().trim().min(2).max(120).optional(),
  totpCode: z.string().regex(/^\d{6}$/).optional(),
});
export function registerAuthRoutes(app: Express) {
  app.use("/api/auth", createLoginLimiter());
  app.post(["/api/auth/login", "/api/auth/register"], async (req, res) => {
    res.set("Cache-Control", "no-store");
    const input = credentialsSchema.safeParse(req.body);
    const register = req.path.endsWith("/register");
    if (!input.success || (register && !input.data.name)) {
      res.status(400).json({ error: "Informe nome, e-mail válido e senha de 12 a 128 caracteres." }); return;
    }
    const { email, password, name, totpCode } = input.data;
    try {
      const db = await getDb();
      if (!db) { res.status(503).json({ error: "Acesso temporariamente indisponível." }); return; }
      const [credential] = await db.select().from(authCredentials).where(eq(authCredentials.email, email)).limit(1);
      let userId: number;
      if (register) {
        if (credential) { res.status(409).json({ error: "Não foi possível cadastrar este e-mail. Tente entrar ou contate o suporte." }); return; }
        const passwordHash = await hashPassword(password);
        userId = await db.transaction(async tx => {
          const [created] = await tx.insert(users).values({ openId: `local:${randomUUID()}`, name, email, loginMethod: "password" }).$returningId();
          await tx.insert(authCredentials).values({ userId: created.id, email, passwordHash });
          return created.id;
        });
      } else {
        const valid = await verifyPassword(password, credential?.passwordHash ?? dummyHash);
        if (!credential || !valid) { res.status(401).json({ error: "E-mail ou senha incorretos." }); return; }
        userId = credential.userId;
        const [twoFactor] = await db.select().from(authTotp).where(eq(authTotp.userId, userId)).limit(1);
        if (twoFactor?.enabledAt) {
          // Never issue session cookie until the second factor passes.
          if (!totpCode) { res.status(202).json({ requires2fa: true }); return; }
          const step = matchingTotpStep(decryptSecret(twoFactor.secretEncrypted), totpCode, twoFactor.lastUsedStep);
          if (step === null) { res.status(401).json({ error: "Código inválido ou expirado." }); return; }
          // Conditional UPDATE makes replays across concurrent workers fail closed.
          const updated = await db.update(authTotp).set({ lastUsedStep: step })
            .where(and(eq(authTotp.userId, userId), eq(authTotp.lastUsedStep, twoFactor.lastUsedStep)));
          if (!updated[0].affectedRows) { res.status(401).json({ error: "Código já utilizado." }); return; }
        }
      }
      await revokeSession(req);
      const token = randomBytes(32).toString("hex");
      await db.delete(authSessions).where(lt(authSessions.expiresAt, new Date()));
      await db.insert(authSessions).values({ tokenHash: hashToken(token), userId, expiresAt: new Date(Date.now() + SESSION_MS) });
      await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, userId));
      res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: SESSION_MS });
      res.json({ success: true });
    } catch (error) {
      const code = (error as { code?: string; cause?: { code?: string } }).code ?? (error as { cause?: { code?: string } }).cause?.code;
      res.status(code === "ER_DUP_ENTRY" ? 409 : 503).json({ error: "Não foi possível concluir o acesso. Tente novamente ou contate o suporte." });
    }
  });
  // Identical response for existing and unknown accounts; do not disclose email existence.
  app.post("/api/auth/forgot-password", async (req, res) => {
    res.set("Cache-Control", "no-store");
    const parsed = z.object({ email: z.string().trim().toLowerCase().email().max(254) }).safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "E-mail inválido." }); return; }
    try {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const [credential] = await db.select().from(authCredentials).where(eq(authCredentials.email, parsed.data.email)).limit(1);
      if (credential) {
        const apiKey = process.env.RESEND_API_KEY;
        const from = process.env.PASSWORD_RESET_FROM;
        const base = process.env.APP_URL;
        if (!apiKey || !from || !base) throw new Error("Email delivery not configured");
        const token = randomBytes(32).toString("hex");
        const url = new URL("/login", base);
        url.searchParams.set("reset", token);
        await db.delete(passwordResets).where(eq(passwordResets.userId, credential.userId));
        await db.insert(passwordResets).values({ userId: credential.userId, tokenHash: hashToken(token), expiresAt: new Date(Date.now() + 10 * 60_000) });
        const response = await fetch("https://api.resend.com/emails", {
          method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({ from, to: [parsed.data.email], subject: "Recuperação de acesso — Plantão Zen Health",
            text: `Recebemos uma solicitação para redefinir sua senha. Abra o link em até 10 minutos: ${url.toString()}\n\nSe não foi você, ignore esta mensagem.` }),
          signal: AbortSignal.timeout(8000),
        });
        if (!response.ok) throw new Error(`Email delivery error: ${response.status}`);
      }
    } catch (err) {
      // Never log addresses, reset links, tokens or API keys.
      console.error("Password recovery request failed", err instanceof Error ? err.message.replace(/Bearer \S+/g, "[redacted]") : "unknown");
    }
    res.json({ success: true, message: "Se o e-mail estiver cadastrado, você receberá instruções." });
  });
  app.post("/api/auth/reset-password", async (req, res) => {
    res.set("Cache-Control", "no-store");
    const parsed = z.object({ token: z.string().regex(/^[a-f0-9]{64}$/), password: z.string().min(12).max(128) }).safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: "Solicitação inválida." }); return; }
    try {
      const db = await getDb(); if (!db) throw new Error("DB unavailable");
      const hash = hashToken(parsed.data.token);
      const [record] = await db.select().from(passwordResets).where(and(eq(passwordResets.tokenHash, hash), gt(passwordResets.expiresAt, new Date()))).limit(1);
      if (!record) { res.status(400).json({ error: "Link inválido ou expirado." }); return; }
      const passwordHash = await hashPassword(parsed.data.password);
      // Atomically consume token and revoke all sessions. Keep 2FA enabled.
      const result = await db.transaction(async tx => {
        const deleted = await tx.delete(passwordResets).where(eq(passwordResets.tokenHash, hash));
        if (!deleted[0].affectedRows) return false;
        await tx.update(authCredentials).set({ passwordHash }).where(eq(authCredentials.userId, record.userId));
        await tx.delete(authSessions).where(eq(authSessions.userId, record.userId));
        return true;
      });
      if (!result) { res.status(400).json({ error: "Link já utilizado." }); return; }
      res.json({ success: true });
    } catch { res.status(503).json({ error: "Não foi possível redefinir a senha." }); }
  });
}

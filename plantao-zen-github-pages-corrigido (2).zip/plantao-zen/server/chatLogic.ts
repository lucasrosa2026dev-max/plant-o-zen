export type ChatStatus = "pending" | "accepted" | "declined";

export const MAX_CHAT_MESSAGE_LENGTH = 2_000;

export function makeChatPairKey(firstUserId: number, secondUserId: number) {
  if (!Number.isSafeInteger(firstUserId) || firstUserId <= 0)
    throw new Error("ID de usuário inválido.");
  if (!Number.isSafeInteger(secondUserId) || secondUserId <= 0)
    throw new Error("ID de usuário inválido.");
  if (firstUserId === secondUserId)
    throw new Error("Não é possível iniciar uma conversa consigo mesmo.");
  const [lower, upper] = [firstUserId, secondUserId].sort((a, b) => a - b);
  return `${lower}:${upper}`;
}

export function orderChatParticipantIds(...userIds: number[]) {
  return Array.from(new Set(userIds)).sort((a, b) => a - b);
}

export function canSearchChatDirectory(input: {
  discoverable: boolean;
  query: string;
  isSelf: boolean;
  isBlocked: boolean;
}) {
  return (
    input.discoverable &&
    input.query.trim().length >= 2 &&
    !input.isSelf &&
    !input.isBlocked
  );
}

export function canRespondToChatRequest(input: {
  status: ChatStatus;
  actorId: number;
  recipientId: number;
}) {
  return input.status === "pending" && input.actorId === input.recipientId;
}

export function canSendChatMessage(input: {
  status: ChatStatus;
  isParticipant: boolean;
  isBlocked: boolean;
}) {
  return input.status === "accepted" && input.isParticipant && !input.isBlocked;
}

export function normalizeChatMessage(value: string) {
  const message = value.normalize("NFC").trim();
  if (!message) throw new Error("Escreva uma mensagem antes de enviar.");
  if (message.length > MAX_CHAT_MESSAGE_LENGTH)
    throw new Error(
      `A mensagem deve ter no máximo ${MAX_CHAT_MESSAGE_LENGTH} caracteres.`,
    );
  return message;
}

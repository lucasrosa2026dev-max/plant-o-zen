import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ getDb: vi.fn(), send: vi.fn() }));
vi.mock("./db", () => ({ getDb: mocks.getDb }));
vi.mock("./pushTransport", () => ({
  pushConfigured: () => true,
  sendAndroidPush: mocks.send,
}));
import { processPushQueue } from "./push";
function fakeDb({ owned = true, claim = 1, attempts = 0 } = {}) {
  const item = {
    id: 1,
    userId: 42,
    deviceId: 5,
    isTest: 0,
    attempts,
    status: "pending",
    createdAt: new Date(),
  };
  const responses = [
    [item],
    owned ? [{ id: 5, token: "private-token", tokenHash: "hash" }] : [],
    [],
  ];
  const states: Record<string, unknown>[] = [];
  const db = {
    select: () => ({
      from: () => ({ where: () => ({ limit: async () => responses.shift() }) }),
    }),
    update: () => ({
      set: (value: Record<string, unknown>) => {
        states.push(value);
        return { where: async () => [{ affectedRows: claim }] };
      },
    }),
    delete: () => ({ where: async () => [] }),
  };
  mocks.getDb.mockResolvedValue(db);
  return states;
}
beforeEach(() => {
  vi.clearAllMocks();
  mocks.send.mockResolvedValue("accepted");
});
describe("persistent push queue", () => {
  it("does not send an item leased by another worker", async () => {
    fakeDb({ claim: 0 });
    await processPushQueue();
    expect(mocks.send).not.toHaveBeenCalled();
  });
  it("cancels delivery after unlinking or changing the owning account", async () => {
    const states = fakeDb({ owned: false });
    await processPushQueue();
    expect(mocks.send).not.toHaveBeenCalled();
    expect(states.at(-1)?.status).toBe("cancelled");
  });
  it("retries provider failures instead of marking delivery accepted", async () => {
    mocks.send.mockResolvedValue("retry");
    const states = fakeDb();
    await processPushQueue();
    expect(states.at(-1)?.status).toBe("pending");
    expect((states.at(-1)?.availableAt as Date).getTime()).toBeGreaterThan(
      Date.now()
    );
  });
  it("stops after five failed attempts", async () => {
    mocks.send.mockResolvedValue("retry");
    const states = fakeDb({ attempts: 4 });
    await processPushQueue();
    expect(states.at(-1)?.status).toBe("failed");
  });
  it("records provider acceptance separately from device receipt", async () => {
    const states = fakeDb();
    await processPushQueue();
    expect(states.at(-1)?.status).toBe("accepted");
  });
});

// Dependency-free regression checks; run with node server/accountDeletion.security.test.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const db = fs.readFileSync('server/db.ts', 'utf8');
const chat = fs.readFileSync('server/chatDb.ts', 'utf8');
const deletion = db.slice(db.indexOf('export async function deleteUserData('),db.indexOf('export async function listContacts('));
assert.match(deletion,/tx\.delete\(chatMessages\)\.where\(eq\(chatMessages\.senderId, userId\)\)/);
assert.doesNotMatch(deletion,/tx\.delete\(chatConversations\)/);
assert.doesNotMatch(deletion,/tx\.delete\(users\)/);
assert.match(deletion,/loginMethod: "deleted"/);
assert.match(deletion,/await tx\.delete\(authSessions\)/);
assert.match(deletion,/await tx\.delete\(authCredentials\)/);
for (const fn of ['sendChatMessage', 'respondToChatRequest']) {
  const code=chat.slice(chat.indexOf('export async function '+fn+'('));
  assert.match(code,/lockedUsers\.some\(person => person\.loginMethod === "deleted"\)/);
}
console.log('8 verificações estáticas de regressão aprovadas. Testes com MySQL ainda necessários.');

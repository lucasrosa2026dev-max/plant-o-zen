export type ContactsNotificationStatus = "sent" | "partial" | "failed" | "no_contacts";

export function validateEmergencyContactOrder(currentIds: number[], requestedIds: number[]) {
  const requested = new Set(requestedIds);
  const current = new Set(currentIds);
  if (requested.size !== requestedIds.length || requested.size !== current.size || [...requested].some(id => !current.has(id))) {
    throw new Error("A ordem precisa conter uma única vez todos os contatos de emergência da conta.");
  }
  return requestedIds;
}

export function classifyContactDelivery(linkedRecipients: number, deliveredRecipients: number): ContactsNotificationStatus {
  if (linkedRecipients === 0) return "no_contacts";
  if (deliveredRecipients <= 0) return "failed";
  if (deliveredRecipients < linkedRecipients) return "partial";
  return "sent";
}

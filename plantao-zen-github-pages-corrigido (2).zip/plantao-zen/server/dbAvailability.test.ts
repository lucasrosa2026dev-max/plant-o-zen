import { afterEach, expect, it, vi } from "vitest";
import {
  getProfile,
  listContacts,
  listAnalyses,
  getActiveEmergency,
  listInboxNotifications,
} from "./db";
afterEach(() => vi.unstubAllEnvs());
it("não apresenta ausência de registros quando DATABASE_URL não está configurada", async () => {
  vi.stubEnv("DATABASE_URL", "");
  for (const query of [
    getProfile,
    listContacts,
    listAnalyses,
    getActiveEmergency,
    listInboxNotifications,
  ]) {
    await expect(query(7)).rejects.toThrow("indisponível");
  }
});

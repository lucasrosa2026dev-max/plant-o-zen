import { describe, expect, it } from "vitest";
import { classifyContactDelivery, validateEmergencyContactOrder } from "./emergencyLogic";

describe("emergency contact order", () => {
  it("accepts a complete permutation of the user's emergency contacts", () => {
    expect(validateEmergencyContactOrder([8, 3, 5], [5, 8, 3])).toEqual([5, 8, 3]);
  });
  it("rejects duplicate, omitted, and foreign contact IDs", () => {
    expect(() => validateEmergencyContactOrder([8, 3], [8, 8])).toThrow();
    expect(() => validateEmergencyContactOrder([8, 3], [8])).toThrow();
    expect(() => validateEmergencyContactOrder([8, 3], [8, 99])).toThrow();
  });
});

describe("notification delivery status", () => {
  it("distinguishes no linked recipients, total failure, partial and complete delivery", () => {
    expect(classifyContactDelivery(0, 0)).toBe("no_contacts");
    expect(classifyContactDelivery(2, 0)).toBe("failed");
    expect(classifyContactDelivery(2, 1)).toBe("partial");
    expect(classifyContactDelivery(2, 2)).toBe("sent");
  });
});

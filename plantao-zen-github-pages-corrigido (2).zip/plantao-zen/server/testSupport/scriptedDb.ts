import { vi } from "vitest";
import type { SQL } from "drizzle-orm";
export type ReadStep = {
  rows: unknown[];
  inspect?: (where: SQL | undefined, table: unknown) => void;
};
/** Scripted repository boundary. Does not execute SQL or prove rollback/locking semantics. */
export function scriptedDb(steps: ReadStep[]) {
  const reads = [...steps];
  const writes: Array<{
    kind: string;
    table: unknown;
    values: Record<string, unknown>;
    where?: SQL;
  }> = [];
  const base = {
    select: vi.fn(() => {
      let where: SQL | undefined;
      let table: unknown;
      const query = {
        from(value: unknown) {
          table = value;
          return query;
        },
        where(value: SQL) {
          where = value;
          return query;
        },
        innerJoin() {
          return query;
        },
        leftJoin() {
          return query;
        },
        limit() {
          return query;
        },
        orderBy() {
          return query;
        },
        for() {
          return query;
        },
        then(
          resolve: (rows: unknown[]) => unknown,
          reject: (err: unknown) => unknown
        ) {
          return Promise.resolve()
            .then(() => {
              const step = reads.shift();
              if (!step) throw new Error("Unexpected database read");
              step.inspect?.(where, table);
              return step.rows;
            })
            .then(resolve, reject);
        },
      };
      return query;
    }),
    insert: vi.fn((table: unknown) => ({
      values(values: Record<string, unknown>) {
        writes.push({ kind: "insert", table, values });
        return Object.assign(Promise.resolve([{ insertId: 42 }]), {
          $returningId: async () => [{ id: 42 }],
        });
      },
    })),
    update: vi.fn((table: unknown) => ({
      set: (values: Record<string, unknown>) => ({
        where: async (where: SQL) => {
          writes.push({ kind: "update", table, values, where });
          return [{ affectedRows: 1 }];
        },
      }),
    })),
    delete: vi.fn((table: unknown) => ({
      where: async (where: SQL) => {
        writes.push({ kind: "delete", table, values: {}, where });
        return [{ affectedRows: 1 }];
      },
    })),
  };
  const db = {
    ...base,
    transaction: vi.fn(
      async <T>(fn: (tx: typeof base) => Promise<T>): Promise<T> => fn(base)
    ),
  };
  return { db, writes, remaining: () => reads.length };
}

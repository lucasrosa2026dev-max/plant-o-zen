import { startPushWorker } from "../push";
import "dotenv/config";
import { sql } from "drizzle-orm";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerAuthRoutes, sameOriginOnly, createLoginLimiter } from "../auth";
import { appRouter } from "../routers";
import { registerWatchRoutes } from "../watch";
import { getDb } from "../db";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  if (process.env.NODE_ENV === "production") {
    if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL é obrigatória.");
    if (!process.env.APP_URL || new URL(process.env.APP_URL).protocol !== "https:") throw new Error("APP_URL deve ser a origem HTTPS pública da aplicação.");
  }
  startPushWorker();
  const app = express();
  const proxyHops = Number(process.env.TRUST_PROXY_HOPS ?? "0");
  if (!Number.isInteger(proxyHops) || proxyHops < 0 || proxyHops > 5) throw new Error("TRUST_PROXY_HOPS inválido.");
  if (proxyHops) app.set("trust proxy", proxyHops);
  const server = createServer(app);
  app.disable("x-powered-by");
  app.use((_req, res, next) => {
    res.set({
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "X-Frame-Options": "DENY",
      "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
      "Cross-Origin-Opener-Policy": "same-origin",
      "X-Permitted-Cross-Domain-Policies": "none",
    });
    if (process.env.NODE_ENV === "production") {
      res.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
      res.set("Content-Security-Policy", "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' https:; upgrade-insecure-requests");
    }
    next();
  });
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "64kb" }));
  app.use(express.urlencoded({ limit: "64kb", extended: true }));
  app.get("/api/health", async (_req, res) => {
    try {
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.execute(sql`select 1`);
      res.json({ status: "ok", dependencies: { database: "ok" } });
    } catch {
      res.status(503).json({ status: "degraded", dependencies: { database: "unavailable" } });
    }
  });
  app.use("/api", (_req, res, next) => { res.set("Cache-Control", "no-store"); next(); });
  // O dispositivo utiliza Bearer, nunca cookies de navegador. Registrar antes da verificação CSRF.
  registerWatchRoutes(app, appRouter);
  app.use("/api", sameOriginOnly);
  registerAuthRoutes(app);
  // Rate limit password-confirmed privacy actions (per server instance).
  const privacyLimiter = createLoginLimiter();
  app.use("/api/trpc", (req, res, next) => {
    if (req.method === "POST" && /^\/(?:privacy\.(?:exportData|deleteAccount)|security\.(?:beginTwoFactor|enableTwoFactor|disableTwoFactor|revokeOtherSessions))(?:\b|,|$)/.test(req.path)) {
      return privacyLimiter(req, res, next);
    }
    next();
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });

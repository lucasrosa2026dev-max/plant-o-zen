import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  intersectsLocalDay,
  localDateKey,
  shiftConflicts,
} from "../shared/workforce";
import { workforceRouter } from "./workforce";
import { getDb } from "./db";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({ getDb: vi.fn() }));
const interval = (
  start: string,
  end: string,
  professionalName = "Ana Silva"
) => ({ professionalName, startsAt: new Date(start), endsAt: new Date(end) });
const base = interval("2026-10-11T07:00:00-03:00", "2026-10-11T19:00:00-03:00");
const caller = (user = { id: 7, role: "user" } as TrpcContext["user"]) =>
  workforceRouter.createCaller({ user } as TrpcContext);

beforeEach(() => vi.resetAllMocks());
describe("regras de escalas", () => {
  it("detecta sobreposição normalizando caixa e espaços", () => {
    expect(
      shiftConflicts([base], { ...base, professionalName: " ANA   SILVA " })
    ).toEqual(["Sobreposição com outro plantão"]);
  });
  it("permite profissionais distintos", () => {
    expect(
      shiftConflicts([base], { ...base, professionalName: "Bia" })
    ).toEqual([]);
  });
  it("valida descanso nos dois sentidos, incluindo o limite exato", () => {
    const next = interval(
      "2026-10-12T06:00:00-03:00",
      "2026-10-12T12:00:00-03:00"
    );
    expect(shiftConflicts([base], next)).toEqual([]);
    expect(shiftConflicts([next], base)).toEqual([]);
    expect(
      shiftConflicts([base], {
        ...next,
        startsAt: new Date("2026-10-12T05:59:00-03:00"),
      })
    ).toHaveLength(1);
    expect(
      shiftConflicts([next], {
        ...base,
        endsAt: new Date("2026-10-11T19:01:00-03:00"),
      })
    ).toHaveLength(1);
  });
  it("usa o dia local e não inclui plantão que terminou à meia-noite", () => {
    const start = new Date(2026, 9, 11, 23, 30);
    const end = new Date(2026, 9, 12, 0, 0);
    expect(localDateKey(start)).toBe("2026-10-11");
    expect(intersectsLocalDay(start, end, "2026-10-11")).toBe(true);
    expect(intersectsLocalDay(start, end, "2026-10-12")).toBe(false);
    expect(
      intersectsLocalDay(start, new Date(2026, 9, 12, 7), "2026-10-12")
    ).toBe(true);
  });
});

describe("router de escalas", () => {
  it("recusa acesso anônimo antes de consultar o banco", async () => {
    await expect(caller(null).list()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
    expect(getDb).not.toHaveBeenCalled();
  });
  it("não transforma banco indisponível em lista vazia", async () => {
    vi.mocked(getDb).mockResolvedValue(null);
    await expect(caller().list()).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
    });
  });
  it("recusa intervalo inválido antes de gravar", async () => {
    await expect(
      caller().create({ ...base, title: "UTI", endsAt: base.startsAt })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(getDb).not.toHaveBeenCalled();
  });
  it("recusa checkout sem check-in dentro da transação", async () => {
    const lock = vi
      .fn()
      .mockResolvedValue([{ ...base, status: "planned", checkInAt: null }]);
    const tx = {
      select: () => ({ from: () => ({ where: () => ({ for: lock }) }) }),
      update: vi.fn(),
    };
    const transaction = vi.fn(async fn => fn(tx));
    vi.mocked(getDb).mockResolvedValue({ transaction } as never);
    await expect(
      caller().attendance({ id: 1, action: "out" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(lock).toHaveBeenCalledWith("update");
    expect(tx.update).not.toHaveBeenCalled();
  });
  it("propaga falha da auditoria para abortar a transação de criação", async () => {
    const ownerLock = vi.fn().mockResolvedValue([{ id: 7 }]);
    const where = vi
      .fn()
      .mockReturnValueOnce({ for: ownerLock })
      .mockResolvedValueOnce([]);
    const values = vi
      .fn()
      .mockResolvedValueOnce([{ insertId: 42 }])
      .mockRejectedValueOnce(new Error("audit unavailable"));
    const tx = {
      select: () => ({ from: () => ({ where }) }),
      insert: () => ({ values }),
    };
    const transaction = vi.fn(async fn => fn(tx));
    vi.mocked(getDb).mockResolvedValue({ transaction } as never);
    await expect(caller().create({ ...base, title: "UTI" })).rejects.toThrow(
      "audit unavailable"
    );
    expect(ownerLock).toHaveBeenCalledWith("update");
    expect(values.mock.calls[1][0]).toMatchObject({
      ownerId: 7,
      shiftId: 42,
      action: "shift.created",
    });
  });
});

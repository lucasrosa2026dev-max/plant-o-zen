import { eq, or, and, inArray } from "drizzle-orm";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { authCredentials, authTotp, users, profiles, contacts, analyses, dailyCheckins, safetyPlans, emergencyEvents, notificationPreferences, smartwatchSettings, inboxNotifications, chatSettings, chatConversations, chatMessages, chatBlocks, chatReports, workShifts, workAudit, watchDevices, watchPairings } from "../drizzle/schema";
import { getDb, deleteUserData } from "./db";
import { verifyPassword } from "./auth";
import { decryptSecret, matchingTotpStep } from "./securityV2";
import { COOKIE_NAME } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { protectedProcedure, router } from "./_core/trpc";

async function verifySensitiveAction(userId: number, password: string, totpCode?: string) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE" });
  const [credential] = await db.select({ passwordHash: authCredentials.passwordHash }).from(authCredentials).where(eq(authCredentials.userId, userId)).limit(1);
  if (!credential || !(await verifyPassword(password, credential.passwordHash))) throw new TRPCError({ code: "FORBIDDEN", message: "Senha incorreta." });
  // When MFA is enabled, a password alone is not sufficient to export health
  // records or permanently erase the account. Replay is prevented atomically.
  const [factor] = await db.select().from(authTotp).where(eq(authTotp.userId, userId)).limit(1);
  if (factor?.enabledAt) {
    if (!totpCode) throw new TRPCError({ code: "FORBIDDEN", message: "Informe o código do autenticador." });
    const step = matchingTotpStep(decryptSecret(factor.secretEncrypted), totpCode, factor.lastUsedStep);
    if (step === null) throw new TRPCError({ code: "FORBIDDEN", message: "Código inválido ou já utilizado." });
    const updated = await db.update(authTotp).set({ lastUsedStep: step })
      .where(and(eq(authTotp.userId, userId), eq(authTotp.lastUsedStep, factor.lastUsedStep)));
    if (!updated[0].affectedRows) throw new TRPCError({ code: "CONFLICT", message: "Código já utilizado." });
  }
  return db;
}
const confirmSchema = z.object({ password: z.string().min(1).max(128), totpCode: z.string().regex(/^\d{6}$/).optional() });

export const privacyRouter = router({
  exportData: protectedProcedure.input(confirmSchema).mutation(async ({ ctx, input }) => {
    const db = await verifySensitiveAction(ctx.user.id, input.password, input.totpCode);
    const id = ctx.user.id;
    const conversations = await db.select().from(chatConversations).where(or(eq(chatConversations.participantAId, id), eq(chatConversations.participantBId, id)));
    const conversationIds = new Set(conversations.map(c => c.id));
    const [account] = await db.select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt, lastSignedIn: users.lastSignedIn }).from(users).where(eq(users.id, id)).limit(1);
    // Never export session tokens, password hashes or push-device credentials.
    return {
      exportedAt: new Date().toISOString(), formatVersion: 1, account,
      profile: await db.select().from(profiles).where(eq(profiles.userId, id)), contacts: await db.select().from(contacts).where(eq(contacts.userId, id)), analyses: await db.select().from(analyses).where(eq(analyses.userId, id)),
      checkins: await db.select().from(dailyCheckins).where(eq(dailyCheckins.userId, id)), safetyPlans: await db.select().from(safetyPlans).where(eq(safetyPlans.userId, id)), emergencies: await db.select().from(emergencyEvents).where(eq(emergencyEvents.userId, id)),
      preferences: await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, id)), smartwatch: await db.select().from(smartwatchSettings).where(eq(smartwatchSettings.userId, id)), notifications: await db.select().from(inboxNotifications).where(eq(inboxNotifications.userId, id)),
      chatSettings: await db.select().from(chatSettings).where(eq(chatSettings.userId, id)), conversations,
      messages: conversationIds.size ? await db.select().from(chatMessages).where(and(inArray(chatMessages.conversationId, [...conversationIds]), eq(chatMessages.senderId, id))) : [],
      chatBlocks: (await db.select().from(chatBlocks).where(eq(chatBlocks.blockerId, id))).map(b => ({ blockedUserId: b.blockedUserId, createdAt: b.createdAt })),
      reportsFiled: (await db.select().from(chatReports).where(eq(chatReports.reporterId, id))).map(r => ({ id: r.id, reason: r.reason, createdAt: r.createdAt, status: r.status })),
      shifts: await db.select().from(workShifts).where(eq(workShifts.ownerId, id)),
      workAudit: await db.select().from(workAudit).where(eq(workAudit.ownerId, id)),
      // Somente metadados, nunca hashes ou códigos de pareamento.
      watchDevices: await db.select({ label: watchDevices.label, createdAt: watchDevices.createdAt, lastSeenAt: watchDevices.lastSeenAt, revokedAt: watchDevices.revokedAt }).from(watchDevices).where(eq(watchDevices.userId, id)),
    };
  }),
  deleteAccount: protectedProcedure.input(confirmSchema.extend({ confirmation: z.literal("EXCLUIR MINHA CONTA") })).mutation(async ({ ctx, input }) => {
    await verifySensitiveAction(ctx.user.id, input.password, input.totpCode);
    // Workforce rows do not have cascade FKs; remove them in the same user-data transaction.
    await deleteUserData(ctx.user.id);
    ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
    return { success: true } as const;
  }),
});

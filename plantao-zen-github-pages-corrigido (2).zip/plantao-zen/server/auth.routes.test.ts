import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import express from "express";
import { createServer, type Server } from "node:http";
import { getDb } from "./db";
import {
  hashPassword,
  hashToken,
  registerAuthRoutes,
  sameOriginOnly,
  verifyPassword,
} from "./auth";
import { authCredentials, authSessions, users } from "../drizzle/schema";
import { scriptedDb } from "./testSupport/scriptedDb";
vi.mock("./db", () => ({ getDb: vi.fn() }));
let server: Server;
let url: string;
beforeEach(async () => {
  vi.stubEnv("NODE_ENV", "development");
  vi.stubEnv("APP_URL", "https://plantao.test");
  const app = express();
  app.use(express.json(), sameOriginOnly);
  registerAuthRoutes(app);
  server = createServer(app);
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  url = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
});
afterEach(async () => {
  await new Promise<void>((resolve, reject) =>
    server.close(e => (e ? reject(e) : resolve()))
  );
  vi.unstubAllEnvs();
  vi.resetAllMocks();
});
const credentials = {
  email: " TEST@example.com ",
  password: "test-password-123",
  name: "Conta de teste",
};
const post = (action: string, body = credentials) =>
  fetch(`${url}/api/auth/${action}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Origin: "https://plantao.test",
    },
    body: JSON.stringify(body),
  });
describe("HTTP authentication with scripted persistence", () => {
  it("registers with a hashed password and stores only the session token hash", async () => {
    const h = scriptedDb([{ rows: [] }]);
    vi.mocked(getDb).mockResolvedValue(h.db as never);
    const res = await post("register");
    expect(res.status).toBe(200);
    const credential = h.writes.find(w => w.table === authCredentials)!;
    expect(credential.values.email).toBe("test@example.com");
    expect(
      await verifyPassword(
        credentials.password,
        String(credential.values.passwordHash)
      )
    ).toBe(true);
    const token = res.headers.get("set-cookie")!.split(";")[0].split("=")[1];
    expect(
      h.writes.find(w => w.table === authSessions && w.kind === "insert")
        ?.values.tokenHash
    ).toBe(hashToken(token));
    expect(h.writes.some(w => w.table === users && w.kind === "insert")).toBe(
      true
    );
    expect(h.remaining()).toBe(0);
  });
  it("rejects duplicate registration without issuing a session", async () => {
    const h = scriptedDb([{ rows: [{ userId: 42 }] }]);
    vi.mocked(getDb).mockResolvedValue(h.db as never);
    const res = await post("register");
    expect(res.status).toBe(409);
    expect(res.headers.get("set-cookie")).toBeNull();
    expect(h.writes).toHaveLength(0);
  });
  it("accepts valid credentials and rejects incorrect passwords", async () => {
    const passwordHash = await hashPassword(credentials.password);
    const h = scriptedDb([
      { rows: [{ userId: 42, passwordHash }] },
      { rows: [] },
    ]);
    vi.mocked(getDb).mockResolvedValue(h.db as never);
    expect((await post("login")).status).toBe(200);
    const denied = scriptedDb([{ rows: [{ userId: 42, passwordHash }] }]);
    vi.mocked(getDb).mockResolvedValue(denied.db as never);
    const res = await post("login", {
      ...credentials,
      password: "wrong-password-123",
    });
    expect(res.status).toBe(401);
    expect(res.headers.get("set-cookie")).toBeNull();
    expect(denied.writes).toHaveLength(0);
  });
  it("does not issue a cookie or write a session before the second factor", async () => {
    const h = scriptedDb([
      {
        rows: [
          {
            userId: 42,
            passwordHash: await hashPassword(credentials.password),
          },
        ],
      },
      { rows: [{ enabledAt: new Date() }] },
    ]);
    vi.mocked(getDb).mockResolvedValue(h.db as never);
    const res = await post("login");
    expect(res.status).toBe(202);
    expect(await res.json()).toEqual({ requires2fa: true });
    expect(res.headers.get("set-cookie")).toBeNull();
    expect(h.writes).toHaveLength(0);
  });
  it("returns a service error without a cookie when persistence fails", async () => {
    vi.mocked(getDb).mockRejectedValue(new Error("offline"));
    const res = await post("register");
    expect(res.status).toBe(503);
    expect(res.headers.get("set-cookie")).toBeNull();
  });
});

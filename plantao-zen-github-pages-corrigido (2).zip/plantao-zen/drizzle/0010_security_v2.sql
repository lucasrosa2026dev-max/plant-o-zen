CREATE TABLE `password_resets` (`tokenHash` varchar(64) NOT NULL, `userId` int NOT NULL, `expiresAt` timestamp NOT NULL, `attempts` int NOT NULL DEFAULT 0, CONSTRAINT `password_resets_tokenHash` PRIMARY KEY(`tokenHash`));
--> statement-breakpoint
ALTER TABLE `password_resets` ADD CONSTRAINT `password_resets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX `password_resets_user_idx` ON `password_resets` (`userId`);
--> statement-breakpoint
CREATE TABLE `auth_totp` (`userId` int NOT NULL, `secretEncrypted` text NOT NULL, `enabledAt` timestamp NULL, `lastUsedStep` int NOT NULL DEFAULT 0, CONSTRAINT `auth_totp_userId` PRIMARY KEY(`userId`));
--> statement-breakpoint
ALTER TABLE `auth_totp` ADD CONSTRAINT `auth_totp_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;

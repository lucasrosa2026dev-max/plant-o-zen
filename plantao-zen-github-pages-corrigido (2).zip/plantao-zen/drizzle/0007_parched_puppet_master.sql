CREATE TABLE `work_audit` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`shift_id` int,
	`action` varchar(80) NOT NULL,
	`details` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_audit_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `work_shifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`professional_name` varchar(120) NOT NULL,
	`title` varchar(160) NOT NULL,
	`starts_at` timestamp NOT NULL,
	`ends_at` timestamp NOT NULL,
	`hourly_cents` int NOT NULL,
	`shift_status` enum('planned','confirmed','completed','cancelled') NOT NULL DEFAULT 'planned',
	`check_in_at` timestamp,
	`check_out_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_shifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `work_audit_owner_idx` ON `work_audit` (`owner_id`);--> statement-breakpoint
CREATE INDEX `work_shifts_owner_idx` ON `work_shifts` (`owner_id`);
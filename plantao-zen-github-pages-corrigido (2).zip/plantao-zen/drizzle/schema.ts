import {
  int,
  index,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const profiles = mysqlTable("profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  fullName: varchar("fullName", { length: 120 }),
  phone: varchar("phone", { length: 32 }),
  birthDate: varchar("birthDate", { length: 10 }),
  city: varchar("city", { length: 100 }),
  careNotes: text("careNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const contacts = mysqlTable(
  "contacts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    email: varchar("email", { length: 320 }),
    relationship: varchar("relationship", { length: 80 }),
    isEmergency: int("isEmergency").default(0).notNull(),
    emergencyPriority: int("emergencyPriority").default(0).notNull(),
    linkedOpenId: varchar("linkedOpenId", { length: 64 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    userIdx: uniqueIndex("contacts_user_id_id_idx").on(table.userId, table.id),
  }),
);

export const analyses = mysqlTable("analyses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  result: varchar("result", { length: 80 }).notNull(),
  details: text("details").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const dailyCheckins = mysqlTable("daily_checkins", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  mood: varchar("mood", { length: 80 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const safetyPlans = mysqlTable("safety_plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  safeLocation: varchar("safeLocation", { length: 240 }),
  medications: text("medications"),
  allergies: text("allergies"),
  priorityContacts: text("priorityContacts"),
  instructions: text("instructions"),
  localServices: text("localServices"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const emergencyEvents = mysqlTable("emergency_events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  activeKey: varchar("activeKey", { length: 64 }).unique(),
  status: mysqlEnum("status", ["active", "cancelled", "resolved"]).default("active").notNull(),
  message: varchar("message", { length: 240 }),
  webNotificationStatus: mysqlEnum("webNotificationStatus", ["not_attempted", "sent", "failed", "unsupported"]).default("not_attempted").notNull(),
  notificationsSent: int("notificationsSent").default(0).notNull(),
  contactsNotificationStatus: mysqlEnum("contactsNotificationStatus", ["not_attempted", "sent", "partial", "failed", "no_contacts"]).default("not_attempted").notNull(),
  callStatus: mysqlEnum("callStatus", ["not_attempted", "initiated", "not_completed"]).default("not_attempted").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  cancelledAt: timestamp("cancelledAt"),
});

export const notificationPreferences = mysqlTable("notification_preferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  notificationsEnabled: int("notificationsEnabled").default(1).notNull(),
  soundEnabled: int("soundEnabled").default(1).notNull(),
  smartwatchEnabled: int("smartwatchEnabled").default(1).notNull(),
  backgroundEnabled: int("backgroundEnabled").default(1).notNull(),
  callConfirmationRequired: int("callConfirmationRequired").default(1).notNull(),
  theme: mysqlEnum("theme", ["light", "dark"]).default("light").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const smartwatchSettings = mysqlTable("smartwatch_settings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  platform: varchar("platform", { length: 80 }),
  pwaInstalled: int("pwaInstalled").default(0).notNull(),
  supportsNotifications: int("supportsNotifications").default(0).notNull(),
  supportsActions: int("supportsActions").default(0).notNull(),
  notificationPermission: varchar("notificationPermission", { length: 32 }).default("default").notNull(),
  smartwatchMirroring: int("smartwatchMirroring").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const inboxNotifications = mysqlTable("inbox_notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  relatedEmergencyId: int("relatedEmergencyId"),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  body: text("body").notNull(),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Profile = typeof profiles.$inferSelect;
export type Contact = typeof contacts.$inferSelect;
export type Analysis = typeof analyses.$inferSelect;
export type DailyCheckin = typeof dailyCheckins.$inferSelect;
export type SafetyPlan = typeof safetyPlans.$inferSelect;
export type EmergencyEvent = typeof emergencyEvents.$inferSelect;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type SmartwatchSettings = typeof smartwatchSettings.$inferSelect;
export type InboxNotification = typeof inboxNotifications.$inferSelect;


export const chatSettings = mysqlTable("chat_settings", {
  userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  publicChatId: varchar("publicChatId", { length: 32 }).notNull().unique(),
  discoverable: int("discoverable").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const chatConversations = mysqlTable(
  "chat_conversations",
  {
    id: int("id").autoincrement().primaryKey(),
    pairKey: varchar("pairKey", { length: 24 }).notNull().unique(),
    participantAId: int("participantAId").notNull().references(() => users.id, { onDelete: "cascade" }),
    participantBId: int("participantBId").notNull().references(() => users.id, { onDelete: "cascade" }),
    requestedById: int("requestedById").notNull().references(() => users.id, { onDelete: "cascade" }),
    status: mysqlEnum("status", ["pending", "accepted", "declined"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  },
  table => ({
    participantAIdx: index("chat_conversations_participant_a_idx").on(table.participantAId, table.status),
    participantBIdx: index("chat_conversations_participant_b_idx").on(table.participantBId, table.status),
    requesterIdx: index("chat_conversations_requester_idx").on(table.requestedById, table.createdAt),
  }),
);

export const chatMessages = mysqlTable(
  "chat_messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull().references(() => chatConversations.id, { onDelete: "cascade" }),
    senderId: int("senderId").notNull().references(() => users.id, { onDelete: "cascade" }),
    body: varchar("body", { length: 2000 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    readAt: timestamp("readAt"),
  },
  table => ({
    conversationIdx: index("chat_messages_conversation_idx").on(table.conversationId, table.id),
    senderIdx: index("chat_messages_sender_idx").on(table.senderId, table.createdAt),
  }),
);

export const chatBlocks = mysqlTable(
  "chat_blocks",
  {
    id: int("id").autoincrement().primaryKey(),
    blockerId: int("blockerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    blockedUserId: int("blockedUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    pairIdx: uniqueIndex("chat_blocks_pair_idx").on(table.blockerId, table.blockedUserId),
    blockedIdx: index("chat_blocks_blocked_idx").on(table.blockedUserId, table.blockerId),
  }),
);

export const chatReports = mysqlTable(
  "chat_reports",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull().references(() => chatConversations.id, { onDelete: "cascade" }),
    messageId: int("messageId").references(() => chatMessages.id, { onDelete: "set null" }),
    reporterId: int("reporterId").notNull().references(() => users.id, { onDelete: "cascade" }),
    reportedUserId: int("reportedUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    reason: mysqlEnum("reason", ["harassment", "spam", "safety", "other"]).notNull(),
    details: varchar("details", { length: 500 }),
    status: mysqlEnum("status", ["open", "reviewed", "actioned"]).default("open").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    reviewedById: int("reviewedById").references(() => users.id, { onDelete: "set null" }),
    reviewedAt: timestamp("reviewedAt"),
  },
  table => ({
    statusIdx: index("chat_reports_status_idx").on(table.status, table.createdAt),
    conversationIdx: index("chat_reports_conversation_idx").on(table.conversationId),
  }),
);

export type ChatSettings = typeof chatSettings.$inferSelect;
export type ChatConversation = typeof chatConversations.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type ChatBlock = typeof chatBlocks.$inferSelect;
export type ChatReport = typeof chatReports.$inferSelect;


// Gestão de plantões: dados separados por proprietário, sem alterar tabelas de segurança.
export const workShifts = mysqlTable("work_shifts", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("owner_id").notNull(),
  professionalName: varchar("professional_name", { length: 120 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  startsAt: timestamp("starts_at").notNull(),
  endsAt: timestamp("ends_at").notNull(),
  hourlyCents: int("hourly_cents").notNull(),
  status: mysqlEnum("shift_status", ["planned", "confirmed", "completed", "cancelled"]).default("planned").notNull(),
  checkInAt: timestamp("check_in_at"),
  checkOutAt: timestamp("check_out_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, t => ({ ownerIdx: index("work_shifts_owner_idx").on(t.ownerId) }));

export const workAudit = mysqlTable("work_audit", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("owner_id").notNull(),
  shiftId: int("shift_id"),
  action: varchar("action", { length: 80 }).notNull(),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, t => ({ ownerIdx: index("work_audit_owner_idx").on(t.ownerId) }));

export const pushDevices = mysqlTable("pushDevices", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull(),
  token: text("token").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
}, table => [uniqueIndex("push_token_hash_unique").on(table.tokenHash), index("push_user_idx").on(table.userId)]);

export const pushQueue = mysqlTable("pushQueue", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  deviceId: int("deviceId").notNull(),
  isTest: int("isTest").default(0).notNull(),
  attempts: int("attempts").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "failed", "cancelled"]).default("pending").notNull(),
  availableAt: timestamp("availableAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("push_due_idx").on(table.status, table.availableAt)]);

export const authCredentials = mysqlTable("auth_credentials", {
  userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  email: varchar("email", { length: 254 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 256 }).notNull(),
});
export const authSessions = mysqlTable("auth_sessions", {
  tokenHash: varchar("tokenHash", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expiresAt").notNull(),
}, table => ({ userIdx: index("auth_sessions_user_idx").on(table.userId), expiryIdx: index("auth_sessions_expiry_idx").on(table.expiresAt) }));


// Tokens de recuperação: apenas hash armazenado; uso único e prazo curto.
export const passwordResets = mysqlTable("password_resets", {
  tokenHash: varchar("tokenHash", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expiresAt").notNull(),
  attempts: int("attempts").default(0).notNull(),
}, table => ({ userIdx: index("password_resets_user_idx").on(table.userId) }));

// Segredo TOTP é cifrado com chave externa ao banco.
export const authTotp = mysqlTable("auth_totp", {
  userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  secretEncrypted: text("secretEncrypted").notNull(),
  enabledAt: timestamp("enabledAt"),
  lastUsedStep: int("lastUsedStep").default(0).notNull(),
});

// Credenciais independentes e revogáveis para relógios. Nunca salvar token em texto puro.
export const watchPairings = mysqlTable("watch_pairings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  codeHash: varchar("code_hash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const watchDevices = mysqlTable("watch_devices", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
  label: varchar("label", { length: 80 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  revokedAt: timestamp("revoked_at"),
  lastSeenAt: timestamp("last_seen_at"),
}, t => ({ ownerIdx: index("watch_devices_owner_idx").on(t.userId) }));

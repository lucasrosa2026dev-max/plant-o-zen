CREATE TABLE `auth_credentials` (
	`userId` int NOT NULL,
	`email` varchar(254) NOT NULL,
	`passwordHash` varchar(256) NOT NULL,
	CONSTRAINT `auth_credentials_userId` PRIMARY KEY(`userId`),
	CONSTRAINT `auth_credentials_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `auth_sessions` (
	`tokenHash` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`expiresAt` timestamp NOT NULL,
	CONSTRAINT `auth_sessions_tokenHash` PRIMARY KEY(`tokenHash`)
);
--> statement-breakpoint
ALTER TABLE `auth_credentials` ADD CONSTRAINT `auth_credentials_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auth_sessions` ADD CONSTRAINT `auth_sessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `auth_sessions_user_idx` ON `auth_sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `auth_sessions_expiry_idx` ON `auth_sessions` (`expiresAt`);
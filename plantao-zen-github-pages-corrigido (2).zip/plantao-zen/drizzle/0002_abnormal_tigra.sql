ALTER TABLE `emergency_events` ADD `activeKey` varchar(64);--> statement-breakpoint
ALTER TABLE `emergency_events` ADD `webNotificationStatus` enum('not_attempted','sent','failed','unsupported') DEFAULT 'not_attempted' NOT NULL;--> statement-breakpoint
ALTER TABLE `emergency_events` ADD CONSTRAINT `emergency_events_activeKey_unique` UNIQUE(`activeKey`);
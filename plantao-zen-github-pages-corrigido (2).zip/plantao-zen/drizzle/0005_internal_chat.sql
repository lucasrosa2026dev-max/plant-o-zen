CREATE TABLE `chat_blocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`blockerId` int NOT NULL,
	`blockedUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_blocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `chat_blocks_pair_idx` UNIQUE(`blockerId`,`blockedUserId`)
);
--> statement-breakpoint
CREATE TABLE `chat_conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`pairKey` varchar(24) NOT NULL,
	`participantAId` int NOT NULL,
	`participantBId` int NOT NULL,
	`requestedById` int NOT NULL,
	`status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastMessageAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_conversations_id` PRIMARY KEY(`id`),
	CONSTRAINT `chat_conversations_pairKey_unique` UNIQUE(`pairKey`)
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`senderId` int NOT NULL,
	`body` varchar(2000) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`readAt` timestamp,
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`messageId` int,
	`reporterId` int NOT NULL,
	`reportedUserId` int NOT NULL,
	`reason` enum('harassment','spam','safety','other') NOT NULL,
	`details` varchar(500),
	`status` enum('open','reviewed','actioned') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedById` int,
	`reviewedAt` timestamp,
	CONSTRAINT `chat_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_settings` (
	`userId` int NOT NULL,
	`publicChatId` varchar(32) NOT NULL,
	`discoverable` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chat_settings_userId` PRIMARY KEY(`userId`),
	CONSTRAINT `chat_settings_publicChatId_unique` UNIQUE(`publicChatId`)
);
--> statement-breakpoint
CREATE INDEX `chat_blocks_blocked_idx` ON `chat_blocks` (`blockedUserId`,`blockerId`);--> statement-breakpoint
CREATE INDEX `chat_conversations_participant_a_idx` ON `chat_conversations` (`participantAId`,`status`);--> statement-breakpoint
CREATE INDEX `chat_conversations_participant_b_idx` ON `chat_conversations` (`participantBId`,`status`);--> statement-breakpoint
CREATE INDEX `chat_conversations_requester_idx` ON `chat_conversations` (`requestedById`,`createdAt`);--> statement-breakpoint
CREATE INDEX `chat_messages_conversation_idx` ON `chat_messages` (`conversationId`,`id`);--> statement-breakpoint
CREATE INDEX `chat_messages_sender_idx` ON `chat_messages` (`senderId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `chat_reports_status_idx` ON `chat_reports` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `chat_reports_conversation_idx` ON `chat_reports` (`conversationId`);
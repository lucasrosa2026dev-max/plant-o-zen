CREATE TABLE `analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(160) NOT NULL,
	`result` varchar(80) NOT NULL,
	`details` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(120) NOT NULL,
	`phone` varchar(32) NOT NULL,
	`email` varchar(320),
	`relationship` varchar(80),
	`isEmergency` int NOT NULL DEFAULT 0,
	`linkedOpenId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`),
	CONSTRAINT `contacts_user_id_id_idx` UNIQUE(`userId`,`id`)
);
--> statement-breakpoint
CREATE TABLE `emergency_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`status` enum('active','cancelled','resolved') NOT NULL DEFAULT 'active',
	`message` varchar(240),
	`notificationsSent` int NOT NULL DEFAULT 0,
	`callStatus` enum('not_attempted','initiated','not_completed') NOT NULL DEFAULT 'not_attempted',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`cancelledAt` timestamp,
	CONSTRAINT `emergency_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inbox_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`relatedEmergencyId` int,
	`eventType` varchar(64) NOT NULL,
	`title` varchar(160) NOT NULL,
	`body` text NOT NULL,
	`isRead` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inbox_notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notification_preferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`notificationsEnabled` int NOT NULL DEFAULT 1,
	`soundEnabled` int NOT NULL DEFAULT 1,
	`smartwatchEnabled` int NOT NULL DEFAULT 1,
	`backgroundEnabled` int NOT NULL DEFAULT 1,
	`callConfirmationRequired` int NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notification_preferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `notification_preferences_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fullName` varchar(120),
	`phone` varchar(32),
	`birthDate` varchar(10),
	`city` varchar(100),
	`careNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `smartwatch_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`platform` varchar(80),
	`pwaInstalled` int NOT NULL DEFAULT 0,
	`supportsNotifications` int NOT NULL DEFAULT 0,
	`supportsActions` int NOT NULL DEFAULT 0,
	`notificationPermission` varchar(32) NOT NULL DEFAULT 'default',
	`smartwatchMirroring` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `smartwatch_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `smartwatch_settings_userId_unique` UNIQUE(`userId`)
);

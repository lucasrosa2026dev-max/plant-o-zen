CREATE TABLE `pushDevices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`token` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pushDevices_id` PRIMARY KEY(`id`),
	CONSTRAINT `push_token_hash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `pushQueue` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`deviceId` int NOT NULL,
	`isTest` int NOT NULL DEFAULT 0,
	`attempts` int NOT NULL DEFAULT 0,
	`status` enum('pending','accepted','failed','cancelled') NOT NULL DEFAULT 'pending',
	`availableAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pushQueue_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `push_user_idx` ON `pushDevices` (`userId`);--> statement-breakpoint
CREATE INDEX `push_due_idx` ON `pushQueue` (`status`,`availableAt`);
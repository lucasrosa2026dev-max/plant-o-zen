CREATE TABLE `daily_checkins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mood` varchar(80) NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `daily_checkins_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `safety_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`safeLocation` varchar(240),
	`medications` text,
	`allergies` text,
	`priorityContacts` text,
	`instructions` text,
	`localServices` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `safety_plans_id` PRIMARY KEY(`id`),
	CONSTRAINT `safety_plans_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `notification_preferences` ADD `theme` enum('light','dark') DEFAULT 'light' NOT NULL;